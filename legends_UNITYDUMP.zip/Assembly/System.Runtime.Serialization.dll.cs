// Namespace: 
internal class <Module>
{}

// Namespace: System.Runtime.Serialization
public sealed class IgnoreDataMemberAttribute
{
	// Methods

	// RVA: 0xFFFFFFFF75A59000
	public Void .ctor() { }

}


