// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine.Networking
public sealed class DownloadHandlerAudioClip
{
	// Properties
	public AudioClip audioClip { get; }

	// Methods

	// RVA: 0xFFFFFFFF75CA2FEC
	public AudioClip get_audioClip() { }

	// RVA: 0xFFFFFFFF75CA302C
	public static AudioClip GetContent(UnityWebRequest www) { }

}


