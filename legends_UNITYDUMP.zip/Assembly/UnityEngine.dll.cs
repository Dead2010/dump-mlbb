// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine
internal class GUILayer
{
	// Methods

	// RVA: 0xFFFFFFFF75CAA19C
	public Void .ctor() { }

}


