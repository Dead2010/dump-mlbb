// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine
public static class JsonUtility
{
	// Methods

	// RVA: 0xFFFFFFFF75C6C3E0
	private static String ToJsonInternal(Object obj, Boolean prettyPrint) { }

	// RVA: 0xFFFFFFFF75C6C430
	private static Object FromJsonInternal(String json, Object objectToOverwrite, Type type) { }

	// RVA: 0xFFFFFFFF75C6C488
	public static String ToJson(Object obj) { }

	// RVA: 0xFFFFFFFF75C6C490
	public static String ToJson(Object obj, Boolean prettyPrint) { }

	// RVA: -1
	public static T FromJson(String json) { }

	// RVA: 0xFFFFFFFF75C6C5DC
	public static Object FromJson(String json, Type type) { }

}


