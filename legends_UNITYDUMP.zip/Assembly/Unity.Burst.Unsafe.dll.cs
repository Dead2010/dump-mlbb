// Namespace: 
internal class <Module>
{}

// Namespace: Unity.Burst
internal static class Unsafe
{
	// Methods

	// RVA: -1
	public static ref T AsRef(Void* source) { }

}

// Namespace: System.Runtime.Versioning
internal sealed class NonVersionableAttribute
{
	// Methods

	// RVA: 0xFFFFFFFF75BBC5B0
	public Void .ctor() { }

}


