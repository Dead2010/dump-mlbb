// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine
public static class ImageConversion
{
	// Methods

	// RVA: 0xFFFFFFFF75C69B58
	public static Byte[] EncodeToPNG(Texture2D tex) { }

	// RVA: 0xFFFFFFFF75C69B98
	public static Byte[] EncodeToJPG(Texture2D tex, Int32 quality) { }

	// RVA: 0xFFFFFFFF75C69BE8
	public static Byte[] EncodeToJPG(Texture2D tex) { }

	// RVA: 0xFFFFFFFF75C69C2C
	public static Boolean LoadImage(Texture2D tex, Byte[] data, Boolean markNonReadable) { }

	// RVA: 0xFFFFFFFF75C69C84
	public static Boolean LoadImage(Texture2D tex, Byte[] data) { }

}


