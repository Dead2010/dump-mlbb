// Namespace: 
internal class <Module>
{}

// Namespace: System.Runtime.CompilerServices
public static class Unsafe
{
	// Methods

	// RVA: -1
	public static T Read(Void* source) { }

	// RVA: -1
	public static Void* AsPointer(ref T value) { }

	// RVA: 0xFFFFFFFF75A58FF0
	public static Void CopyBlockUnaligned(Void* destination, Void* source, UInt32 byteCount) { }

	// RVA: -1
	public static T As(Object o) { }

	// RVA: -1
	public static ref TTo As(ref TFrom source) { }

}

// Namespace: System.Runtime.Versioning
internal sealed class NonVersionableAttribute
{
	// Methods

	// RVA: 0xFFFFFFFF75A58FF8
	public Void .ctor() { }

}


