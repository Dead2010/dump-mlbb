// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine.AI
public static class NavMesh
{
	// Fields
	public static OnNavMeshPreUpdate onPreUpdate; // 0x0

	// Methods

	// RVA: 0xFFFFFFFF723B310C
	private static Void Internal_CallOnNavMeshPreUpdate() { }

}

// Namespace: 
public sealed class OnNavMeshPreUpdate
{
	// Methods

	// RVA: 0xFFFFFFFF75BD3B3C
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: 0xFFFFFFFF75BD3940
	public virtual Void Invoke() { }

	// RVA: 0xFFFFFFFF75BD3B50
	public virtual IAsyncResult BeginInvoke(AsyncCallback callback, Object object) { }

	// RVA: 0xFFFFFFFF75BD3BA8
	public virtual Void EndInvoke(IAsyncResult result) { }

}


