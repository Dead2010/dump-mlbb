// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine
public sealed class SpriteMask
{
	// Properties
	public Sprite sprite { set; }

	// Methods

	// RVA: 0xFFFFFFFF75C7EE0C
	public Void set_sprite(Sprite value) { }

}


