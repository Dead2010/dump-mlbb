// Namespace: 
internal class <Module>
{}

// Namespace: UnityEngine
public sealed class Grid
{
	// Properties
	public Vector3 cellSize { get; }

	// Methods

	// RVA: 0xFFFFFFFF75C4D0D0
	public Vector3 get_cellSize() { }

	// RVA: 0xFFFFFFFF75C4D130
	private Void get_cellSize_Injected(out Vector3 ret) { }

}

// Namespace: UnityEngine
public class GridLayout
{
	// Methods

	// RVA: 0xFFFFFFFF75C4D180
	private Void DoNothing() { }

}


