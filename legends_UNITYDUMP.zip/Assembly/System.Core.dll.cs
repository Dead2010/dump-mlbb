// Namespace: 
internal class <Module>
{}

// Namespace: 
internal static class SR
{
	// Methods

	// RVA: 0xFFFFFFFF759F3D1C
	internal static String GetString(String name) { }

	// RVA: 0xFFFFFFFF759F3D20
	internal static String Format(String resourceFormat, Object p1) { }

	// RVA: 0xFFFFFFFF759F3D70
	internal static String Format(String resourceFormat, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF759F3DD0
	internal static String Format(String resourceFormat, Object p1, Object p2, Object p3) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T-1>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T0>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T0, T1>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T0, T1, T2>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T0, T1, T2, T3>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T0, T1, T2, T3, T4>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Action`<T0, T1, T2, T3, T4, T5>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual Void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, T16 arg16) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, T16 arg16, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual Void EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T-1>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0, T1>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0, T1, T2>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0, T1, T2, T3>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0, T1, T2, T3, T4>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0, T1, T2, T3, T4, T5>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System
public sealed class Func`<T0, T1, T2, T3, T4, T5, T6>
{
	// Methods

	// RVA: -1
	public Void .ctor(Object object, IntPtr method) { }

	// RVA: -1
	public virtual TResult Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, T16 arg16) { }

	// RVA: -1
	public virtual IAsyncResult BeginInvoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5, T6 arg6, T7 arg7, T8 arg8, T9 arg9, T10 arg10, T11 arg11, T12 arg12, T13 arg13, T14 arg14, T15 arg15, T16 arg16, AsyncCallback callback, Object object) { }

	// RVA: -1
	public virtual TResult EndInvoke(IAsyncResult result) { }

}

// Namespace: System.Threading
public enum LockRecursionPolicy
{
	// Fields
	public Int32 value__; // 0x10
	public const LockRecursionPolicy NoRecursion = 0;
	public const LockRecursionPolicy SupportsRecursion = 1;
}

// Namespace: System.Threading
internal class ReaderWriterCount
{
	// Fields
	public Int64 lockID; // 0x10
	public Int32 readercount; // 0x18
	public Int32 writercount; // 0x1C
	public Int32 upgradecount; // 0x20
	public ReaderWriterCount next; // 0x28

	// Methods

	// RVA: 0xFFFFFFFF75A56FB8
	public Void .ctor() { }

}

// Namespace: System.Threading
public class ReaderWriterLockSlim
{
	// Fields
	private Boolean fIsReentrant; // 0x10
	private Int32 myLock; // 0x14
	private const Int32 LockSpinCycles = 20;
	private const Int32 LockSpinCount = 10;
	private const Int32 LockSleep0Count = 5;
	private UInt32 numWriteWaiters; // 0x18
	private UInt32 numReadWaiters; // 0x1C
	private UInt32 numWriteUpgradeWaiters; // 0x20
	private UInt32 numUpgradeWaiters; // 0x24
	private Boolean fNoWaiters; // 0x28
	private Int32 upgradeLockOwnerId; // 0x2C
	private Int32 writeLockOwnerId; // 0x30
	private EventWaitHandle writeEvent; // 0x38
	private EventWaitHandle readEvent; // 0x40
	private EventWaitHandle upgradeEvent; // 0x48
	private EventWaitHandle waitUpgradeEvent; // 0x50
	private static Int64 s_nextLockID; // 0x0
	private Int64 lockID; // 0x58
	private static ReaderWriterCount t_rwc; // 0xFFFFFFFFFFFFFFFF
	private Boolean fUpgradeThreadHoldingRead; // 0x60
	private const Int32 MaxSpinCount = 20;
	private UInt32 owners; // 0x64
	private const UInt32 WRITER_HELD = 2147483648;
	private const UInt32 WAITING_WRITERS = 1073741824;
	private const UInt32 WAITING_UPGRADER = 536870912;
	private const UInt32 MAX_READER = 268435454;
	private const UInt32 READER_MASK = 268435455;
	private Boolean fDisposed; // 0x68

	// Properties
	public Boolean IsReadLockHeld { get; }
	public Boolean IsUpgradeableReadLockHeld { get; }
	public Boolean IsWriteLockHeld { get; }
	public Int32 RecursiveReadCount { get; }
	public Int32 RecursiveUpgradeCount { get; }
	public Int32 RecursiveWriteCount { get; }
	public Int32 WaitingReadCount { get; }
	public Int32 WaitingUpgradeCount { get; }
	public Int32 WaitingWriteCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A56FC0
	private Void InitializeThreadCounts() { }

	// RVA: 0xFFFFFFFF75A56FCC
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A57018
	public Void .ctor(LockRecursionPolicy recursionPolicy) { }

	// RVA: 0xFFFFFFFF75A57078
	private static Boolean IsRWEntryEmpty(ReaderWriterCount rwc) { }

	// RVA: 0xFFFFFFFF75A570BC
	private Boolean IsRwHashEntryChanged(ReaderWriterCount lrwc) { }

	// RVA: 0xFFFFFFFF75A570E4
	private ReaderWriterCount GetThreadRWCount(Boolean dontAllocate) { }

	// RVA: 0xFFFFFFFF75A571FC
	public Void EnterReadLock() { }

	// RVA: 0xFFFFFFFF75A57240
	public Boolean TryEnterReadLock(Int32 millisecondsTimeout) { }

	// RVA: 0xFFFFFFFF75A5731C
	private Boolean TryEnterReadLock(TimeoutTracker timeout) { }

	// RVA: 0xFFFFFFFF75A57320
	private Boolean TryEnterReadLockCore(TimeoutTracker timeout) { }

	// RVA: 0xFFFFFFFF75A57B6C
	public Void EnterWriteLock() { }

	// RVA: 0xFFFFFFFF75A57BB0
	public Boolean TryEnterWriteLock(Int32 millisecondsTimeout) { }

	// RVA: 0xFFFFFFFF75A57BE8
	private Boolean TryEnterWriteLock(TimeoutTracker timeout) { }

	// RVA: 0xFFFFFFFF75A57BEC
	private Boolean TryEnterWriteLockCore(TimeoutTracker timeout) { }

	// RVA: 0xFFFFFFFF75A58018
	public Void EnterUpgradeableReadLock() { }

	// RVA: 0xFFFFFFFF75A5805C
	public Boolean TryEnterUpgradeableReadLock(Int32 millisecondsTimeout) { }

	// RVA: 0xFFFFFFFF75A58094
	private Boolean TryEnterUpgradeableReadLock(TimeoutTracker timeout) { }

	// RVA: 0xFFFFFFFF75A58098
	private Boolean TryEnterUpgradeableReadLockCore(TimeoutTracker timeout) { }

	// RVA: 0xFFFFFFFF75A5844C
	public Void ExitReadLock() { }

	// RVA: 0xFFFFFFFF75A58620
	public Void ExitWriteLock() { }

	// RVA: 0xFFFFFFFF75A58798
	public Void ExitUpgradeableReadLock() { }

	// RVA: 0xFFFFFFFF75A578CC
	private Void LazyCreateEvent(ref EventWaitHandle waitEvent, Boolean makeAutoResetEvent) { }

	// RVA: 0xFFFFFFFF75A579A4
	private Boolean WaitOnEvent(EventWaitHandle waitEvent, ref UInt32 numWaiters, TimeoutTracker timeout, Boolean isWriteWaiter) { }

	// RVA: 0xFFFFFFFF75A585E4
	private Void ExitAndWakeUpAppropriateWaiters() { }

	// RVA: 0xFFFFFFFF75A58A90
	private Void ExitAndWakeUpAppropriateWaitersPreferringWriters() { }

	// RVA: 0xFFFFFFFF75A589EC
	private Void ExitAndWakeUpAppropriateReadWaiters() { }

	// RVA: 0xFFFFFFFF75A57FEC
	private Boolean IsWriterAcquired() { }

	// RVA: 0xFFFFFFFF75A57FFC
	private Void SetWriterAcquired() { }

	// RVA: 0xFFFFFFFF75A58788
	private Void ClearWriterAcquired() { }

	// RVA: 0xFFFFFFFF75A58954
	private Void SetWritersWaiting() { }

	// RVA: 0xFFFFFFFF75A589CC
	private Void ClearWritersWaiting() { }

	// RVA: 0xFFFFFFFF75A58964
	private Void SetUpgraderWaiting() { }

	// RVA: 0xFFFFFFFF75A589DC
	private Void ClearUpgraderWaiting() { }

	// RVA: 0xFFFFFFFF75A5800C
	private UInt32 GetNumReaders() { }

	// RVA: 0xFFFFFFFF75A58B28
	private Void EnterMyLock() { }

	// RVA: 0xFFFFFFFF75A58B6C
	private Void EnterMyLockSpin() { }

	// RVA: 0xFFFFFFFF75A577E4
	private Void ExitMyLock() { }

	// RVA: 0xFFFFFFFF75A57868
	private static Void SpinWait(Int32 SpinCount) { }

	// RVA: 0xFFFFFFFF75A58C10
	public Void Dispose() { }

	// RVA: 0xFFFFFFFF75A58C18
	private Void Dispose(Boolean disposing) { }

	// RVA: 0xFFFFFFFF75A58DC8
	public Boolean get_IsReadLockHeld() { }

	// RVA: 0xFFFFFFFF75A58DE4
	public Boolean get_IsUpgradeableReadLockHeld() { }

	// RVA: 0xFFFFFFFF75A58E00
	public Boolean get_IsWriteLockHeld() { }

	// RVA: 0xFFFFFFFF75A58E1C
	public Int32 get_RecursiveReadCount() { }

	// RVA: 0xFFFFFFFF75A58E90
	public Int32 get_RecursiveUpgradeCount() { }

	// RVA: 0xFFFFFFFF75A58F34
	public Int32 get_RecursiveWriteCount() { }

	// RVA: 0xFFFFFFFF75A58FD8
	public Int32 get_WaitingReadCount() { }

	// RVA: 0xFFFFFFFF75A58FE0
	public Int32 get_WaitingUpgradeCount() { }

	// RVA: 0xFFFFFFFF75A58FE8
	public Int32 get_WaitingWriteCount() { }

}

// Namespace: 
private struct TimeoutTracker
{
	// Fields
	private Int32 m_total; // 0x10
	private Int32 m_start; // 0x14

	// Properties
	public Int32 RemainingMilliseconds { get; }
	public Boolean IsExpired { get; }

	// Methods

	// RVA: 0xFFFFFFFF71144CE8
	public Void .ctor(Int32 millisecondsTimeout) { }

	// RVA: 0xFFFFFFFF71144CF0
	public Int32 get_RemainingMilliseconds() { }

	// RVA: 0xFFFFFFFF71144D48
	public Boolean get_IsExpired() { }

}

// Namespace: System.Security.Cryptography
public sealed class AesManaged
{
	// Fields
	private RijndaelManaged m_rijndael; // 0x48

	// Properties
	public override Int32 FeedbackSize { get; }
	public override Byte[] IV { get; set; }
	public override Byte[] Key { get; set; }
	public override Int32 KeySize { get; set; }
	public override CipherMode Mode { get; set; }
	public override PaddingMode Padding { get; set; }

	// Methods

	// RVA: 0xFFFFFFFF75A546B4
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A54808
	public override Int32 get_FeedbackSize() { }

	// RVA: 0xFFFFFFFF75A54830
	public override Byte[] get_IV() { }

	// RVA: 0xFFFFFFFF75A54858
	public override Void set_IV(Byte[] value) { }

	// RVA: 0xFFFFFFFF75A54880
	public override Byte[] get_Key() { }

	// RVA: 0xFFFFFFFF75A548A8
	public override Void set_Key(Byte[] value) { }

	// RVA: 0xFFFFFFFF75A548D0
	public override Int32 get_KeySize() { }

	// RVA: 0xFFFFFFFF75A548F8
	public override Void set_KeySize(Int32 value) { }

	// RVA: 0xFFFFFFFF75A54920
	public override CipherMode get_Mode() { }

	// RVA: 0xFFFFFFFF75A54948
	public override Void set_Mode(CipherMode value) { }

	// RVA: 0xFFFFFFFF75A54A04
	public override PaddingMode get_Padding() { }

	// RVA: 0xFFFFFFFF75A54A2C
	public override Void set_Padding(PaddingMode value) { }

	// RVA: 0xFFFFFFFF75A54A54
	public override ICryptoTransform CreateDecryptor() { }

	// RVA: 0xFFFFFFFF75A54A7C
	public override ICryptoTransform CreateDecryptor(Byte[] key, Byte[] iv) { }

	// RVA: 0xFFFFFFFF75A54BF8
	public override ICryptoTransform CreateEncryptor() { }

	// RVA: 0xFFFFFFFF75A54C20
	public override ICryptoTransform CreateEncryptor(Byte[] key, Byte[] iv) { }

	// RVA: 0xFFFFFFFF75A54D9C
	protected override Void Dispose(Boolean disposing) { }

	// RVA: 0xFFFFFFFF75A54E8C
	public override Void GenerateIV() { }

	// RVA: 0xFFFFFFFF75A54EB4
	public override Void GenerateKey() { }

}

// Namespace: System.Security.Cryptography
public sealed class AesCryptoServiceProvider
{
	// Properties
	public override Byte[] IV { get; set; }
	public override Byte[] Key { get; set; }
	public override Int32 KeySize { get; set; }
	public override Int32 FeedbackSize { get; }
	public override CipherMode Mode { get; set; }
	public override PaddingMode Padding { get; set; }

	// Methods

	// RVA: 0xFFFFFFFF75A54248
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A542B8
	public override Void GenerateIV() { }

	// RVA: 0xFFFFFFFF75A542F0
	public override Void GenerateKey() { }

	// RVA: 0xFFFFFFFF75A54328
	public override ICryptoTransform CreateDecryptor(Byte[] key, Byte[] iv) { }

	// RVA: 0xFFFFFFFF75A5441C
	public override ICryptoTransform CreateEncryptor(Byte[] key, Byte[] iv) { }

	// RVA: 0xFFFFFFFF75A54514
	public override Byte[] get_IV() { }

	// RVA: 0xFFFFFFFF75A5451C
	public override Void set_IV(Byte[] value) { }

	// RVA: 0xFFFFFFFF75A54524
	public override Byte[] get_Key() { }

	// RVA: 0xFFFFFFFF75A5452C
	public override Void set_Key(Byte[] value) { }

	// RVA: 0xFFFFFFFF75A54534
	public override Int32 get_KeySize() { }

	// RVA: 0xFFFFFFFF75A5453C
	public override Void set_KeySize(Int32 value) { }

	// RVA: 0xFFFFFFFF75A54544
	public override Int32 get_FeedbackSize() { }

	// RVA: 0xFFFFFFFF72367338
	public override CipherMode get_Mode() { }

	// RVA: 0xFFFFFFFF75A5454C
	public override Void set_Mode(CipherMode value) { }

	// RVA: 0xFFFFFFFF75A545E4
	public override PaddingMode get_Padding() { }

	// RVA: 0xFFFFFFFF75A545EC
	public override Void set_Padding(PaddingMode value) { }

	// RVA: 0xFFFFFFFF75A545F4
	public override ICryptoTransform CreateDecryptor() { }

	// RVA: 0xFFFFFFFF75A54650
	public override ICryptoTransform CreateEncryptor() { }

	// RVA: 0xFFFFFFFF75A546AC
	protected override Void Dispose(Boolean disposing) { }

}

// Namespace: System.Security.Cryptography
internal class AesTransform
{
	// Fields
	private UInt32[] expandedKey; // 0x58
	private Int32 Nk; // 0x60
	private Int32 Nr; // 0x64
	private static readonly UInt32[] Rcon; // 0x0
	private static readonly Byte[] SBox; // 0x8
	private static readonly Byte[] iSBox; // 0x10
	private static readonly UInt32[] T0; // 0x18
	private static readonly UInt32[] T1; // 0x20
	private static readonly UInt32[] T2; // 0x28
	private static readonly UInt32[] T3; // 0x30
	private static readonly UInt32[] iT0; // 0x38
	private static readonly UInt32[] iT1; // 0x40
	private static readonly UInt32[] iT2; // 0x48
	private static readonly UInt32[] iT3; // 0x50

	// Methods

	// RVA: 0xFFFFFFFF72366C60
	public Void .ctor(Aes algo, Boolean encryption, Byte[] key, Byte[] iv) { }

	// RVA: 0xFFFFFFFF72367340
	protected override Void ECB(Byte[] input, Byte[] output) { }

	// RVA: 0xFFFFFFFF75A54EDC
	private UInt32 SubByte(UInt32 a) { }

	// RVA: 0xFFFFFFFF75A54FBC
	private Void Encrypt128(Byte[] indata, Byte[] outdata, UInt32[] ekey) { }

	// RVA: 0xFFFFFFFF72367354
	private Void Decrypt128(Byte[] indata, Byte[] outdata, UInt32[] ekey) { }

	// RVA: 0xFFFFFFFF75A56CBC
	private static Void .cctor() { }

}

// Namespace: System.Linq
internal static class Error
{
	// Methods

	// RVA: 0xFFFFFFFF759F7E64
	internal static Exception ArgumentNull(String s) { }

	// RVA: 0xFFFFFFFF759F891C
	internal static Exception ArgumentOutOfRange(String s) { }

	// RVA: 0xFFFFFFFF759F8958
	internal static Exception MoreThanOneMatch() { }

	// RVA: 0xFFFFFFFF759F8374
	internal static Exception NoElements() { }

	// RVA: 0xFFFFFFFF759F89B4
	internal static Exception NoMatch() { }

	// RVA: 0xFFFFFFFF759F8A10
	internal static Exception NotSupported() { }

}

// Namespace: System.Linq
public static class Enumerable
{
	// Methods

	// RVA: -1
	public static IEnumerable<T0> Where(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public static IEnumerable<T0> Select(IEnumerable<T0> source, Func<T0, T1> selector) { }

	// RVA: -1
	private static Func<T0, T1> CombinePredicates(Func<T0, T1> predicate1, Func<T0, T1> predicate2) { }

	// RVA: -1
	private static Func<T0, T1> CombineSelectors(Func<T0, T1> selector1, Func<T0, T1> selector2) { }

	// RVA: -1
	public static IEnumerable<T0> SelectMany(IEnumerable<T0> source, Func<T0, T1> selector) { }

	// RVA: -1
	private static IEnumerable<T0> SelectManyIterator(IEnumerable<T0> source, Func<T0, T1> selector) { }

	// RVA: -1
	public static IEnumerable<T0> SelectMany(IEnumerable<T0> source, Func<T0, T1> collectionSelector, Func<T0, T1, T2> resultSelector) { }

	// RVA: -1
	private static IEnumerable<T0> SelectManyIterator(IEnumerable<T0> source, Func<T0, T1> collectionSelector, Func<T0, T1, T2> resultSelector) { }

	// RVA: -1
	public static IEnumerable<T0> Take(IEnumerable<T0> source, Int32 count) { }

	// RVA: -1
	private static IEnumerable<T0> TakeIterator(IEnumerable<T0> source, Int32 count) { }

	// RVA: -1
	public static IEnumerable<T0> Skip(IEnumerable<T0> source, Int32 count) { }

	// RVA: -1
	private static IEnumerable<T0> SkipIterator(IEnumerable<T0> source, Int32 count) { }

	// RVA: -1
	public static IEnumerable<T0> Join(IEnumerable<T0> outer, IEnumerable<T0> inner, Func<T0, T1> outerKeySelector, Func<T0, T1> innerKeySelector, Func<T0, T1, T2> resultSelector) { }

	// RVA: -1
	private static IEnumerable<T0> JoinIterator(IEnumerable<T0> outer, IEnumerable<T0> inner, Func<T0, T1> outerKeySelector, Func<T0, T1> innerKeySelector, Func<T0, T1, T2> resultSelector, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static IOrderedEnumerable<T0> OrderBy(IEnumerable<T0> source, Func<T0, T1> keySelector) { }

	// RVA: -1
	public static IOrderedEnumerable<T0> OrderBy(IEnumerable<T0> source, Func<T0, T1> keySelector, IComparer<T0> comparer) { }

	// RVA: -1
	public static IOrderedEnumerable<T0> OrderByDescending(IEnumerable<T0> source, Func<T0, T1> keySelector) { }

	// RVA: -1
	public static IOrderedEnumerable<T0> ThenBy(IOrderedEnumerable<T0> source, Func<T0, T1> keySelector) { }

	// RVA: -1
	public static IEnumerable<T0> GroupBy(IEnumerable<T0> source, Func<T0, T1> keySelector) { }

	// RVA: -1
	public static IEnumerable<T0> GroupBy(IEnumerable<T0> source, Func<T0, T1> keySelector, Func<T0, T1> elementSelector) { }

	// RVA: -1
	public static IEnumerable<T0> Concat(IEnumerable<T0> first, IEnumerable<T0> second) { }

	// RVA: -1
	private static IEnumerable<T0> ConcatIterator(IEnumerable<T0> first, IEnumerable<T0> second) { }

	// RVA: -1
	public static IEnumerable<T0> Distinct(IEnumerable<T0> source) { }

	// RVA: -1
	private static IEnumerable<T0> DistinctIterator(IEnumerable<T0> source, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static IEnumerable<T0> Union(IEnumerable<T0> first, IEnumerable<T0> second) { }

	// RVA: -1
	private static IEnumerable<T0> UnionIterator(IEnumerable<T0> first, IEnumerable<T0> second, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static IEnumerable<T0> Intersect(IEnumerable<T0> first, IEnumerable<T0> second) { }

	// RVA: -1
	private static IEnumerable<T0> IntersectIterator(IEnumerable<T0> first, IEnumerable<T0> second, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static IEnumerable<T0> Except(IEnumerable<T0> first, IEnumerable<T0> second) { }

	// RVA: -1
	private static IEnumerable<T0> ExceptIterator(IEnumerable<T0> first, IEnumerable<T0> second, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static Boolean SequenceEqual(IEnumerable<T0> first, IEnumerable<T0> second) { }

	// RVA: -1
	public static Boolean SequenceEqual(IEnumerable<T0> first, IEnumerable<T0> second, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static TSource[] ToArray(IEnumerable<T0> source) { }

	// RVA: -1
	public static List<T0> ToList(IEnumerable<T0> source) { }

	// RVA: -1
	public static Dictionary<T0, T1> ToDictionary(IEnumerable<T0> source, Func<T0, T1> keySelector, Func<T0, T1> elementSelector) { }

	// RVA: -1
	public static Dictionary<T0, T1> ToDictionary(IEnumerable<T0> source, Func<T0, T1> keySelector, Func<T0, T1> elementSelector, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public static IEnumerable<T0> Cast(IEnumerable source) { }

	// RVA: -1
	private static IEnumerable<T0> CastIterator(IEnumerable source) { }

	// RVA: -1
	public static TSource First(IEnumerable<T0> source) { }

	// RVA: -1
	public static TSource First(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public static TSource FirstOrDefault(IEnumerable<T0> source) { }

	// RVA: -1
	public static TSource FirstOrDefault(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public static TSource Last(IEnumerable<T0> source) { }

	// RVA: -1
	public static TSource SingleOrDefault(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public static TSource ElementAt(IEnumerable<T0> source, Int32 index) { }

	// RVA: -1
	public static IEnumerable<T0> Empty() { }

	// RVA: -1
	public static Boolean Any(IEnumerable<T0> source) { }

	// RVA: -1
	public static Boolean Any(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public static Boolean All(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public static Int32 Count(IEnumerable<T0> source) { }

	// RVA: -1
	public static Boolean Contains(IEnumerable<T0> source, TSource value) { }

	// RVA: -1
	public static Boolean Contains(IEnumerable<T0> source, TSource value, IEqualityComparer<T0> comparer) { }

	// RVA: 0xFFFFFFFF759F7BF4
	public static Int32 Sum(IEnumerable<T0> source) { }

	// RVA: 0xFFFFFFFF759F7EA0
	public static Double Sum(IEnumerable<T0> source) { }

	// RVA: -1
	public static Int32 Sum(IEnumerable<T0> source, Func<T0, T1> selector) { }

	// RVA: -1
	public static Double Sum(IEnumerable<T0> source, Func<T0, T1> selector) { }

	// RVA: 0xFFFFFFFF759F8104
	public static Int32 Min(IEnumerable<T0> source) { }

	// RVA: 0xFFFFFFFF759F83D0
	public static Int32 Max(IEnumerable<T0> source) { }

	// RVA: -1
	public static Int32 Max(IEnumerable<T0> source, Func<T0, T1> selector) { }

	// RVA: 0xFFFFFFFF759F8640
	public static Double Average(IEnumerable<T0> source) { }

}

// Namespace: 
private abstract class Iterator<T0>
{
	// Fields
	private Int32 threadId; // 0x0
	internal Int32 state; // 0x0
	internal TSource current; // 0x0

	// Properties
	public TSource Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	public TSource get_Current() { }

	// RVA: -1
	public abstract Iterator<T0> Clone() { }

	// RVA: -1
	public virtual Void Dispose() { }

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	public abstract Boolean MoveNext() { }

	// RVA: -1
	public abstract IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public abstract IEnumerable<T0> Where(Func<T0, T1> predicate) { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private class WhereEnumerableIterator<T0>
{
	// Fields
	private IEnumerable<T0> source; // 0x0
	private Func<T0, T1> predicate; // 0x0
	private IEnumerator<T0> enumerator; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(IEnumerable<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public override Iterator<T0> Clone() { }

	// RVA: -1
	public override Void Dispose() { }

	// RVA: -1
	public override Boolean MoveNext() { }

	// RVA: -1
	public override IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public override IEnumerable<T0> Where(Func<T0, T1> predicate) { }

}

// Namespace: 
private class WhereArrayIterator<T0>
{
	// Fields
	private TSource[] source; // 0x0
	private Func<T0, T1> predicate; // 0x0
	private Int32 index; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(TSource[] source, Func<T0, T1> predicate) { }

	// RVA: -1
	public override Iterator<T0> Clone() { }

	// RVA: -1
	public override Boolean MoveNext() { }

	// RVA: -1
	public override IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public override IEnumerable<T0> Where(Func<T0, T1> predicate) { }

}

// Namespace: 
private class WhereListIterator<T0>
{
	// Fields
	private List<T0> source; // 0x0
	private Func<T0, T1> predicate; // 0x0
	private Enumerator enumerator; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(List<T0> source, Func<T0, T1> predicate) { }

	// RVA: -1
	public override Iterator<T0> Clone() { }

	// RVA: -1
	public override Boolean MoveNext() { }

	// RVA: -1
	public override IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public override IEnumerable<T0> Where(Func<T0, T1> predicate) { }

}

// Namespace: 
private class WhereSelectEnumerableIterator<T0, T1>
{
	// Fields
	private IEnumerable<T0> source; // 0x0
	private Func<T0, T1> predicate; // 0x0
	private Func<T0, T1> selector; // 0x0
	private IEnumerator<T0> enumerator; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(IEnumerable<T0> source, Func<T0, T1> predicate, Func<T0, T1> selector) { }

	// RVA: -1
	public override Iterator<T0> Clone() { }

	// RVA: -1
	public override Void Dispose() { }

	// RVA: -1
	public override Boolean MoveNext() { }

	// RVA: -1
	public override IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public override IEnumerable<T0> Where(Func<T0, T1> predicate) { }

}

// Namespace: 
private class WhereSelectArrayIterator<T0, T1>
{
	// Fields
	private TSource[] source; // 0x0
	private Func<T0, T1> predicate; // 0x0
	private Func<T0, T1> selector; // 0x0
	private Int32 index; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(TSource[] source, Func<T0, T1> predicate, Func<T0, T1> selector) { }

	// RVA: -1
	public override Iterator<T0> Clone() { }

	// RVA: -1
	public override Boolean MoveNext() { }

	// RVA: -1
	public override IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public override IEnumerable<T0> Where(Func<T0, T1> predicate) { }

}

// Namespace: 
private class WhereSelectListIterator<T0, T1>
{
	// Fields
	private List<T0> source; // 0x0
	private Func<T0, T1> predicate; // 0x0
	private Func<T0, T1> selector; // 0x0
	private Enumerator enumerator; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(List<T0> source, Func<T0, T1> predicate, Func<T0, T1> selector) { }

	// RVA: -1
	public override Iterator<T0> Clone() { }

	// RVA: -1
	public override Boolean MoveNext() { }

	// RVA: -1
	public override IEnumerable<T0> Select(Func<T0, T1> selector) { }

	// RVA: -1
	public override IEnumerable<T0> Where(Func<T0, T1> predicate) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0<T0>
{
	// Fields
	public Func<T0, T1> predicate1; // 0x0
	public Func<T0, T1> predicate2; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	internal Boolean <CombinePredicates>b__0(TSource x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0<T0, T1, T2>
{
	// Fields
	public Func<T0, T1> selector2; // 0x0
	public Func<T0, T1> selector1; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	internal TResult <CombineSelectors>b__0(TSource x) { }

}

// Namespace: 
private sealed class <SelectManyIterator>d__17<T0, T1>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TResult <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEnumerable<T0> source; // 0x0
	public IEnumerable<T0> <>3__source; // 0x0
	private Func<T0, T1> selector; // 0x0
	public Func<T0, T1> <>3__selector; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0
	private IEnumerator<T0> <>7__wrap2; // 0x0

	// Properties
	private TResult System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private Void <>m__Finally2() { }

	// RVA: -1
	private TResult System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <SelectManyIterator>d__23<T0, T1, T2>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TResult <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEnumerable<T0> source; // 0x0
	public IEnumerable<T0> <>3__source; // 0x0
	private Func<T0, T1> collectionSelector; // 0x0
	public Func<T0, T1> <>3__collectionSelector; // 0x0
	private Func<T0, T1, T2> resultSelector; // 0x0
	public Func<T0, T1, T2> <>3__resultSelector; // 0x0
	private TSource <element>5__1; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0
	private IEnumerator<T0> <>7__wrap2; // 0x0

	// Properties
	private TResult System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private Void <>m__Finally2() { }

	// RVA: -1
	private TResult System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <TakeIterator>d__25<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private Int32 count; // 0x0
	public Int32 <>3__count; // 0x0
	private IEnumerable<T0> source; // 0x0
	public IEnumerable<T0> <>3__source; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <SkipIterator>d__31<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEnumerable<T0> source; // 0x0
	public IEnumerable<T0> <>3__source; // 0x0
	private Int32 count; // 0x0
	public Int32 <>3__count; // 0x0
	private IEnumerator<T0> <e>5__1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <JoinIterator>d__38<T0, T1, T2, T3>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TResult <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEnumerable<T0> inner; // 0x0
	public IEnumerable<T0> <>3__inner; // 0x0
	private Func<T0, T1> innerKeySelector; // 0x0
	public Func<T0, T1> <>3__innerKeySelector; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0
	public IEqualityComparer<T0> <>3__comparer; // 0x0
	private IEnumerable<T0> outer; // 0x0
	public IEnumerable<T0> <>3__outer; // 0x0
	private Lookup<T0, T1> <lookup>5__1; // 0x0
	private Func<T0, T1> outerKeySelector; // 0x0
	public Func<T0, T1> <>3__outerKeySelector; // 0x0
	private Func<T0, T1, T2> resultSelector; // 0x0
	public Func<T0, T1, T2> <>3__resultSelector; // 0x0
	private TOuter <item>5__2; // 0x0
	private Grouping <g>5__3; // 0x0
	private Int32 <i>5__4; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TResult System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TResult System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <ConcatIterator>d__59<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEnumerable<T0> first; // 0x0
	public IEnumerable<T0> <>3__first; // 0x0
	private IEnumerable<T0> second; // 0x0
	public IEnumerable<T0> <>3__second; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private Void <>m__Finally2() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <DistinctIterator>d__68<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0
	public IEqualityComparer<T0> <>3__comparer; // 0x0
	private IEnumerable<T0> source; // 0x0
	public IEnumerable<T0> <>3__source; // 0x0
	private Set<T0> <set>5__1; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <UnionIterator>d__71<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0
	public IEqualityComparer<T0> <>3__comparer; // 0x0
	private IEnumerable<T0> first; // 0x0
	public IEnumerable<T0> <>3__first; // 0x0
	private Set<T0> <set>5__1; // 0x0
	private IEnumerable<T0> second; // 0x0
	public IEnumerable<T0> <>3__second; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private Void <>m__Finally2() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <IntersectIterator>d__74<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0
	public IEqualityComparer<T0> <>3__comparer; // 0x0
	private IEnumerable<T0> second; // 0x0
	public IEnumerable<T0> <>3__second; // 0x0
	private IEnumerable<T0> first; // 0x0
	public IEnumerable<T0> <>3__first; // 0x0
	private Set<T0> <set>5__1; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <ExceptIterator>d__77<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TSource <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0
	public IEqualityComparer<T0> <>3__comparer; // 0x0
	private IEnumerable<T0> second; // 0x0
	public IEnumerable<T0> <>3__second; // 0x0
	private IEnumerable<T0> first; // 0x0
	public IEnumerable<T0> <>3__first; // 0x0
	private Set<T0> <set>5__1; // 0x0
	private IEnumerator<T0> <>7__wrap1; // 0x0

	// Properties
	private TSource System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TSource System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <CastIterator>d__99<T0>
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TResult <>2__current; // 0x0
	private Int32 <>l__initialThreadId; // 0x0
	private IEnumerable source; // 0x0
	public IEnumerable <>3__source; // 0x0
	private IEnumerator <>7__wrap1; // 0x0

	// Properties
	private TResult System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private Void <>m__Finally1() { }

	// RVA: -1
	private TResult System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Linq
internal class EmptyEnumerable<T0>
{
	// Fields
	public static readonly TElement[] Instance; // 0x0

	// Methods

	// RVA: -1
	private static Void .cctor() { }

}

// Namespace: System.Linq
internal class IdentityFunction<T0>
{
	// Properties
	public static Func<T0, T1> Instance { get; }

	// Methods

	// RVA: -1
	public static Func<T0, T1> get_Instance() { }

}

// Namespace: 
private sealed class <>c
{
	// Fields
	public static readonly <>c <>9; // 0x0
	public static Func<T0, T1> <>9__1_0; // 0x0

	// Methods

	// RVA: -1
	private static Void .cctor() { }

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	internal TElement <get_Instance>b__1_0(TElement x) { }

}

// Namespace: System.Linq
public interface IOrderedEnumerable<T0>
{
	// Methods

	// RVA: -1
	public abstract IOrderedEnumerable<T0> CreateOrderedEnumerable(Func<T0, T1> keySelector, IComparer<T0> comparer, Boolean descending) { }

}

// Namespace: System.Linq
public interface IGrouping<T0, T1>
{
	// Properties
	public abstract TKey Key { get; }

	// Methods

	// RVA: -1
	public abstract TKey get_Key() { }

}

// Namespace: System.Linq
public class Lookup<T0, T1>
{
	// Fields
	private IEqualityComparer<T0> comparer; // 0x0
	private Grouping[] groupings; // 0x0
	private Grouping lastGrouping; // 0x0
	private Int32 count; // 0x0

	// Methods

	// RVA: -1
	internal static Lookup<T0, T1> Create(IEnumerable<T0> source, Func<T0, T1> keySelector, Func<T0, T1> elementSelector, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	internal static Lookup<T0, T1> CreateForJoin(IEnumerable<T0> source, Func<T0, T1> keySelector, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	private Void .ctor(IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	internal Int32 InternalGetHashCode(TKey key) { }

	// RVA: -1
	internal Grouping GetGrouping(TKey key, Boolean create) { }

	// RVA: -1
	private Void Resize() { }

}

// Namespace: 
internal class Grouping
{
	// Fields
	internal TKey key; // 0x0
	internal Int32 hashCode; // 0x0
	internal TElement[] elements; // 0x0
	internal Int32 count; // 0x0
	internal Grouping hashNext; // 0x0
	internal Grouping next; // 0x0

	// Properties
	public TKey Key { get; }
	private Int32 System.Collections.Generic.ICollection<TElement>.Count { get; }
	private Boolean System.Collections.Generic.ICollection<TElement>.IsReadOnly { get; }
	private TElement System.Collections.Generic.IList<TElement>.Item { get; set; }

	// Methods

	// RVA: -1
	internal Void Add(TElement element) { }

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public TKey get_Key() { }

	// RVA: -1
	private Int32 System.Collections.Generic.ICollection<TElement>.get_Count() { }

	// RVA: -1
	private Boolean System.Collections.Generic.ICollection<TElement>.get_IsReadOnly() { }

	// RVA: -1
	private Void System.Collections.Generic.ICollection<TElement>.Add(TElement item) { }

	// RVA: -1
	private Void System.Collections.Generic.ICollection<TElement>.Clear() { }

	// RVA: -1
	private Boolean System.Collections.Generic.ICollection<TElement>.Contains(TElement item) { }

	// RVA: -1
	private Void System.Collections.Generic.ICollection<TElement>.CopyTo(TElement[] array, Int32 arrayIndex) { }

	// RVA: -1
	private Boolean System.Collections.Generic.ICollection<TElement>.Remove(TElement item) { }

	// RVA: -1
	private Int32 System.Collections.Generic.IList<TElement>.IndexOf(TElement item) { }

	// RVA: -1
	private Void System.Collections.Generic.IList<TElement>.Insert(Int32 index, TElement item) { }

	// RVA: -1
	private Void System.Collections.Generic.IList<TElement>.RemoveAt(Int32 index) { }

	// RVA: -1
	private TElement System.Collections.Generic.IList<TElement>.get_Item(Int32 index) { }

	// RVA: -1
	private Void System.Collections.Generic.IList<TElement>.set_Item(Int32 index, TElement value) { }

	// RVA: -1
	public Void .ctor() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__7
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TElement <>2__current; // 0x0
	public Grouping <>4__this; // 0x0
	private Int32 <i>5__1; // 0x0

	// Properties
	private TElement System.Collections.Generic.IEnumerator<TElement>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private TElement System.Collections.Generic.IEnumerator<TElement>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__12
{
	// Fields
	private Int32 <>1__state; // 0x0
	private IGrouping<T0, T1> <>2__current; // 0x0
	public Lookup<T0, T1> <>4__this; // 0x0
	private Grouping <g>5__1; // 0x0

	// Properties
	private IGrouping<T0, T1> System.Collections.Generic.IEnumerator<System.Linq.IGrouping<TKey,TElement>>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private IGrouping<T0, T1> System.Collections.Generic.IEnumerator<System.Linq.IGrouping<TKey,TElement>>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq
internal class Set<T0>
{
	// Fields
	private Int32[] buckets; // 0x0
	private Slot[] slots; // 0x0
	private Int32 count; // 0x0
	private Int32 freeList; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public Boolean Add(TElement value) { }

	// RVA: -1
	public Boolean Remove(TElement value) { }

	// RVA: -1
	private Boolean Find(TElement value, Boolean add) { }

	// RVA: -1
	private Void Resize() { }

	// RVA: -1
	internal Int32 InternalGetHashCode(TElement value) { }

}

// Namespace: 
internal struct Slot
{
	// Fields
	internal Int32 hashCode; // 0x0
	internal TElement value; // 0x0
	internal Int32 next; // 0x0
}

// Namespace: System.Linq
internal class GroupedEnumerable<T0, T1, T2>
{
	// Fields
	private IEnumerable<T0> source; // 0x0
	private Func<T0, T1> keySelector; // 0x0
	private Func<T0, T1> elementSelector; // 0x0
	private IEqualityComparer<T0> comparer; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(IEnumerable<T0> source, Func<T0, T1> keySelector, Func<T0, T1> elementSelector, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Linq
internal abstract class OrderedEnumerable<T0>
{
	// Fields
	internal IEnumerable<T0> source; // 0x0

	// Methods

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	internal abstract EnumerableSorter<T0> GetEnumerableSorter(EnumerableSorter<T0> next) { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private IOrderedEnumerable<T0> System.Linq.IOrderedEnumerable<TElement>.CreateOrderedEnumerable(Func<T0, T1> keySelector, IComparer<T0> comparer, Boolean descending) { }

	// RVA: -1
	protected Void .ctor() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__1
{
	// Fields
	private Int32 <>1__state; // 0x0
	private TElement <>2__current; // 0x0
	public OrderedEnumerable<T0> <>4__this; // 0x0
	private Buffer<T0> <buffer>5__1; // 0x0
	private Int32[] <map>5__2; // 0x0
	private Int32 <i>5__3; // 0x0

	// Properties
	private TElement System.Collections.Generic.IEnumerator<TElement>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private TElement System.Collections.Generic.IEnumerator<TElement>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq
internal class OrderedEnumerable<T0, T1>
{
	// Fields
	internal OrderedEnumerable<T0> parent; // 0x0
	internal Func<T0, T1> keySelector; // 0x0
	internal IComparer<T0> comparer; // 0x0
	internal Boolean descending; // 0x0

	// Methods

	// RVA: -1
	internal Void .ctor(IEnumerable<T0> source, Func<T0, T1> keySelector, IComparer<T0> comparer, Boolean descending) { }

	// RVA: -1
	internal override EnumerableSorter<T0> GetEnumerableSorter(EnumerableSorter<T0> next) { }

}

// Namespace: System.Linq
internal abstract class EnumerableSorter<T0>
{
	// Methods

	// RVA: -1
	internal abstract Void ComputeKeys(TElement[] elements, Int32 count) { }

	// RVA: -1
	internal abstract Int32 CompareKeys(Int32 index1, Int32 index2) { }

	// RVA: -1
	internal Int32[] Sort(TElement[] elements, Int32 count) { }

	// RVA: -1
	private Void QuickSort(Int32[] map, Int32 left, Int32 right) { }

	// RVA: -1
	protected Void .ctor() { }

}

// Namespace: System.Linq
internal class EnumerableSorter<T0, T1>
{
	// Fields
	internal Func<T0, T1> keySelector; // 0x0
	internal IComparer<T0> comparer; // 0x0
	internal Boolean descending; // 0x0
	internal EnumerableSorter<T0> next; // 0x0
	internal TKey[] keys; // 0x0

	// Methods

	// RVA: -1
	internal Void .ctor(Func<T0, T1> keySelector, IComparer<T0> comparer, Boolean descending, EnumerableSorter<T0> next) { }

	// RVA: -1
	internal override Void ComputeKeys(TElement[] elements, Int32 count) { }

	// RVA: -1
	internal override Int32 CompareKeys(Int32 index1, Int32 index2) { }

}

// Namespace: System.Linq
internal struct Buffer<T0>
{
	// Fields
	internal TElement[] items; // 0x0
	internal Int32 count; // 0x0

	// Methods

	// RVA: -1
	internal Void .ctor(IEnumerable<T0> source) { }

	// RVA: -1
	internal TElement[] ToArray() { }

}

// Namespace: System.Linq.Expressions
internal static class CachedReflectionInfo
{
	// Fields
	private static MethodInfo s_String_op_Equality_String_String; // 0x0
	private static MethodInfo s_Math_Pow_Double_Double; // 0x8

	// Properties
	public static MethodInfo String_op_Equality_String_String { get; }
	public static MethodInfo Math_Pow_Double_Double { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FD4E4
	public static MethodInfo get_String_op_Equality_String_String() { }

	// RVA: 0xFFFFFFFF759FD604
	public static MethodInfo get_Math_Pow_Double_Double() { }

}

// Namespace: System.Linq.Expressions
public class BinaryExpression
{
	// Fields
	private readonly Expression <Right>k__BackingField; // 0x10
	private readonly Expression <Left>k__BackingField; // 0x18

	// Properties
	public override Boolean CanReduce { get; }
	public Expression Right { get; }
	public Expression Left { get; }
	public MethodInfo Method { get; }
	public LambdaExpression Conversion { get; }
	public Boolean IsLifted { get; }
	public Boolean IsLiftedToNull { get; }
	internal Boolean IsLiftedLogical { get; }
	internal Boolean IsReferenceComparison { get; }

	// Methods

	// RVA: 0xFFFFFFFF759F8A48
	internal Void .ctor(Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF759F8B10
	public override Boolean get_CanReduce() { }

	// RVA: 0xFFFFFFFF759F8B3C
	private static Boolean IsOpAssignment(ExpressionType op) { }

	// RVA: 0xFFFFFFFF759F8B4C
	public Expression get_Right() { }

	// RVA: 0xFFFFFFFF759F8B54
	public Expression get_Left() { }

	// RVA: 0xFFFFFFFF759F8B5C
	public MethodInfo get_Method() { }

	// RVA: 0xFFFFFFFF759F8B6C
	internal virtual MethodInfo GetMethod() { }

	// RVA: 0xFFFFFFFF759F8B74
	public BinaryExpression Update(Expression left, LambdaExpression conversion, Expression right) { }

	// RVA: 0xFFFFFFFF759F9C00
	public override Expression Reduce() { }

	// RVA: 0xFFFFFFFF759FA47C
	private static ExpressionType GetBinaryOpFromAssignmentOp(ExpressionType op) { }

	// RVA: 0xFFFFFFFF759FA394
	private Expression ReduceVariable() { }

	// RVA: 0xFFFFFFFF759F9C98
	private Expression ReduceMember() { }

	// RVA: 0xFFFFFFFF759F9FC0
	private Expression ReduceIndex() { }

	// RVA: 0xFFFFFFFF759F8D04
	public LambdaExpression get_Conversion() { }

	// RVA: 0xFFFFFFFF759FAE48
	internal virtual LambdaExpression GetConversion() { }

	// RVA: 0xFFFFFFFF759FAE50
	public Boolean get_IsLifted() { }

	// RVA: 0xFFFFFFFF759F9050
	public Boolean get_IsLiftedToNull() { }

	// RVA: 0xFFFFFFFF759FAFA0
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF759FAFD0
	internal Boolean get_IsLiftedLogical() { }

	// RVA: 0xFFFFFFFF759F8D14
	internal Boolean get_IsReferenceComparison() { }

	// RVA: 0xFFFFFFFF759FB0D8
	internal Expression ReduceUserdefinedLifted() { }

}

// Namespace: System.Linq.Expressions
internal sealed class LogicalBinaryExpression
{
	// Fields
	private readonly ExpressionType <NodeType>k__BackingField; // 0x20

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D90C
	internal Void .ctor(ExpressionType nodeType, Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF75A4D940
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4D984
	public sealed override ExpressionType get_NodeType() { }

}

// Namespace: System.Linq.Expressions
internal class AssignBinaryExpression
{
	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }

	// Methods

	// RVA: 0xFFFFFFFF759F8A44
	internal Void .ctor(Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF759F8AD8
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF759F8B00
	public sealed override ExpressionType get_NodeType() { }

}

// Namespace: System.Linq.Expressions
internal sealed class CoalesceConversionBinaryExpression
{
	// Fields
	private readonly LambdaExpression _conversion; // 0x20

	// Properties
	public sealed override ExpressionType NodeType { get; }
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FDB38
	internal Void .ctor(Expression left, Expression right, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF759FDB68
	internal override LambdaExpression GetConversion() { }

	// RVA: 0xFFFFFFFF759FDB70
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF759FDB78
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
internal sealed class OpAssignMethodConversionBinaryExpression
{
	// Fields
	private readonly LambdaExpression _conversion; // 0x38

	// Methods

	// RVA: 0xFFFFFFFF75A4F894
	internal Void .ctor(ExpressionType nodeType, Expression left, Expression right, Type type, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A4F910
	internal override LambdaExpression GetConversion() { }

}

// Namespace: System.Linq.Expressions
internal class SimpleBinaryExpression
{
	// Fields
	private readonly ExpressionType <NodeType>k__BackingField; // 0x20
	private readonly Type <Type>k__BackingField; // 0x28

	// Properties
	public sealed override ExpressionType NodeType { get; }
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DD00
	internal Void .ctor(ExpressionType nodeType, Expression left, Expression right, Type type) { }

	// RVA: 0xFFFFFFFF75A50804
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A5080C
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
internal class MethodBinaryExpression
{
	// Fields
	private readonly MethodInfo _method; // 0x30

	// Methods

	// RVA: 0xFFFFFFFF75A4DCA0
	internal Void .ctor(ExpressionType nodeType, Expression left, Expression right, Type type, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A4DD4C
	internal override MethodInfo GetMethod() { }

}

// Namespace: System.Linq.Expressions
public abstract class Expression
{
	// Fields
	private static readonly CacheDict<T0, T1> s_lambdaDelegateCache; // 0x0
	private static CacheDict<T0, T1> s_lambdaFactories; // 0x8
	private static ConditionalWeakTable<T0, T1> s_legacyCtorSupportTable; // 0x10

	// Properties
	public virtual ExpressionType NodeType { get; }
	public virtual Type Type { get; }
	public virtual Boolean CanReduce { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FA6C8
	public static BinaryExpression Assign(Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF75A00E24
	private static BinaryExpression GetUserDefinedBinaryOperator(ExpressionType binaryType, String name, Expression left, Expression right, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A0125C
	private static BinaryExpression GetMethodBasedBinaryOperator(ExpressionType binaryType, Expression left, Expression right, MethodInfo method, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A018E4
	private static BinaryExpression GetMethodBasedAssignOperator(ExpressionType binaryType, Expression left, Expression right, MethodInfo method, LambdaExpression conversion, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A01D50
	private static BinaryExpression GetUserDefinedBinaryOperatorOrThrow(ExpressionType binaryType, String name, Expression left, Expression right, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A01F84
	private static BinaryExpression GetUserDefinedAssignOperatorOrThrow(ExpressionType binaryType, String name, Expression left, Expression right, LambdaExpression conversion, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A010FC
	private static MethodInfo GetUserDefinedBinaryOperator(ExpressionType binaryType, Type leftType, Type rightType, String name) { }

	// RVA: 0xFFFFFFFF75A021C4
	private static Boolean IsLiftingConditionalLogicalOperator(Type left, Type right, MethodInfo method, ExpressionType binaryType) { }

	// RVA: 0xFFFFFFFF75A017D0
	internal static Boolean ParameterIsAssignable(ParameterInfo pi, Type argType) { }

	// RVA: 0xFFFFFFFF75A01838
	private static Void ValidateParamswithOperandsOrThrow(Type paramType, Type operandType, ExpressionType exprType, String name) { }

	// RVA: 0xFFFFFFFF75A016B8
	private static Void ValidateOperator(MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A02234
	private static Void ValidateMethodInfo(MethodInfo method, String paramName) { }

	// RVA: 0xFFFFFFFF75A022DC
	private static Boolean IsNullComparison(Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF75A023A8
	private static Boolean IsNullConstant(Expression e) { }

	// RVA: 0xFFFFFFFF75A0242C
	private static Void ValidateUserDefinedConditionalLogicOperator(ExpressionType nodeType, Type left, Type right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A02960
	private static Void VerifyOpTrueFalse(ExpressionType nodeType, Type left, MethodInfo opTrue, String paramName) { }

	// RVA: 0xFFFFFFFF75A028D0
	private static Boolean IsValidLiftedConditionalLogicalOperator(Type left, Type right, ParameterInfo[] pms) { }

	// RVA: 0xFFFFFFFF759FA4E0
	public static BinaryExpression MakeBinary(ExpressionType binaryType, Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF759F9094
	public static BinaryExpression MakeBinary(ExpressionType binaryType, Expression left, Expression right, Boolean liftToNull, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A04D90
	public static BinaryExpression Equal(Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF759F8DF0
	public static BinaryExpression ReferenceEqual(Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF75A04EA0
	public static BinaryExpression NotEqual(Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF759F8F20
	public static BinaryExpression ReferenceNotEqual(Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF75A0779C
	private static BinaryExpression GetEqualityComparisonOperator(ExpressionType binaryType, String opName, Expression left, Expression right, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A04B70
	public static BinaryExpression GreaterThan(Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A04950
	public static BinaryExpression LessThan(Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A04C80
	public static BinaryExpression GreaterThanOrEqual(Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A04A60
	public static BinaryExpression LessThanOrEqual(Expression left, Expression right, Boolean liftToNull, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A07AEC
	private static BinaryExpression GetComparisonOperator(ExpressionType binaryType, String opName, Expression left, Expression right, Boolean liftToNull) { }

	// RVA: 0xFFFFFFFF75A03DBC
	public static BinaryExpression AndAlso(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A0444C
	public static BinaryExpression OrElse(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A051A0
	public static BinaryExpression Coalesce(Expression left, Expression right, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A07CD0
	private static Type ValidateCoalesceArgTypes(Type left, Type right) { }

	// RVA: 0xFFFFFFFF75A02AE8
	public static BinaryExpression Add(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A05AE8
	public static BinaryExpression AddAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A01B2C
	private static Void ValidateOpAssignConversionLambda(LambdaExpression conversion, Expression left, MethodInfo method, ExpressionType nodeType) { }

	// RVA: 0xFFFFFFFF75A07148
	public static BinaryExpression AddAssignChecked(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A02CD8
	public static BinaryExpression AddChecked(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A02EC8
	public static BinaryExpression Subtract(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06F2C
	public static BinaryExpression SubtractAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A07364
	public static BinaryExpression SubtractAssignChecked(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A030B8
	public static BinaryExpression SubtractChecked(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A03688
	public static BinaryExpression Divide(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A05F20
	public static BinaryExpression DivideAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A03878
	public static BinaryExpression Modulo(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06558
	public static BinaryExpression ModuloAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A032A8
	public static BinaryExpression Multiply(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06774
	public static BinaryExpression MultiplyAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A07580
	public static BinaryExpression MultiplyAssignChecked(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A03498
	public static BinaryExpression MultiplyChecked(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A07DAC
	private static Boolean IsSimpleShift(Type left, Type right) { }

	// RVA: 0xFFFFFFFF75A07E24
	private static Type GetResultTypeOfShift(Type left, Type right) { }

	// RVA: 0xFFFFFFFF75A05910
	public static BinaryExpression LeftShift(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06358
	public static BinaryExpression LeftShiftAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A05738
	public static BinaryExpression RightShift(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06D2C
	public static BinaryExpression RightShiftAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A03BCC
	public static BinaryExpression And(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A05D04
	public static BinaryExpression AndAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A0425C
	public static BinaryExpression Or(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06990
	public static BinaryExpression OrAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A04FB0
	public static BinaryExpression ExclusiveOr(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A0613C
	public static BinaryExpression ExclusiveOrAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A03A68
	public static BinaryExpression Power(Expression left, Expression right, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A06BAC
	public static BinaryExpression PowerAssign(Expression left, Expression right, MethodInfo method, LambdaExpression conversion) { }

	// RVA: 0xFFFFFFFF75A0559C
	public static BinaryExpression ArrayIndex(Expression array, Expression index) { }

	// RVA: 0xFFFFFFFF75A07EE4
	public static BlockExpression Block(Type type, Expression[] expressions) { }

	// RVA: 0xFFFFFFFF75A07F6C
	public static BlockExpression Block(Type type, IEnumerable<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A081D0
	public static BlockExpression Block(Type type, IEnumerable<T0> variables, Expression[] expressions) { }

	// RVA: 0xFFFFFFFF759FAACC
	public static BlockExpression Block(IEnumerable<T0> variables, IEnumerable<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A08010
	public static BlockExpression Block(Type type, IEnumerable<T0> variables, IEnumerable<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A08C90
	private static BlockExpression BlockCore(Type type, ReadOnlyCollection<T0> variables, ReadOnlyCollection<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A08F38
	internal static Void ValidateVariables(ReadOnlyCollection<T0> varList, String collectionName) { }

	// RVA: 0xFFFFFFFF75A0839C
	private static BlockExpression GetOptimizedBlockExpression(IReadOnlyList<T0> expressions) { }

	// RVA: 0xFFFFFFFF759FD914
	public static CatchBlock MakeCatchBlock(Type type, ParameterExpression variable, Expression body, Expression filter) { }

	// RVA: 0xFFFFFFFF759FBF3C
	public static ConditionalExpression Condition(Expression test, Expression ifTrue, Expression ifFalse) { }

	// RVA: 0xFFFFFFFF759FE040
	public static ConditionalExpression Condition(Expression test, Expression ifTrue, Expression ifFalse, Type type) { }

	// RVA: 0xFFFFFFFF75A090B8
	public static ConstantExpression Constant(Object value) { }

	// RVA: 0xFFFFFFFF759FBD6C
	public static ConstantExpression Constant(Object value, Type type) { }

	// RVA: 0xFFFFFFFF75A09110
	public static DefaultExpression Empty() { }

	// RVA: 0xFFFFFFFF759F8B08
	protected Void .ctor() { }

	// RVA: 0xFFFFFFFF75A09198
	public virtual ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A09270
	public virtual Type get_Type() { }

	// RVA: 0xFFFFFFFF75A09348
	public virtual Boolean get_CanReduce() { }

	// RVA: 0xFFFFFFFF75A09350
	public virtual Expression Reduce() { }

	// RVA: 0xFFFFFFFF75A093B8
	protected internal virtual Expression VisitChildren(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A09524
	protected internal virtual Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A0944C
	public Expression ReduceAndCheck() { }

	// RVA: 0xFFFFFFFF75A09554
	public override String ToString() { }

	// RVA: 0xFFFFFFFF75A08244
	private static Void RequiresCanRead(IReadOnlyList<T0> items, String paramName) { }

	// RVA: 0xFFFFFFFF75A00BEC
	private static Void RequiresCanWrite(Expression expression, String paramName) { }

	// RVA: 0xFFFFFFFF75A095D0
	public static GotoExpression Goto(LabelTarget target, Expression value) { }

	// RVA: 0xFFFFFFFF75A09678
	public static GotoExpression MakeGoto(GotoExpressionKind kind, LabelTarget target, Expression value, Type type) { }

	// RVA: 0xFFFFFFFF75A09740
	private static Void ValidateGoto(LabelTarget target, ref Expression value, String targetParameter, String valueParameter, Type type) { }

	// RVA: 0xFFFFFFFF75A09958
	private static Void ValidateGotoType(Type expectedType, ref Expression value, String paramName) { }

	// RVA: 0xFFFFFFFF759FAD94
	public static IndexExpression MakeIndex(Expression instance, PropertyInfo indexer, IEnumerable<T0> arguments) { }

	// RVA: 0xFFFFFFFF75A09EDC
	public static IndexExpression ArrayAccess(Expression array, Expression[] indexes) { }

	// RVA: 0xFFFFFFFF75A09B30
	public static IndexExpression ArrayAccess(Expression array, IEnumerable<T0> indexes) { }

	// RVA: 0xFFFFFFFF75A09A88
	public static IndexExpression Property(Expression instance, PropertyInfo indexer, IEnumerable<T0> arguments) { }

	// RVA: 0xFFFFFFFF75A0A004
	private static IndexExpression MakeIndexProperty(Expression instance, PropertyInfo indexer, String paramName, ReadOnlyCollection<T0> argList) { }

	// RVA: 0xFFFFFFFF75A0A0BC
	private static Void ValidateIndexedProperty(Expression instance, PropertyInfo indexer, String paramName, ref ReadOnlyCollection<T0> argList) { }

	// RVA: 0xFFFFFFFF75A0A584
	private static Void ValidateAccessor(Expression instance, MethodInfo method, ParameterInfo[] indexes, ref ReadOnlyCollection<T0> arguments, String paramName) { }

	// RVA: 0xFFFFFFFF75A0A768
	private static Void ValidateAccessorArgumentTypes(MethodInfo method, ParameterInfo[] indexes, ref ReadOnlyCollection<T0> arguments, String paramName) { }

	// RVA: 0xFFFFFFFF759FA570
	internal static InvocationExpression Invoke(Expression expression, Expression arg0) { }

	// RVA: 0xFFFFFFFF75A0AAE4
	internal static MethodInfo GetInvokeMethod(Expression expression) { }

	// RVA: 0xFFFFFFFF75A0AC9C
	public static LabelExpression Label(LabelTarget target, Expression defaultValue) { }

	// RVA: 0xFFFFFFFF75A0AD5C
	public static LabelTarget Label(Type type, String name) { }

	// RVA: 0xFFFFFFFF75A0ADEC
	internal static LambdaExpression CreateLambda(Type delegateType, Expression body, String name, Boolean tailCall, ReadOnlyCollection<T0> parameters) { }

	// RVA: -1
	public static Expression<T0> Lambda(Expression body, ParameterExpression[] parameters) { }

	// RVA: -1
	public static Expression<T0> Lambda(Expression body, Boolean tailCall, IEnumerable<T0> parameters) { }

	// RVA: -1
	public static Expression<T0> Lambda(Expression body, String name, Boolean tailCall, IEnumerable<T0> parameters) { }

	// RVA: 0xFFFFFFFF75A0B140
	public static LambdaExpression Lambda(Type delegateType, Expression body, ParameterExpression[] parameters) { }

	// RVA: 0xFFFFFFFF75A0B1BC
	public static LambdaExpression Lambda(Type delegateType, Expression body, String name, Boolean tailCall, IEnumerable<T0> parameters) { }

	// RVA: 0xFFFFFFFF75A0B298
	private static Void ValidateLambdaArgs(Type delegateType, ref Expression body, ReadOnlyCollection<T0> parameters, String paramName) { }

	// RVA: 0xFFFFFFFF75A0B824
	public static MemberExpression Field(Expression expression, FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A0B988
	public static MemberExpression Field(Expression expression, String fieldName) { }

	// RVA: 0xFFFFFFFF759FB770
	public static MemberExpression Property(Expression expression, String propertyName) { }

	// RVA: 0xFFFFFFFF75A0BAEC
	public static MemberExpression Property(Expression expression, PropertyInfo property) { }

	// RVA: 0xFFFFFFFF75A0BD28
	private static PropertyInfo GetProperty(MethodInfo mi, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF75A0BF64
	private static Boolean CheckMethod(MethodInfo method, MethodInfo propertyMethod) { }

	// RVA: 0xFFFFFFFF759FA930
	public static MemberExpression MakeMemberAccess(Expression expression, MemberInfo member) { }

	// RVA: 0xFFFFFFFF75A0C054
	internal static MethodCallExpression Call(MethodInfo method) { }

	// RVA: 0xFFFFFFFF759FBA48
	public static MethodCallExpression Call(MethodInfo method, Expression arg0) { }

	// RVA: 0xFFFFFFFF759FBB74
	public static MethodCallExpression Call(MethodInfo method, Expression arg0, Expression arg1) { }

	// RVA: 0xFFFFFFFF75A0C190
	public static MethodCallExpression Call(MethodInfo method, Expression arg0, Expression arg1, Expression arg2) { }

	// RVA: 0xFFFFFFFF75A0C374
	public static MethodCallExpression Call(MethodInfo method, Expression arg0, Expression arg1, Expression arg2, Expression arg3) { }

	// RVA: 0xFFFFFFFF75A0C5B0
	public static MethodCallExpression Call(MethodInfo method, Expression arg0, Expression arg1, Expression arg2, Expression arg3, Expression arg4) { }

	// RVA: 0xFFFFFFFF75A0C848
	public static MethodCallExpression Call(MethodInfo method, IEnumerable<T0> arguments) { }

	// RVA: 0xFFFFFFFF75A0D2D0
	public static MethodCallExpression Call(Expression instance, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A0D404
	public static MethodCallExpression Call(Expression instance, MethodInfo method, Expression[] arguments) { }

	// RVA: 0xFFFFFFFF75A0D478
	internal static MethodCallExpression Call(Expression instance, MethodInfo method, Expression arg0) { }

	// RVA: 0xFFFFFFFF75A0D648
	public static MethodCallExpression Call(Expression instance, MethodInfo method, Expression arg0, Expression arg1) { }

	// RVA: 0xFFFFFFFF75A0D870
	public static MethodCallExpression Call(Expression instance, MethodInfo method, Expression arg0, Expression arg1, Expression arg2) { }

	// RVA: 0xFFFFFFFF759FB8C8
	public static MethodCallExpression Call(Expression instance, String methodName, Type[] typeArguments, Expression[] arguments) { }

	// RVA: 0xFFFFFFFF75A0C8B8
	public static MethodCallExpression Call(Expression instance, MethodInfo method, IEnumerable<T0> arguments) { }

	// RVA: 0xFFFFFFFF75A0C108
	private static ParameterInfo[] ValidateMethodAndGetParameters(Expression instance, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A0DD3C
	private static Void ValidateStaticOrInstanceMethod(Expression instance, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A0A6D8
	private static Void ValidateCallInstanceType(Type instanceType, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A0DE20
	private static Void ValidateArgumentTypes(MethodBase method, ExpressionType nodeKind, ref ReadOnlyCollection<T0> arguments, String methodParamName) { }

	// RVA: 0xFFFFFFFF75A0AC8C
	private static ParameterInfo[] GetParametersForValidation(MethodBase method, ExpressionType nodeKind) { }

	// RVA: 0xFFFFFFFF75A0AC90
	private static Void ValidateArgumentCount(MethodBase method, ExpressionType nodeKind, Int32 count, ParameterInfo[] pis) { }

	// RVA: 0xFFFFFFFF75A0AC94
	private static Expression ValidateOneArgument(MethodBase method, ExpressionType nodeKind, Expression arg, ParameterInfo pi, String methodParamName, String argumentParamName) { }

	// RVA: 0xFFFFFFFF75A09A84
	private static Boolean TryQuote(Type parameterType, ref Expression argument) { }

	// RVA: 0xFFFFFFFF75A0DB14
	private static MethodInfo FindMethod(Type type, String methodName, Type[] typeArgs, Expression[] args, BindingFlags flags) { }

	// RVA: 0xFFFFFFFF75A0DF2C
	private static Boolean IsCompatible(MethodBase m, Expression[] arguments) { }

	// RVA: 0xFFFFFFFF75A0DE74
	private static MethodInfo ApplyTypeArgs(MethodInfo m, Type[] typeArgs) { }

	// RVA: 0xFFFFFFFF75A0E12C
	public static NewArrayExpression NewArrayInit(Type type, Expression[] initializers) { }

	// RVA: 0xFFFFFFFF75A0E198
	public static NewArrayExpression NewArrayInit(Type type, IEnumerable<T0> initializers) { }

	// RVA: 0xFFFFFFFF75A0E528
	public static NewArrayExpression NewArrayBounds(Type type, IEnumerable<T0> bounds) { }

	// RVA: 0xFFFFFFFF75A0E730
	public static NewExpression New(ConstructorInfo constructor, Expression[] arguments) { }

	// RVA: 0xFFFFFFFF75A0E79C
	public static NewExpression New(ConstructorInfo constructor, IEnumerable<T0> arguments) { }

	// RVA: 0xFFFFFFFF75A0E998
	public static NewExpression New(ConstructorInfo constructor, IEnumerable<T0> arguments, IEnumerable<T0> members) { }

	// RVA: 0xFFFFFFFF75A0EB48
	private static Void ValidateNewArgs(ConstructorInfo constructor, ref ReadOnlyCollection<T0> arguments, ref ReadOnlyCollection<T0> members) { }

	// RVA: 0xFFFFFFFF75A0F1C8
	private static Void ValidateAnonymousTypeMember(ref MemberInfo member, out Type memberType, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF75A0E924
	private static Void ValidateConstructor(ConstructorInfo constructor, String paramName) { }

	// RVA: 0xFFFFFFFF75A0F448
	public static ParameterExpression Parameter(Type type) { }

	// RVA: 0xFFFFFFFF759FB6BC
	public static ParameterExpression Parameter(Type type, String name) { }

	// RVA: 0xFFFFFFFF759FA8B0
	public static ParameterExpression Variable(Type type, String name) { }

	// RVA: 0xFFFFFFFF75A0F4A8
	private static Void Validate(Type type, Boolean allowByRef) { }

	// RVA: 0xFFFFFFFF75A0F56C
	public static TryExpression TryFinally(Expression body, Expression finally) { }

	// RVA: 0xFFFFFFFF75A0F5E4
	public static TryExpression MakeTry(Type type, Expression body, Expression finally, Expression fault, IEnumerable<T0> handlers) { }

	// RVA: 0xFFFFFFFF75A0F7F8
	private static Void ValidateTryAndCatchHaveSameType(Type type, Expression tryBody, ReadOnlyCollection<T0> handlers) { }

	// RVA: 0xFFFFFFFF75A0FFA0
	public static UnaryExpression MakeUnary(ExpressionType unaryType, Expression operand, Type type, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11D04
	private static UnaryExpression GetUserDefinedUnaryOperatorOrThrow(ExpressionType unaryType, String name, Expression operand) { }

	// RVA: 0xFFFFFFFF75A11E94
	private static UnaryExpression GetUserDefinedUnaryOperator(ExpressionType unaryType, String name, Expression operand) { }

	// RVA: 0xFFFFFFFF75A120AC
	private static UnaryExpression GetMethodBasedUnaryOperator(ExpressionType unaryType, Expression operand, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A1238C
	private static UnaryExpression GetUserDefinedCoercionOrThrow(ExpressionType coercionType, Expression expression, Type convertToType) { }

	// RVA: 0xFFFFFFFF75A12444
	private static UnaryExpression GetUserDefinedCoercion(ExpressionType coercionType, Expression expression, Type convertToType) { }

	// RVA: 0xFFFFFFFF75A12500
	private static UnaryExpression GetMethodBasedCoercionOperator(ExpressionType unaryType, Expression operand, Type convertToType, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A10590
	public static UnaryExpression Negate(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11570
	public static UnaryExpression UnaryPlus(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A1071C
	public static UnaryExpression NegateChecked(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A108A8
	public static UnaryExpression Not(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A10A40
	public static UnaryExpression IsFalse(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A10BB0
	public static UnaryExpression IsTrue(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A10D20
	public static UnaryExpression OnesComplement(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11470
	public static UnaryExpression TypeAs(Expression expression, Type type) { }

	// RVA: 0xFFFFFFFF75A116E0
	public static UnaryExpression Unbox(Expression expression, Type type) { }

	// RVA: 0xFFFFFFFF759FBCFC
	public static UnaryExpression Convert(Expression expression, Type type) { }

	// RVA: 0xFFFFFFFF75A11030
	public static UnaryExpression Convert(Expression expression, Type type, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A111C8
	public static UnaryExpression ConvertChecked(Expression expression, Type type, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A10E90
	public static UnaryExpression ArrayLength(Expression array) { }

	// RVA: 0xFFFFFFFF759F4D84
	public static UnaryExpression Quote(Expression expression) { }

	// RVA: 0xFFFFFFFF75A11378
	public static UnaryExpression Throw(Expression value, Type type) { }

	// RVA: 0xFFFFFFFF75A11864
	public static UnaryExpression Increment(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A119D4
	public static UnaryExpression Decrement(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11B44
	public static UnaryExpression PreIncrementAssign(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11C24
	public static UnaryExpression PreDecrementAssign(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11BB4
	public static UnaryExpression PostIncrementAssign(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A11C94
	public static UnaryExpression PostDecrementAssign(Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A127A4
	private static UnaryExpression MakeOpAssignUnary(ExpressionType kind, Expression expression, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A129D0
	private static Void .cctor() { }

}

// Namespace: 
internal class BinaryExpressionProxy
{}

// Namespace: 
internal class BlockExpressionProxy
{}

// Namespace: 
internal class CatchBlockProxy
{}

// Namespace: 
internal class ConditionalExpressionProxy
{}

// Namespace: 
internal class ConstantExpressionProxy
{}

// Namespace: 
internal class DebugInfoExpressionProxy
{}

// Namespace: 
internal class DefaultExpressionProxy
{}

// Namespace: 
internal class GotoExpressionProxy
{}

// Namespace: 
internal class IndexExpressionProxy
{}

// Namespace: 
internal class InvocationExpressionProxy
{}

// Namespace: 
internal class LabelExpressionProxy
{}

// Namespace: 
internal class LambdaExpressionProxy
{}

// Namespace: 
internal class ListInitExpressionProxy
{}

// Namespace: 
internal class LoopExpressionProxy
{}

// Namespace: 
internal class MemberExpressionProxy
{}

// Namespace: 
internal class MemberInitExpressionProxy
{}

// Namespace: 
internal class MethodCallExpressionProxy
{}

// Namespace: 
internal class NewArrayExpressionProxy
{}

// Namespace: 
internal class NewExpressionProxy
{}

// Namespace: 
internal class ParameterExpressionProxy
{}

// Namespace: 
internal class RuntimeVariablesExpressionProxy
{}

// Namespace: 
internal class SwitchCaseProxy
{}

// Namespace: 
internal class SwitchExpressionProxy
{}

// Namespace: 
internal class TryExpressionProxy
{}

// Namespace: 
internal class TypeBinaryExpressionProxy
{}

// Namespace: 
internal class UnaryExpressionProxy
{}

// Namespace: 
private class ExtensionInfo
{
	// Fields
	internal readonly ExpressionType NodeType; // 0x10
	internal readonly Type Type; // 0x18
}

// Namespace: System.Linq.Expressions
public class BlockExpression
{
	// Properties
	public ReadOnlyCollection<T0> Expressions { get; }
	public ReadOnlyCollection<T0> Variables { get; }
	public sealed override ExpressionType NodeType { get; }
	public override Type Type { get; }
	internal virtual Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FCA40
	public ReadOnlyCollection<T0> get_Expressions() { }

	// RVA: 0xFFFFFFFF759FCA50
	public ReadOnlyCollection<T0> get_Variables() { }

	// RVA: 0xFFFFFFFF759FC124
	internal Void .ctor() { }

	// RVA: 0xFFFFFFFF759FCA60
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF759FCA90
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF759FCA98
	public override Type get_Type() { }

	// RVA: 0xFFFFFFFF759FCAF0
	internal virtual Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF759FCB2C
	internal virtual Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF759FCB68
	internal virtual ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF759FCBA4
	internal virtual ReadOnlyCollection<T0> GetOrMakeVariables() { }

	// RVA: 0xFFFFFFFF759FCC04
	internal virtual BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

	// RVA: 0xFFFFFFFF759FC268
	internal static ReadOnlyCollection<T0> ReturnReadOnlyExpressions(BlockExpression provider, ref Object collection) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block2
{
	// Fields
	private Object _arg0; // 0x10
	private readonly Expression _arg1; // 0x18

	// Properties
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FC0D8
	internal Void .ctor(Expression arg0, Expression arg1) { }

	// RVA: 0xFFFFFFFF759FC184
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF759FC258
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF759FC260
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF759FC3C4
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block3
{
	// Fields
	private Object _arg0; // 0x10
	private readonly Expression _arg1; // 0x18
	private readonly Expression _arg2; // 0x20

	// Properties
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FC468
	internal Void .ctor(Expression arg0, Expression arg1, Expression arg2) { }

	// RVA: 0xFFFFFFFF759FC4C8
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF759FC570
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF759FC578
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF759FC580
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block4
{
	// Fields
	private Object _arg0; // 0x10
	private readonly Expression _arg1; // 0x18
	private readonly Expression _arg2; // 0x20
	private readonly Expression _arg3; // 0x28

	// Properties
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FC61C
	internal Void .ctor(Expression arg0, Expression arg1, Expression arg2, Expression arg3) { }

	// RVA: 0xFFFFFFFF759FC698
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF759FC758
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF759FC760
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF759FC768
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block5
{
	// Fields
	private Object _arg0; // 0x10
	private readonly Expression _arg1; // 0x18
	private readonly Expression _arg2; // 0x20
	private readonly Expression _arg3; // 0x28
	private readonly Expression _arg4; // 0x30

	// Properties
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FC818
	internal Void .ctor(Expression arg0, Expression arg1, Expression arg2, Expression arg3, Expression arg4) { }

	// RVA: 0xFFFFFFFF759FC8A8
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF759FC970
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF759FC978
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF759FC980
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal class BlockN
{
	// Fields
	private IReadOnlyList<T0> _expressions; // 0x10

	// Properties
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FD2A0
	internal Void .ctor(IReadOnlyList<T0> expressions) { }

	// RVA: 0xFFFFFFFF759FD2D0
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF759FD384
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF759FD428
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF759FD470
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal class ScopeExpression
{
	// Fields
	private IReadOnlyList<T0> _variables; // 0x10

	// Properties
	protected IReadOnlyList<T0> VariablesList { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A5010C
	internal Void .ctor(IReadOnlyList<T0> variables) { }

	// RVA: 0xFFFFFFFF75A50378
	internal override ReadOnlyCollection<T0> GetOrMakeVariables() { }

	// RVA: 0xFFFFFFFF75A503C0
	protected IReadOnlyList<T0> get_VariablesList() { }

	// RVA: 0xFFFFFFFF75A502D8
	internal IReadOnlyList<T0> ReuseOrValidateVariables(ReadOnlyCollection<T0> variables) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Scope1
{
	// Fields
	private Object _body; // 0x18

	// Properties
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A5006C
	internal Void .ctor(IReadOnlyList<T0> variables, Expression body) { }

	// RVA: 0xFFFFFFFF75A500BC
	private Void .ctor(IReadOnlyList<T0> variables, Object body) { }

	// RVA: 0xFFFFFFFF75A50140
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF75A501C0
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF75A501C8
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF75A501D4
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal class ScopeN
{
	// Fields
	private IReadOnlyList<T0> _body; // 0x18

	// Properties
	protected IReadOnlyList<T0> Body { get; }
	internal override Int32 ExpressionCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A503C8
	internal Void .ctor(IReadOnlyList<T0> variables, IReadOnlyList<T0> body) { }

	// RVA: 0xFFFFFFFF75A50418
	protected IReadOnlyList<T0> get_Body() { }

	// RVA: 0xFFFFFFFF75A50420
	internal override Expression GetExpression(Int32 index) { }

	// RVA: 0xFFFFFFFF75A504D4
	internal override Int32 get_ExpressionCount() { }

	// RVA: 0xFFFFFFFF75A50578
	internal override ReadOnlyCollection<T0> GetOrMakeExpressions() { }

	// RVA: 0xFFFFFFFF75A505C0
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class ScopeWithType
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x20

	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A506AC
	internal Void .ctor(IReadOnlyList<T0> variables, IReadOnlyList<T0> expressions, Type type) { }

	// RVA: 0xFFFFFFFF75A50710
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A50718
	internal override BlockExpression Rewrite(ReadOnlyCollection<T0> variables, Expression[] args) { }

}

// Namespace: System.Linq.Expressions
internal class BlockExpressionList
{
	// Fields
	private readonly BlockExpression _block; // 0x10
	private readonly Expression _arg0; // 0x18

	// Properties
	public Expression Item { get; set; }
	public Int32 Count { get; }
	public Boolean IsReadOnly { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FCC40
	internal Void .ctor(BlockExpression provider, Expression arg0) { }

	// RVA: 0xFFFFFFFF759FCC90
	public Int32 IndexOf(Expression item) { }

	// RVA: 0xFFFFFFFF759FCD2C
	public Void Insert(Int32 index, Expression item) { }

	// RVA: 0xFFFFFFFF759FCD68
	public Void RemoveAt(Int32 index) { }

	// RVA: 0xFFFFFFFF759FCDA4
	public Expression get_Item(Int32 index) { }

	// RVA: 0xFFFFFFFF759FCDDC
	public Void set_Item(Int32 index, Expression value) { }

	// RVA: 0xFFFFFFFF759FCE18
	public Void Add(Expression item) { }

	// RVA: 0xFFFFFFFF759FCE54
	public Void Clear() { }

	// RVA: 0xFFFFFFFF759FCE90
	public Boolean Contains(Expression item) { }

	// RVA: 0xFFFFFFFF759FCEAC
	public Void CopyTo(Expression[] array, Int32 index) { }

	// RVA: 0xFFFFFFFF759FD00C
	public Int32 get_Count() { }

	// RVA: 0xFFFFFFFF759FD034
	public Boolean get_IsReadOnly() { }

	// RVA: 0xFFFFFFFF759FD070
	public Boolean Remove(Expression item) { }

	// RVA: 0xFFFFFFFF759FD0AC
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: 0xFFFFFFFF759FD144
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__18
{
	// Fields
	private Int32 <>1__state; // 0x10
	private Expression <>2__current; // 0x18
	public BlockExpressionList <>4__this; // 0x20
	private Int32 <i>5__1; // 0x28

	// Properties
	private Expression System.Collections.Generic.IEnumerator<System.Linq.Expressions.Expression>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FD118
	public Void .ctor(Int32 <>1__state) { }

	// RVA: 0xFFFFFFFF759FD148
	private Void System.IDisposable.Dispose() { }

	// RVA: 0xFFFFFFFF759FD14C
	private Boolean MoveNext() { }

	// RVA: 0xFFFFFFFF759FD23C
	private Expression System.Collections.Generic.IEnumerator<System.Linq.Expressions.Expression>.get_Current() { }

	// RVA: 0xFFFFFFFF759FD244
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: 0xFFFFFFFF759FD298
	private Object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq.Expressions
public sealed class CatchBlock
{
	// Fields
	private readonly ParameterExpression <Variable>k__BackingField; // 0x10
	private readonly Type <Test>k__BackingField; // 0x18
	private readonly Expression <Body>k__BackingField; // 0x20
	private readonly Expression <Filter>k__BackingField; // 0x28

	// Properties
	public ParameterExpression Variable { get; }
	public Type Test { get; }
	public Expression Body { get; }
	public Expression Filter { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FD734
	internal Void .ctor(Type test, ParameterExpression variable, Expression body, Expression filter) { }

	// RVA: 0xFFFFFFFF759FD7B4
	public ParameterExpression get_Variable() { }

	// RVA: 0xFFFFFFFF759FD7BC
	public Type get_Test() { }

	// RVA: 0xFFFFFFFF759FD7C4
	public Expression get_Body() { }

	// RVA: 0xFFFFFFFF759FD7CC
	public Expression get_Filter() { }

	// RVA: 0xFFFFFFFF759FD7D4
	public override String ToString() { }

	// RVA: 0xFFFFFFFF759FD850
	public CatchBlock Update(ParameterExpression variable, Expression filter, Expression body) { }

}

// Namespace: System.Linq.Expressions
internal static class ArrayBuilderExtensions
{
	// Methods

	// RVA: -1
	public static ReadOnlyCollection<T0> ToReadOnly(ArrayBuilder<T0> builder) { }

}

// Namespace: System.Linq.Expressions
internal enum AnalyzeTypeIsResult
{
	// Fields
	public Int32 value__; // 0x10
	public const AnalyzeTypeIsResult KnownFalse = 0;
	public const AnalyzeTypeIsResult KnownTrue = 1;
	public const AnalyzeTypeIsResult KnownAssignable = 2;
	public const AnalyzeTypeIsResult Unknown = 3;
}

// Namespace: System.Linq.Expressions
internal static class ConstantCheck
{
	// Methods

	// RVA: 0xFFFFFFFF759FE214
	internal static AnalyzeTypeIsResult AnalyzeTypeIs(TypeBinaryExpression typeIs) { }

	// RVA: 0xFFFFFFFF759FE234
	private static AnalyzeTypeIsResult AnalyzeTypeIs(Expression operand, Type testType) { }

}

// Namespace: System.Linq.Expressions
public class ConditionalExpression
{
	// Fields
	private readonly Expression <Test>k__BackingField; // 0x10
	private readonly Expression <IfTrue>k__BackingField; // 0x18

	// Properties
	public sealed override ExpressionType NodeType { get; }
	public override Type Type { get; }
	public Expression Test { get; }
	public Expression IfTrue { get; }
	public Expression IfFalse { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FDBA0
	internal Void .ctor(Expression test, Expression ifTrue) { }

	// RVA: 0xFFFFFFFF759FDC30
	internal static ConditionalExpression Make(Expression test, Expression ifTrue, Expression ifFalse, Type type) { }

	// RVA: 0xFFFFFFFF759FDE78
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF759FDE80
	public override Type get_Type() { }

	// RVA: 0xFFFFFFFF759FDEA8
	public Expression get_Test() { }

	// RVA: 0xFFFFFFFF759FDEB0
	public Expression get_IfTrue() { }

	// RVA: 0xFFFFFFFF759FDEB8
	public Expression get_IfFalse() { }

	// RVA: 0xFFFFFFFF759FDEC8
	internal virtual Expression GetFalse() { }

	// RVA: 0xFFFFFFFF759FDF28
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF759FDF58
	public ConditionalExpression Update(Expression test, Expression ifTrue, Expression ifFalse) { }

}

// Namespace: System.Linq.Expressions
internal class FullConditionalExpression
{
	// Fields
	private readonly Expression _false; // 0x20

	// Methods

	// RVA: 0xFFFFFFFF759FDE48
	internal Void .ctor(Expression test, Expression ifTrue, Expression ifFalse) { }

	// RVA: 0xFFFFFFFF75A15BB4
	internal override Expression GetFalse() { }

}

// Namespace: System.Linq.Expressions
internal sealed class FullConditionalExpressionWithType
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x28

	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FDDFC
	internal Void .ctor(Expression test, Expression ifTrue, Expression ifFalse, Type type) { }

	// RVA: 0xFFFFFFFF75A15BBC
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
public class ConstantExpression
{
	// Fields
	private readonly Object <Value>k__BackingField; // 0x10

	// Properties
	public override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public Object Value { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FE35C
	internal Void .ctor(Object value) { }

	// RVA: 0xFFFFFFFF759FE3D8
	public override Type get_Type() { }

	// RVA: 0xFFFFFFFF759FE434
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF759FE43C
	public Object get_Value() { }

	// RVA: 0xFFFFFFFF759FE444
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

}

// Namespace: System.Linq.Expressions
internal class TypedConstantExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x18

	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A52C68
	internal Void .ctor(Object value, Type type) { }

	// RVA: 0xFFFFFFFF75A52C9C
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
public class DebugInfoExpression
{
	// Fields
	private readonly SymbolDocumentInfo <Document>k__BackingField; // 0x10

	// Properties
	public virtual Int32 StartLine { get; }
	public virtual Int32 EndLine { get; }
	public SymbolDocumentInfo Document { get; }
	public virtual Boolean IsClear { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FE474
	public virtual Int32 get_StartLine() { }

	// RVA: 0xFFFFFFFF759FE4B0
	public virtual Int32 get_EndLine() { }

	// RVA: 0xFFFFFFFF759FE4EC
	public SymbolDocumentInfo get_Document() { }

	// RVA: 0xFFFFFFFF759FE4F4
	public virtual Boolean get_IsClear() { }

}

// Namespace: System.Linq.Expressions
public sealed class DefaultExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x10

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FE530
	internal Void .ctor(Type type) { }

	// RVA: 0xFFFFFFFF759FE5AC
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF759FE5B4
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF759FE5BC
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

}

// Namespace: System.Linq.Expressions
public sealed class ElementInit
{
	// Fields
	private readonly MethodInfo <AddMethod>k__BackingField; // 0x10
	private readonly ReadOnlyCollection<T0> <Arguments>k__BackingField; // 0x18

	// Properties
	public MethodInfo AddMethod { get; }
	public ReadOnlyCollection<T0> Arguments { get; }
	public Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF759FE5EC
	public MethodInfo get_AddMethod() { }

	// RVA: 0xFFFFFFFF759FE5F4
	public ReadOnlyCollection<T0> get_Arguments() { }

	// RVA: 0xFFFFFFFF759FE5FC
	public Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF759FE65C
	public Int32 get_ArgumentCount() { }

}

// Namespace: System.Linq.Expressions
internal static class Error
{
	// Methods

	// RVA: 0xFFFFFFFF759FE6AC
	internal static Exception ReducibleMustOverrideReduce() { }

	// RVA: 0xFFFFFFFF759FE6F0
	internal static Exception CollectionModifiedWhileEnumerating() { }

	// RVA: 0xFFFFFFFF759FE734
	internal static Exception MustReduceToDifferent() { }

	// RVA: 0xFFFFFFFF759FE778
	internal static Exception ReducedNotCompatible() { }

	// RVA: 0xFFFFFFFF759FE7BC
	internal static Exception SetterHasNoParams(String paramName) { }

	// RVA: 0xFFFFFFFF759FE810
	internal static Exception PropertyCannotHaveRefType(String paramName) { }

	// RVA: 0xFFFFFFFF759FE864
	internal static Exception IndexesOfSetGetMustMatch(String paramName) { }

	// RVA: 0xFFFFFFFF759FE8B8
	internal static Exception AccessorsCannotHaveVarArgs(String paramName) { }

	// RVA: 0xFFFFFFFF759FE90C
	private static Exception AccessorsCannotHaveByRefArgs(String paramName) { }

	// RVA: 0xFFFFFFFF759FE960
	internal static Exception AccessorsCannotHaveByRefArgs(String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FEA40
	internal static Exception BoundsCannotBeLessThanOne(String paramName) { }

	// RVA: 0xFFFFFFFF759F79A0
	internal static Exception TypeMustNotBeByRef(String paramName) { }

	// RVA: 0xFFFFFFFF759F79F4
	internal static Exception TypeMustNotBePointer(String paramName) { }

	// RVA: 0xFFFFFFFF759FEA94
	internal static Exception SetterMustBeVoid(String paramName) { }

	// RVA: 0xFFFFFFFF759FEAE8
	internal static Exception PropertyTypeMustMatchGetter(String paramName) { }

	// RVA: 0xFFFFFFFF759FEB3C
	internal static Exception PropertyTypeMustMatchSetter(String paramName) { }

	// RVA: 0xFFFFFFFF759FEB90
	internal static Exception BothAccessorsMustBeStatic(String paramName) { }

	// RVA: 0xFFFFFFFF759FEBE4
	internal static Exception OnlyStaticFieldsHaveNullInstance(String paramName) { }

	// RVA: 0xFFFFFFFF759FEC38
	internal static Exception OnlyStaticPropertiesHaveNullInstance(String paramName) { }

	// RVA: 0xFFFFFFFF759FEC8C
	internal static Exception OnlyStaticMethodsHaveNullInstance() { }

	// RVA: 0xFFFFFFFF759FECD0
	internal static Exception PropertyTypeCannotBeVoid(String paramName) { }

	// RVA: 0xFFFFFFFF759FED24
	internal static Exception InvalidUnboxType(String paramName) { }

	// RVA: 0xFFFFFFFF759FED78
	internal static Exception ExpressionMustBeWriteable(String paramName) { }

	// RVA: 0xFFFFFFFF759FEDCC
	internal static Exception ArgumentMustNotHaveValueType(String paramName) { }

	// RVA: 0xFFFFFFFF759FEE20
	internal static Exception MustBeReducible() { }

	// RVA: 0xFFFFFFFF759FEE64
	internal static Exception LabelMustBeVoidOrHaveExpression(String paramName) { }

	// RVA: 0xFFFFFFFF759FEEB8
	internal static Exception QuotedExpressionMustBeLambda(String paramName) { }

	// RVA: 0xFFFFFFFF759FEF0C
	internal static Exception VariableMustNotBeByRef(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF759FEF60
	internal static Exception VariableMustNotBeByRef(Object p0, Object p1, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FEFD0
	private static Exception DuplicateVariable(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FF024
	internal static Exception DuplicateVariable(Object p0, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FF08C
	internal static Exception FaultCannotHaveCatchOrFinally(String paramName) { }

	// RVA: 0xFFFFFFFF759FF0E0
	internal static Exception TryMustHaveCatchFinallyOrFault() { }

	// RVA: 0xFFFFFFFF759FF124
	internal static Exception BodyOfCatchMustHaveSameTypeAsBodyOfTry() { }

	// RVA: 0xFFFFFFFF759FF168
	internal static Exception ExtensionNodeMustOverrideProperty(Object p0) { }

	// RVA: 0xFFFFFFFF759FF1AC
	internal static Exception UserDefinedOperatorMustBeStatic(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FF200
	internal static Exception UserDefinedOperatorMustNotBeVoid(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FF254
	internal static Exception CoercionOperatorNotDefined(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FF298
	internal static Exception UnaryOperatorNotDefined(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FF2DC
	internal static Exception BinaryOperatorNotDefined(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF759FF320
	internal static Exception ReferenceEqualityNotDefined(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FF364
	internal static Exception OperandTypesDoNotMatchParameters(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FF3A8
	internal static Exception OverloadOperatorTypeDoesNotMatchConversionType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FF3EC
	internal static Exception ConversionIsNotSupportedForArithmeticTypes() { }

	// RVA: 0xFFFFFFFF759FF430
	internal static Exception ArgumentMustBeArray(String paramName) { }

	// RVA: 0xFFFFFFFF759FF484
	internal static Exception ArgumentMustBeBoolean(String paramName) { }

	// RVA: 0xFFFFFFFF759FF4D8
	private static Exception ArgumentMustBeFieldInfoOrPropertyInfoOrMethod(String paramName) { }

	// RVA: 0xFFFFFFFF759FF52C
	internal static Exception ArgumentMustBeFieldInfoOrPropertyInfoOrMethod(String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FF584
	private static Exception ArgumentMustBeInstanceMember(String paramName) { }

	// RVA: 0xFFFFFFFF759FF5D8
	internal static Exception ArgumentMustBeInstanceMember(String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FF630
	private static Exception ArgumentMustBeInteger(String paramName) { }

	// RVA: 0xFFFFFFFF759FF684
	internal static Exception ArgumentMustBeInteger(String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FF6DC
	internal static Exception ArgumentMustBeArrayIndexType(String paramName) { }

	// RVA: 0xFFFFFFFF759FF730
	internal static Exception ArgumentMustBeSingleDimensionalArrayType(String paramName) { }

	// RVA: 0xFFFFFFFF759FF784
	internal static Exception ArgumentTypesMustMatch() { }

	// RVA: 0xFFFFFFFF759FF7C8
	internal static Exception CannotAutoInitializeValueTypeMemberThroughProperty(Object p0) { }

	// RVA: 0xFFFFFFFF759FF80C
	internal static Exception IncorrectTypeForTypeAs(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FF860
	internal static Exception CoalesceUsedOnNonNullType() { }

	// RVA: 0xFFFFFFFF759FF8A4
	internal static Exception ExpressionTypeCannotInitializeArrayType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FF8E8
	private static Exception ArgumentTypeDoesNotMatchMember(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF759FF93C
	internal static Exception ArgumentTypeDoesNotMatchMember(Object p0, Object p1, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FF9AC
	private static Exception ArgumentMemberNotDeclOnType(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF759FFA00
	internal static Exception ArgumentMemberNotDeclOnType(Object p0, Object p1, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FFA70
	internal static Exception ExpressionTypeDoesNotMatchReturn(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FFAB4
	internal static Exception ExpressionTypeDoesNotMatchAssignment(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FFAF8
	internal static Exception ExpressionTypeDoesNotMatchLabel(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FFB3C
	internal static Exception ExpressionTypeNotInvocable(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FFB90
	internal static Exception InstanceFieldNotDefinedForType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FFBD4
	internal static Exception FieldInfoNotDefinedForType(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF759FFC18
	internal static Exception IncorrectNumberOfIndexes() { }

	// RVA: 0xFFFFFFFF759FFC5C
	internal static Exception IncorrectNumberOfLambdaDeclarationParameters() { }

	// RVA: 0xFFFFFFFF759FFCA0
	internal static Exception IncorrectNumberOfMembersForGivenConstructor() { }

	// RVA: 0xFFFFFFFF759FFCE4
	internal static Exception IncorrectNumberOfArgumentsForMembers() { }

	// RVA: 0xFFFFFFFF759FFD28
	internal static Exception LambdaTypeMustBeDerivedFromSystemDelegate(String paramName) { }

	// RVA: 0xFFFFFFFF759FFD7C
	internal static Exception MemberNotFieldOrProperty(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FFDD0
	internal static Exception MethodContainsGenericParameters(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FFE24
	internal static Exception MethodIsGeneric(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FFE78
	private static Exception MethodNotPropertyAccessor(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF759FFECC
	internal static Exception MethodNotPropertyAccessor(Object p0, Object p1, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FFF3C
	internal static Exception PropertyDoesNotHaveGetter(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759FFF90
	internal static Exception PropertyDoesNotHaveGetter(Object p0, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759FFFF8
	internal static Exception PropertyDoesNotHaveAccessor(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF75A0004C
	internal static Exception ParameterExpressionNotValidAsDelegate(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A00090
	internal static Exception PropertyNotDefinedForType(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF75A000E4
	internal static Exception InstancePropertyNotDefinedForType(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF75A00138
	internal static Exception InstanceAndMethodTypeMismatch(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A0017C
	internal static Exception UnhandledBinary(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF75A001D0
	internal static Exception UnhandledUnary(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF75A00224
	internal static Exception UserDefinedOpMustHaveConsistentTypes(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A00268
	internal static Exception UserDefinedOpMustHaveValidReturnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A002AC
	internal static Exception LogicalOperatorMustHaveBooleanOperators(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A002F0
	internal static Exception MethodWithArgsDoesNotExistOnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A00334
	internal static Exception GenericMethodWithArgsDoesNotExistOnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A00378
	internal static Exception MethodWithMoreThanOneMatch(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A003BC
	internal static Exception ArgumentCannotBeOfTypeVoid(String paramName) { }

	// RVA: 0xFFFFFFFF75A00410
	internal static Exception LabelTargetAlreadyDefined(Object p0) { }

	// RVA: 0xFFFFFFFF75A00454
	internal static Exception LabelTargetUndefined(Object p0) { }

	// RVA: 0xFFFFFFFF75A00498
	internal static Exception ControlCannotLeaveFinally() { }

	// RVA: 0xFFFFFFFF75A004DC
	internal static Exception ControlCannotLeaveFilterTest() { }

	// RVA: 0xFFFFFFFF75A00520
	internal static Exception AmbiguousJump(Object p0) { }

	// RVA: 0xFFFFFFFF75A00564
	internal static Exception ControlCannotEnterTry() { }

	// RVA: 0xFFFFFFFF75A005A8
	internal static Exception ControlCannotEnterExpression() { }

	// RVA: 0xFFFFFFFF75A005EC
	internal static Exception NonLocalJumpWithValue(Object p0) { }

	// RVA: 0xFFFFFFFF75A00630
	internal static Exception InvalidLvalue(ExpressionType p0) { }

	// RVA: 0xFFFFFFFF75A006B4
	internal static Exception RethrowRequiresCatch() { }

	// RVA: 0xFFFFFFFF75A006F8
	internal static Exception MustRewriteToSameNode(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A0073C
	internal static Exception MustRewriteChildToSameType(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A00780
	internal static Exception MustRewriteWithoutMethod(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF759FC21C
	internal static Exception ArgumentOutOfRange(String paramName) { }

	// RVA: 0xFFFFFFFF75A007C4
	internal static Exception NotSupported() { }

	// RVA: 0xFFFFFFFF75A007F8
	internal static Exception NonStaticConstructorRequired(String paramName) { }

	// RVA: 0xFFFFFFFF75A0084C
	internal static Exception NonAbstractConstructorRequired() { }

	// RVA: 0xFFFFFFFF75A00890
	internal static Exception InvalidProgram() { }

	// RVA: 0xFFFFFFFF75A008E4
	internal static Exception EnumerationIsDone() { }

	// RVA: 0xFFFFFFFF75A00928
	private static Exception TypeContainsGenericParameters(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759F7A48
	internal static Exception TypeContainsGenericParameters(Object p0, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF75A0097C
	internal static Exception TypeIsGeneric(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF759F7AB0
	internal static Exception TypeIsGeneric(Object p0, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759F46C0
	internal static Exception IncorrectNumberOfConstructorArguments() { }

	// RVA: 0xFFFFFFFF75A009D0
	internal static Exception ExpressionTypeDoesNotMatchMethodParameter(Object p0, Object p1, Object p2, String paramName) { }

	// RVA: 0xFFFFFFFF759F4C58
	internal static Exception ExpressionTypeDoesNotMatchMethodParameter(Object p0, Object p1, Object p2, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF75A00A24
	internal static Exception ExpressionTypeDoesNotMatchParameter(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF759F4BE8
	internal static Exception ExpressionTypeDoesNotMatchParameter(Object p0, Object p1, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759F4704
	internal static Exception IncorrectNumberOfLambdaArguments() { }

	// RVA: 0xFFFFFFFF759F4748
	internal static Exception IncorrectNumberOfMethodCallArguments(Object p0, String paramName) { }

	// RVA: 0xFFFFFFFF75A00A78
	internal static Exception ExpressionTypeDoesNotMatchConstructorParameter(Object p0, Object p1, String paramName) { }

	// RVA: 0xFFFFFFFF759F4B78
	internal static Exception ExpressionTypeDoesNotMatchConstructorParameter(Object p0, Object p1, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF75A00ACC
	internal static Exception ExpressionMustBeReadable(String paramName) { }

	// RVA: 0xFFFFFFFF759F4CD8
	internal static Exception ExpressionMustBeReadable(String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759F3EF4
	internal static Exception InvalidArgumentValue(String paramName) { }

	// RVA: 0xFFFFFFFF75A00B20
	internal static Exception InvalidNullValue(Type type, String paramName) { }

	// RVA: 0xFFFFFFFF75A00B74
	internal static Exception InvalidTypeException(Object value, Type type, String paramName) { }

	// RVA: 0xFFFFFFFF759FE9B8
	private static String GetParamName(String paramName, Int32 index) { }

}

// Namespace: System.Linq.Expressions
internal sealed class ExpressionStringBuilder
{
	// Fields
	private readonly StringBuilder _out; // 0x10
	private Dictionary<T0, T1> _ids; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A12A54
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A12AA4
	public override String ToString() { }

	// RVA: 0xFFFFFFFF75A12ACC
	private Int32 GetLabelId(LabelTarget label) { }

	// RVA: 0xFFFFFFFF75A12BB8
	private Int32 GetParamId(ParameterExpression p) { }

	// RVA: 0xFFFFFFFF75A12AD0
	private Int32 GetId(Object o) { }

	// RVA: 0xFFFFFFFF75A12BBC
	private Void Out(String s) { }

	// RVA: 0xFFFFFFFF75A12BDC
	private Void Out(Char c) { }

	// RVA: 0xFFFFFFFF75A09558
	internal static String ExpressionToString(Expression node) { }

	// RVA: 0xFFFFFFFF759FD7D8
	internal static String CatchBlockToString(CatchBlock node) { }

	// RVA: -1
	private Void VisitExpressions(Char open, ReadOnlyCollection<T0> expressions, Char close) { }

	// RVA: -1
	private Void VisitExpressions(Char open, ReadOnlyCollection<T0> expressions, Char close, String seperator) { }

	// RVA: 0xFFFFFFFF75A12BFC
	protected internal override Expression VisitBinary(BinaryExpression node) { }

	// RVA: 0xFFFFFFFF75A1317C
	protected internal override Expression VisitParameter(ParameterExpression node) { }

	// RVA: -1
	protected internal override Expression VisitLambda(Expression<T0> node) { }

	// RVA: 0xFFFFFFFF75A13274
	protected internal override Expression VisitConditional(ConditionalExpression node) { }

	// RVA: 0xFFFFFFFF75A13388
	protected internal override Expression VisitConstant(ConstantExpression node) { }

	// RVA: 0xFFFFFFFF75A134E8
	private Void OutMember(Expression instance, MemberInfo member) { }

	// RVA: 0xFFFFFFFF75A135A4
	protected internal override Expression VisitMember(MemberExpression node) { }

	// RVA: 0xFFFFFFFF75A135F8
	protected internal override Expression VisitInvocation(InvocationExpression node) { }

	// RVA: 0xFFFFFFFF75A13720
	protected internal override Expression VisitMethodCall(MethodCallExpression node) { }

	// RVA: 0xFFFFFFFF75A13944
	protected internal override Expression VisitNewArray(NewArrayExpression node) { }

	// RVA: 0xFFFFFFFF75A13A78
	protected internal override Expression VisitNew(NewExpression node) { }

	// RVA: 0xFFFFFFFF75A13CD4
	protected internal override Expression VisitUnary(UnaryExpression node) { }

	// RVA: 0xFFFFFFFF75A14128
	protected internal override Expression VisitBlock(BlockExpression node) { }

	// RVA: 0xFFFFFFFF75A143D8
	protected internal override Expression VisitDefault(DefaultExpression node) { }

	// RVA: 0xFFFFFFFF75A14494
	protected internal override Expression VisitLabel(LabelExpression node) { }

	// RVA: 0xFFFFFFFF75A145F4
	protected internal override Expression VisitGoto(GotoExpression node) { }

	// RVA: 0xFFFFFFFF75A14730
	protected override CatchBlock VisitCatchBlock(CatchBlock node) { }

	// RVA: 0xFFFFFFFF75A1483C
	protected internal override Expression VisitTry(TryExpression node) { }

	// RVA: 0xFFFFFFFF75A148A4
	protected internal override Expression VisitIndex(IndexExpression node) { }

	// RVA: 0xFFFFFFFF75A14A6C
	protected internal override Expression VisitExtension(Expression node) { }

	// RVA: 0xFFFFFFFF75A14520
	private Void DumpLabel(LabelTarget target) { }

	// RVA: 0xFFFFFFFF75A1308C
	private static Boolean IsBool(Expression node) { }

}

// Namespace: System.Linq.Expressions
public enum ExpressionType
{
	// Fields
	public Int32 value__; // 0x10
	public const ExpressionType Add = 0;
	public const ExpressionType AddChecked = 1;
	public const ExpressionType And = 2;
	public const ExpressionType AndAlso = 3;
	public const ExpressionType ArrayLength = 4;
	public const ExpressionType ArrayIndex = 5;
	public const ExpressionType Call = 6;
	public const ExpressionType Coalesce = 7;
	public const ExpressionType Conditional = 8;
	public const ExpressionType Constant = 9;
	public const ExpressionType Convert = 10;
	public const ExpressionType ConvertChecked = 11;
	public const ExpressionType Divide = 12;
	public const ExpressionType Equal = 13;
	public const ExpressionType ExclusiveOr = 14;
	public const ExpressionType GreaterThan = 15;
	public const ExpressionType GreaterThanOrEqual = 16;
	public const ExpressionType Invoke = 17;
	public const ExpressionType Lambda = 18;
	public const ExpressionType LeftShift = 19;
	public const ExpressionType LessThan = 20;
	public const ExpressionType LessThanOrEqual = 21;
	public const ExpressionType ListInit = 22;
	public const ExpressionType MemberAccess = 23;
	public const ExpressionType MemberInit = 24;
	public const ExpressionType Modulo = 25;
	public const ExpressionType Multiply = 26;
	public const ExpressionType MultiplyChecked = 27;
	public const ExpressionType Negate = 28;
	public const ExpressionType UnaryPlus = 29;
	public const ExpressionType NegateChecked = 30;
	public const ExpressionType New = 31;
	public const ExpressionType NewArrayInit = 32;
	public const ExpressionType NewArrayBounds = 33;
	public const ExpressionType Not = 34;
	public const ExpressionType NotEqual = 35;
	public const ExpressionType Or = 36;
	public const ExpressionType OrElse = 37;
	public const ExpressionType Parameter = 38;
	public const ExpressionType Power = 39;
	public const ExpressionType Quote = 40;
	public const ExpressionType RightShift = 41;
	public const ExpressionType Subtract = 42;
	public const ExpressionType SubtractChecked = 43;
	public const ExpressionType TypeAs = 44;
	public const ExpressionType TypeIs = 45;
	public const ExpressionType Assign = 46;
	public const ExpressionType Block = 47;
	public const ExpressionType DebugInfo = 48;
	public const ExpressionType Decrement = 49;
	public const ExpressionType Dynamic = 50;
	public const ExpressionType Default = 51;
	public const ExpressionType Extension = 52;
	public const ExpressionType Goto = 53;
	public const ExpressionType Increment = 54;
	public const ExpressionType Index = 55;
	public const ExpressionType Label = 56;
	public const ExpressionType RuntimeVariables = 57;
	public const ExpressionType Loop = 58;
	public const ExpressionType Switch = 59;
	public const ExpressionType Throw = 60;
	public const ExpressionType Try = 61;
	public const ExpressionType Unbox = 62;
	public const ExpressionType AddAssign = 63;
	public const ExpressionType AndAssign = 64;
	public const ExpressionType DivideAssign = 65;
	public const ExpressionType ExclusiveOrAssign = 66;
	public const ExpressionType LeftShiftAssign = 67;
	public const ExpressionType ModuloAssign = 68;
	public const ExpressionType MultiplyAssign = 69;
	public const ExpressionType OrAssign = 70;
	public const ExpressionType PowerAssign = 71;
	public const ExpressionType RightShiftAssign = 72;
	public const ExpressionType SubtractAssign = 73;
	public const ExpressionType AddAssignChecked = 74;
	public const ExpressionType MultiplyAssignChecked = 75;
	public const ExpressionType SubtractAssignChecked = 76;
	public const ExpressionType PreIncrementAssign = 77;
	public const ExpressionType PreDecrementAssign = 78;
	public const ExpressionType PostIncrementAssign = 79;
	public const ExpressionType PostDecrementAssign = 80;
	public const ExpressionType TypeEqual = 81;
	public const ExpressionType OnesComplement = 82;
	public const ExpressionType IsTrue = 83;
	public const ExpressionType IsFalse = 84;
}

// Namespace: System.Linq.Expressions
public abstract class ExpressionVisitor
{
	// Methods

	// RVA: 0xFFFFFFFF75A12A9C
	protected Void .ctor() { }

	// RVA: 0xFFFFFFFF75A14C74
	public virtual Expression Visit(Expression node) { }

	// RVA: 0xFFFFFFFF75A14C9C
	public ReadOnlyCollection<T0> Visit(ReadOnlyCollection<T0> nodes) { }

	// RVA: 0xFFFFFFFF75A14EA8
	private Expression[] VisitArguments(IArgumentProvider nodes) { }

	// RVA: 0xFFFFFFFF75A14EAC
	private ParameterExpression[] VisitParameters(IParameterProvider nodes, String callerName) { }

	// RVA: -1
	public static ReadOnlyCollection<T0> Visit(ReadOnlyCollection<T0> nodes, Func<T0, T1> elementVisitor) { }

	// RVA: -1
	public T VisitAndConvert(T node, String callerName) { }

	// RVA: -1
	public ReadOnlyCollection<T0> VisitAndConvert(ReadOnlyCollection<T0> nodes, String callerName) { }

	// RVA: 0xFFFFFFFF75A14EB0
	protected internal virtual Expression VisitBinary(BinaryExpression node) { }

	// RVA: 0xFFFFFFFF75A15100
	protected internal virtual Expression VisitBlock(BlockExpression node) { }

	// RVA: 0xFFFFFFFF75A151EC
	protected internal virtual Expression VisitConditional(ConditionalExpression node) { }

	// RVA: 0xFFFFFFFF75A1528C
	protected internal virtual Expression VisitConstant(ConstantExpression node) { }

	// RVA: 0xFFFFFFFF75A15294
	protected internal virtual Expression VisitDefault(DefaultExpression node) { }

	// RVA: 0xFFFFFFFF75A1529C
	protected internal virtual Expression VisitExtension(Expression node) { }

	// RVA: 0xFFFFFFFF75A152CC
	protected internal virtual Expression VisitGoto(GotoExpression node) { }

	// RVA: 0xFFFFFFFF75A153F8
	protected internal virtual Expression VisitInvocation(InvocationExpression node) { }

	// RVA: 0xFFFFFFFF75A15488
	protected virtual LabelTarget VisitLabelTarget(LabelTarget node) { }

	// RVA: 0xFFFFFFFF75A15490
	protected internal virtual Expression VisitLabel(LabelExpression node) { }

	// RVA: -1
	protected internal virtual Expression VisitLambda(Expression<T0> node) { }

	// RVA: 0xFFFFFFFF75A15500
	protected internal virtual Expression VisitMember(MemberExpression node) { }

	// RVA: 0xFFFFFFFF75A15544
	protected internal virtual Expression VisitIndex(IndexExpression node) { }

	// RVA: 0xFFFFFFFF75A15648
	protected internal virtual Expression VisitMethodCall(MethodCallExpression node) { }

	// RVA: 0xFFFFFFFF75A156F4
	protected internal virtual Expression VisitNewArray(NewArrayExpression node) { }

	// RVA: 0xFFFFFFFF75A1572C
	protected internal virtual Expression VisitNew(NewExpression node) { }

	// RVA: 0xFFFFFFFF75A15774
	protected internal virtual Expression VisitParameter(ParameterExpression node) { }

	// RVA: 0xFFFFFFFF75A1577C
	protected virtual CatchBlock VisitCatchBlock(CatchBlock node) { }

	// RVA: 0xFFFFFFFF75A1583C
	protected internal virtual Expression VisitTry(TryExpression node) { }

	// RVA: 0xFFFFFFFF75A15958
	protected internal virtual Expression VisitUnary(UnaryExpression node) { }

	// RVA: 0xFFFFFFFF75A159A8
	private static UnaryExpression ValidateUnary(UnaryExpression before, UnaryExpression after) { }

	// RVA: 0xFFFFFFFF75A14F90
	private static BinaryExpression ValidateBinary(BinaryExpression before, BinaryExpression after) { }

	// RVA: 0xFFFFFFFF75A15AAC
	private static Void ValidateChildType(Type before, Type after, String methodName) { }

}

// Namespace: System.Linq.Expressions
public enum GotoExpressionKind
{
	// Fields
	public Int32 value__; // 0x10
	public const GotoExpressionKind Goto = 0;
	public const GotoExpressionKind Return = 1;
	public const GotoExpressionKind Break = 2;
	public const GotoExpressionKind Continue = 3;
}

// Namespace: System.Linq.Expressions
public sealed class GotoExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x10
	private readonly Expression <Value>k__BackingField; // 0x18
	private readonly LabelTarget <Target>k__BackingField; // 0x20
	private readonly GotoExpressionKind <Kind>k__BackingField; // 0x28

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public Expression Value { get; }
	public LabelTarget Target { get; }
	public GotoExpressionKind Kind { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A098A4
	internal Void .ctor(GotoExpressionKind kind, LabelTarget target, Expression value, Type type) { }

	// RVA: 0xFFFFFFFF75A15BC4
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A15BCC
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A15BD4
	public Expression get_Value() { }

	// RVA: 0xFFFFFFFF75A15BDC
	public LabelTarget get_Target() { }

	// RVA: 0xFFFFFFFF75A15BE4
	public GotoExpressionKind get_Kind() { }

	// RVA: 0xFFFFFFFF75A15BEC
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A15338
	public GotoExpression Update(LabelTarget target, Expression value) { }

}

// Namespace: System.Linq.Expressions
public interface IArgumentProvider
{
	// Properties
	public abstract Int32 ArgumentCount { get; }

	// Methods

	// RVA: -1
	public abstract Expression GetArgument(Int32 index) { }

	// RVA: -1
	public abstract Int32 get_ArgumentCount() { }

}

// Namespace: System.Linq.Expressions
internal interface IParameterProvider
{
	// Properties
	public abstract Int32 ParameterCount { get; }

	// Methods

	// RVA: -1
	public abstract ParameterExpression GetParameter(Int32 index) { }

	// RVA: -1
	public abstract Int32 get_ParameterCount() { }

}

// Namespace: System.Linq.Expressions
public sealed class IndexExpression
{
	// Fields
	private IReadOnlyList<T0> _arguments; // 0x10
	private readonly Expression <Object>k__BackingField; // 0x18
	private readonly PropertyInfo <Indexer>k__BackingField; // 0x20

	// Properties
	public sealed override ExpressionType NodeType { get; }
	public sealed override Type Type { get; }
	public Expression Object { get; }
	public PropertyInfo Indexer { get; }
	public Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A09F48
	internal Void .ctor(Expression instance, PropertyInfo indexer, IReadOnlyList<T0> arguments) { }

	// RVA: 0xFFFFFFFF75A15C1C
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A15C24
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A15C94
	public Expression get_Object() { }

	// RVA: 0xFFFFFFFF75A15C9C
	public PropertyInfo get_Indexer() { }

	// RVA: 0xFFFFFFFF759FACE0
	public Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF759FAC3C
	public Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A15CA4
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A155C8
	internal Expression Rewrite(Expression instance, Expression[] arguments) { }

}

// Namespace: System.Linq.Expressions
public class InvocationExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x10
	private readonly Expression <Expression>k__BackingField; // 0x18

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public Expression Expression { get; }
	public virtual Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D160
	internal Void .ctor(Expression expression, Type returnType) { }

	// RVA: 0xFFFFFFFF75A4D1F0
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4D1F8
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4D200
	public Expression get_Expression() { }

	// RVA: 0xFFFFFFFF75A4D208
	public virtual Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4D248
	public virtual Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4D288
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A4D2B8
	internal virtual InvocationExpression Rewrite(Expression lambda, Expression[] arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression1
{
	// Fields
	private Object _arg0; // 0x20

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D2F8
	public Void .ctor(Expression lambda, Type returnType, Expression arg0) { }

	// RVA: 0xFFFFFFFF75A4D328
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4D3BC
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4D3C4
	internal override InvocationExpression Rewrite(Expression lambda, Expression[] arguments) { }

}

// Namespace: System.Linq.Expressions
public sealed class LabelExpression
{
	// Fields
	private readonly LabelTarget <Target>k__BackingField; // 0x10
	private readonly Expression <DefaultValue>k__BackingField; // 0x18

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public LabelTarget Target { get; }
	public Expression DefaultValue { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D478
	internal Void .ctor(LabelTarget label, Expression defaultValue) { }

	// RVA: 0xFFFFFFFF75A4D508
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4D528
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4D530
	public LabelTarget get_Target() { }

	// RVA: 0xFFFFFFFF75A4D538
	public Expression get_DefaultValue() { }

	// RVA: 0xFFFFFFFF75A4D540
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A4D570
	public LabelExpression Update(LabelTarget target, Expression defaultValue) { }

}

// Namespace: System.Linq.Expressions
public sealed class LabelTarget
{
	// Fields
	private readonly String <Name>k__BackingField; // 0x10
	private readonly Type <Type>k__BackingField; // 0x18

	// Properties
	public String Name { get; }
	public Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D610
	internal Void .ctor(Type type, String name) { }

	// RVA: 0xFFFFFFFF75A4D660
	public String get_Name() { }

	// RVA: 0xFFFFFFFF75A4D668
	public Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4D670
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions
public abstract class LambdaExpression
{
	// Fields
	private readonly Expression _body; // 0x10

	// Properties
	public sealed override Type Type { get; }
	internal abstract Type TypeCore { get; }
	internal abstract Type PublicType { get; }
	public sealed override ExpressionType NodeType { get; }
	public String Name { get; }
	internal virtual String NameCore { get; }
	public Expression Body { get; }
	public Type ReturnType { get; }
	public Boolean TailCall { get; }
	internal virtual Boolean TailCallCore { get; }
	private Int32 System.Linq.Expressions.IParameterProvider.ParameterCount { get; }
	internal virtual Int32 ParameterCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D6D4
	internal Void .ctor(Expression body) { }

	// RVA: 0xFFFFFFFF75A4D750
	public sealed override Type get_Type() { }

	// RVA: -1
	internal abstract Type get_TypeCore() { }

	// RVA: -1
	internal abstract Type get_PublicType() { }

	// RVA: 0xFFFFFFFF75A4D760
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4D768
	public String get_Name() { }

	// RVA: 0xFFFFFFFF75A4D778
	internal virtual String get_NameCore() { }

	// RVA: 0xFFFFFFFF75A4D780
	public Expression get_Body() { }

	// RVA: 0xFFFFFFFF75A4D788
	public Type get_ReturnType() { }

	// RVA: 0xFFFFFFFF75A4D7C4
	public Boolean get_TailCall() { }

	// RVA: 0xFFFFFFFF75A4D7D4
	internal virtual Boolean get_TailCallCore() { }

	// RVA: 0xFFFFFFFF75A4D7DC
	private ParameterExpression System.Linq.Expressions.IParameterProvider.GetParameter(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4D7EC
	internal virtual ParameterExpression GetParameter(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4D82C
	private Int32 System.Linq.Expressions.IParameterProvider.get_ParameterCount() { }

	// RVA: 0xFFFFFFFF75A4D83C
	internal virtual Int32 get_ParameterCount() { }

	// RVA: 0xFFFFFFFF75A4D87C
	public Delegate Compile() { }

	// RVA: 0xFFFFFFFF75A4D884
	public Delegate Compile(Boolean preferInterpretation) { }

	// RVA: 0xFFFFFFFF75A4D8F4
	public Delegate Compile(DebugInfoGenerator debugInfoGenerator) { }

}

// Namespace: System.Linq.Expressions
public class Expression<T0>
{
	// Properties
	internal sealed override Type TypeCore { get; }
	internal override Type PublicType { get; }

	// Methods

	// RVA: -1
	internal Void .ctor(Expression body) { }

	// RVA: -1
	internal sealed override Type get_TypeCore() { }

	// RVA: -1
	internal override Type get_PublicType() { }

	// RVA: -1
	public TDelegate Compile() { }

	// RVA: -1
	public TDelegate Compile(Boolean preferInterpretation) { }

	// RVA: -1
	internal virtual Expression<T0> Rewrite(Expression body, ParameterExpression[] parameters) { }

	// RVA: -1
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

}

// Namespace: System.Linq.Expressions
internal static class ExpressionCreator<T0>
{
	// Methods

	// RVA: -1
	public static LambdaExpression CreateExpressionFunc(Expression body, String name, Boolean tailCall, ReadOnlyCollection<T0> parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression0<T0>
{
	// Properties
	internal override Int32 ParameterCount { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Expression body) { }

	// RVA: -1
	internal override Int32 get_ParameterCount() { }

	// RVA: -1
	internal override ParameterExpression GetParameter(Int32 index) { }

	// RVA: -1
	internal override Expression<T0> Rewrite(Expression body, ParameterExpression[] parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression1<T0>
{
	// Fields
	private Object _par0; // 0x0

	// Properties
	internal override Int32 ParameterCount { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Expression body, ParameterExpression par0) { }

	// RVA: -1
	internal override Int32 get_ParameterCount() { }

	// RVA: -1
	internal override ParameterExpression GetParameter(Int32 index) { }

	// RVA: -1
	internal override Expression<T0> Rewrite(Expression body, ParameterExpression[] parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression2<T0>
{
	// Fields
	private Object _par0; // 0x0
	private readonly ParameterExpression _par1; // 0x0

	// Properties
	internal override Int32 ParameterCount { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Expression body, ParameterExpression par0, ParameterExpression par1) { }

	// RVA: -1
	internal override Int32 get_ParameterCount() { }

	// RVA: -1
	internal override ParameterExpression GetParameter(Int32 index) { }

	// RVA: -1
	internal override Expression<T0> Rewrite(Expression body, ParameterExpression[] parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression3<T0>
{
	// Fields
	private Object _par0; // 0x0
	private readonly ParameterExpression _par1; // 0x0
	private readonly ParameterExpression _par2; // 0x0

	// Properties
	internal override Int32 ParameterCount { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Expression body, ParameterExpression par0, ParameterExpression par1, ParameterExpression par2) { }

	// RVA: -1
	internal override Int32 get_ParameterCount() { }

	// RVA: -1
	internal override ParameterExpression GetParameter(Int32 index) { }

	// RVA: -1
	internal override Expression<T0> Rewrite(Expression body, ParameterExpression[] parameters) { }

}

// Namespace: System.Linq.Expressions
internal class ExpressionN<T0>
{
	// Fields
	private IReadOnlyList<T0> _parameters; // 0x0

	// Properties
	internal override Int32 ParameterCount { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Expression body, IReadOnlyList<T0> parameters) { }

	// RVA: -1
	internal override Int32 get_ParameterCount() { }

	// RVA: -1
	internal override ParameterExpression GetParameter(Int32 index) { }

	// RVA: -1
	internal override Expression<T0> Rewrite(Expression body, ParameterExpression[] parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class FullExpression<T0>
{
	// Fields
	private readonly String <NameCore>k__BackingField; // 0x0
	private readonly Boolean <TailCallCore>k__BackingField; // 0x0

	// Properties
	internal override String NameCore { get; }
	internal override Boolean TailCallCore { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Expression body, String name, Boolean tailCall, IReadOnlyList<T0> parameters) { }

	// RVA: -1
	internal override String get_NameCore() { }

	// RVA: -1
	internal override Boolean get_TailCallCore() { }

}

// Namespace: System.Linq.Expressions
public sealed class ListInitExpression
{
	// Fields
	private readonly NewExpression <NewExpression>k__BackingField; // 0x10
	private readonly ReadOnlyCollection<T0> <Initializers>k__BackingField; // 0x18

	// Properties
	public NewExpression NewExpression { get; }
	public ReadOnlyCollection<T0> Initializers { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D8FC
	public NewExpression get_NewExpression() { }

	// RVA: 0xFFFFFFFF75A4D904
	public ReadOnlyCollection<T0> get_Initializers() { }

}

// Namespace: System.Linq.Expressions
public sealed class LoopExpression
{
	// Fields
	private readonly Expression <Body>k__BackingField; // 0x10
	private readonly LabelTarget <BreakLabel>k__BackingField; // 0x18
	private readonly LabelTarget <ContinueLabel>k__BackingField; // 0x20

	// Properties
	public Expression Body { get; }
	public LabelTarget BreakLabel { get; }
	public LabelTarget ContinueLabel { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D98C
	public Expression get_Body() { }

	// RVA: 0xFFFFFFFF75A4D994
	public LabelTarget get_BreakLabel() { }

	// RVA: 0xFFFFFFFF75A4D99C
	public LabelTarget get_ContinueLabel() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberAssignment
{
	// Fields
	private readonly Expression _expression; // 0x20

	// Properties
	public Expression Expression { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D9A4
	public Expression get_Expression() { }

}

// Namespace: System.Linq.Expressions
public enum MemberBindingType
{
	// Fields
	public Int32 value__; // 0x10
	public const MemberBindingType Assignment = 0;
	public const MemberBindingType MemberBinding = 1;
	public const MemberBindingType ListBinding = 2;
}

// Namespace: System.Linq.Expressions
public abstract class MemberBinding
{
	// Fields
	private readonly MemberBindingType <BindingType>k__BackingField; // 0x10
	private readonly MemberInfo <Member>k__BackingField; // 0x18

	// Properties
	public MemberBindingType BindingType { get; }
	public MemberInfo Member { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D9AC
	public MemberBindingType get_BindingType() { }

	// RVA: 0xFFFFFFFF75A4D9B4
	public MemberInfo get_Member() { }

}

// Namespace: System.Linq.Expressions
public class MemberExpression
{
	// Fields
	private readonly Expression <Expression>k__BackingField; // 0x10

	// Properties
	public MemberInfo Member { get; }
	public Expression Expression { get; }
	public sealed override ExpressionType NodeType { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D9BC
	public MemberInfo get_Member() { }

	// RVA: 0xFFFFFFFF75A4D9CC
	public Expression get_Expression() { }

	// RVA: 0xFFFFFFFF75A4D9D4
	internal Void .ctor(Expression expression) { }

	// RVA: 0xFFFFFFFF75A4DA50
	internal static PropertyExpression Make(Expression expression, PropertyInfo property) { }

	// RVA: 0xFFFFFFFF75A4DAF4
	internal static FieldExpression Make(Expression expression, FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A4DB60
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4DB68
	internal virtual MemberInfo GetMember() { }

	// RVA: 0xFFFFFFFF75A4DBA8
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A4DBD8
	public MemberExpression Update(Expression expression) { }

}

// Namespace: System.Linq.Expressions
internal sealed class FieldExpression
{
	// Fields
	private readonly FieldInfo _field; // 0x18

	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A15B50
	public Void .ctor(Expression expression, FieldInfo member) { }

	// RVA: 0xFFFFFFFF75A15B84
	internal override MemberInfo GetMember() { }

	// RVA: 0xFFFFFFFF75A15B8C
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
internal sealed class PropertyExpression
{
	// Fields
	private readonly PropertyInfo _property; // 0x18

	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DAC4
	public Void .ctor(Expression expression, PropertyInfo member) { }

	// RVA: 0xFFFFFFFF75A50034
	internal override MemberInfo GetMember() { }

	// RVA: 0xFFFFFFFF75A5003C
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberInitExpression
{
	// Fields
	private readonly NewExpression <NewExpression>k__BackingField; // 0x10
	private readonly ReadOnlyCollection<T0> <Bindings>k__BackingField; // 0x18

	// Properties
	public NewExpression NewExpression { get; }
	public ReadOnlyCollection<T0> Bindings { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DC80
	public NewExpression get_NewExpression() { }

	// RVA: 0xFFFFFFFF75A4DC88
	public ReadOnlyCollection<T0> get_Bindings() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberListBinding
{
	// Fields
	private readonly ReadOnlyCollection<T0> <Initializers>k__BackingField; // 0x20

	// Properties
	public ReadOnlyCollection<T0> Initializers { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DC90
	public ReadOnlyCollection<T0> get_Initializers() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberMemberBinding
{
	// Fields
	private readonly ReadOnlyCollection<T0> <Bindings>k__BackingField; // 0x20

	// Properties
	public ReadOnlyCollection<T0> Bindings { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DC98
	public ReadOnlyCollection<T0> get_Bindings() { }

}

// Namespace: System.Linq.Expressions
public class MethodCallExpression
{
	// Fields
	private readonly MethodInfo <Method>k__BackingField; // 0x10

	// Properties
	public sealed override ExpressionType NodeType { get; }
	public sealed override Type Type { get; }
	public MethodInfo Method { get; }
	public Expression Object { get; }
	public virtual Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DD54
	internal Void .ctor(MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A4DDD0
	internal virtual Expression GetInstance() { }

	// RVA: 0xFFFFFFFF75A4DDD8
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4DDE0
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4DE08
	public MethodInfo get_Method() { }

	// RVA: 0xFFFFFFFF75A4DE10
	public Expression get_Object() { }

	// RVA: 0xFFFFFFFF75A4DE20
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A4DE50
	internal virtual MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

	// RVA: 0xFFFFFFFF75A4DE90
	public virtual Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4DED0
	public virtual Int32 get_ArgumentCount() { }

}

// Namespace: System.Linq.Expressions
internal class InstanceMethodCallExpression
{
	// Fields
	private readonly Expression _instance; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A15CD4
	public Void .ctor(MethodInfo method, Expression instance) { }

	// RVA: 0xFFFFFFFF75A15D08
	internal override Expression GetInstance() { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpressionN
{
	// Fields
	private IReadOnlyList<T0> _arguments; // 0x18

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4EFF4
	public Void .ctor(MethodInfo method, IReadOnlyList<T0> args) { }

	// RVA: 0xFFFFFFFF75A4F024
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4F0D8
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4F17C
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpressionN
{
	// Fields
	private IReadOnlyList<T0> _arguments; // 0x20

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A0DE24
	public Void .ctor(MethodInfo method, Expression instance, IReadOnlyList<T0> args) { }

	// RVA: 0xFFFFFFFF75A164FC
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A165B0
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A16654
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression0
{
	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DF10
	public Void .ctor(MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A4DF14
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4DF70
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4DF78
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression1
{
	// Fields
	private Object _arg0; // 0x18

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4DFDC
	public Void .ctor(MethodInfo method, Expression arg0) { }

	// RVA: 0xFFFFFFFF75A4E00C
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4E0A0
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4E0A8
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression2
{
	// Fields
	private Object _arg0; // 0x18
	private readonly Expression _arg1; // 0x20

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4E1B4
	public Void .ctor(MethodInfo method, Expression arg0, Expression arg1) { }

	// RVA: 0xFFFFFFFF75A4E200
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4E2B0
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4E2B8
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression3
{
	// Fields
	private Object _arg0; // 0x18
	private readonly Expression _arg1; // 0x20
	private readonly Expression _arg2; // 0x28

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4E45C
	public Void .ctor(MethodInfo method, Expression arg0, Expression arg1, Expression arg2) { }

	// RVA: 0xFFFFFFFF75A4E4BC
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4E57C
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4E584
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression4
{
	// Fields
	private Object _arg0; // 0x18
	private readonly Expression _arg1; // 0x20
	private readonly Expression _arg2; // 0x28
	private readonly Expression _arg3; // 0x30

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4E79C
	public Void .ctor(MethodInfo method, Expression arg0, Expression arg1, Expression arg2, Expression arg3) { }

	// RVA: 0xFFFFFFFF75A4E818
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4E8F0
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4E8F8
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression5
{
	// Fields
	private Object _arg0; // 0x18
	private readonly Expression _arg1; // 0x20
	private readonly Expression _arg2; // 0x28
	private readonly Expression _arg3; // 0x30
	private readonly Expression _arg4; // 0x38

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4EB80
	public Void .ctor(MethodInfo method, Expression arg0, Expression arg1, Expression arg2, Expression arg3, Expression arg4) { }

	// RVA: 0xFFFFFFFF75A4EC10
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4ECF0
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4ECF8
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression0
{
	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A0D3D0
	public Void .ctor(MethodInfo method, Expression instance) { }

	// RVA: 0xFFFFFFFF75A15D10
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A15D6C
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A15D74
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression1
{
	// Fields
	private Object _arg0; // 0x20

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A0D5F8
	public Void .ctor(MethodInfo method, Expression instance, Expression arg0) { }

	// RVA: 0xFFFFFFFF75A15DE4
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A15E78
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A15E80
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression2
{
	// Fields
	private Object _arg0; // 0x20
	private readonly Expression _arg1; // 0x28

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A0D80C
	public Void .ctor(MethodInfo method, Expression instance, Expression arg0, Expression arg1) { }

	// RVA: 0xFFFFFFFF75A15F94
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A16044
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A1604C
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression3
{
	// Fields
	private Object _arg0; // 0x20
	private readonly Expression _arg1; // 0x28
	private readonly Expression _arg2; // 0x30

	// Properties
	public override Int32 ArgumentCount { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A0DA94
	public Void .ctor(MethodInfo method, Expression instance, Expression arg0, Expression arg1, Expression arg2) { }

	// RVA: 0xFFFFFFFF75A16208
	public override Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A162C8
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A162D0
	internal override MethodCallExpression Rewrite(Expression instance, IReadOnlyList<T0> args) { }

}

// Namespace: System.Linq.Expressions
public class NewArrayExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x10
	private readonly ReadOnlyCollection<T0> <Expressions>k__BackingField; // 0x18

	// Properties
	public sealed override Type Type { get; }
	public ReadOnlyCollection<T0> Expressions { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4F1FC
	internal Void .ctor(Type type, ReadOnlyCollection<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A4F294
	internal static NewArrayExpression Make(ExpressionType nodeType, Type type, ReadOnlyCollection<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A4F32C
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4F334
	public ReadOnlyCollection<T0> get_Expressions() { }

	// RVA: 0xFFFFFFFF75A4F33C
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A4F36C
	public NewArrayExpression Update(IEnumerable<T0> expressions) { }

}

// Namespace: System.Linq.Expressions
internal sealed class NewArrayInitExpression
{
	// Properties
	public sealed override ExpressionType NodeType { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4F328
	internal Void .ctor(Type type, ReadOnlyCollection<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A4F4D0
	public sealed override ExpressionType get_NodeType() { }

}

// Namespace: System.Linq.Expressions
internal sealed class NewArrayBoundsExpression
{
	// Properties
	public sealed override ExpressionType NodeType { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4F1F8
	internal Void .ctor(Type type, ReadOnlyCollection<T0> expressions) { }

	// RVA: 0xFFFFFFFF75A4F28C
	public sealed override ExpressionType get_NodeType() { }

}

// Namespace: System.Linq.Expressions
public class NewExpression
{
	// Fields
	private IReadOnlyList<T0> _arguments; // 0x10
	private readonly ConstructorInfo <Constructor>k__BackingField; // 0x18
	private readonly ReadOnlyCollection<T0> <Members>k__BackingField; // 0x20

	// Properties
	public override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public ConstructorInfo Constructor { get; }
	public ReadOnlyCollection<T0> Arguments { get; }
	public Int32 ArgumentCount { get; }
	public ReadOnlyCollection<T0> Members { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4F4D8
	internal Void .ctor(ConstructorInfo constructor, IReadOnlyList<T0> arguments, ReadOnlyCollection<T0> members) { }

	// RVA: 0xFFFFFFFF75A4F584
	public override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4F5AC
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4F5B4
	public ConstructorInfo get_Constructor() { }

	// RVA: 0xFFFFFFFF75A4F5BC
	public ReadOnlyCollection<T0> get_Arguments() { }

	// RVA: 0xFFFFFFFF75A4F604
	public Expression GetArgument(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4F6B8
	public Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A4F75C
	public ReadOnlyCollection<T0> get_Members() { }

	// RVA: 0xFFFFFFFF75A4F764
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A4F794
	public NewExpression Update(IEnumerable<T0> arguments) { }

}

// Namespace: System.Linq.Expressions
public class ParameterExpression
{
	// Fields
	private readonly String <Name>k__BackingField; // 0x10

	// Properties
	public override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public String Name { get; }
	public Boolean IsByRef { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4F918
	internal Void .ctor(String name) { }

	// RVA: 0xFFFFFFFF75A4F994
	internal static ParameterExpression Make(Type type, String name, Boolean isByRef) { }

	// RVA: 0xFFFFFFFF75A4FF98
	public override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A4FFDC
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A4FFE4
	public String get_Name() { }

	// RVA: 0xFFFFFFFF75A4FFEC
	public Boolean get_IsByRef() { }

	// RVA: 0xFFFFFFFF75A4FFFC
	internal virtual Boolean GetIsByRef() { }

	// RVA: 0xFFFFFFFF75A50004
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

}

// Namespace: System.Linq.Expressions
internal sealed class ByRefParameterExpression
{
	// Methods

	// RVA: 0xFFFFFFFF759FD4D4
	internal Void .ctor(Type type, String name) { }

	// RVA: 0xFFFFFFFF759FD4DC
	internal override Boolean GetIsByRef() { }

}

// Namespace: System.Linq.Expressions
internal class TypedParameterExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x18

	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4FF64
	internal Void .ctor(Type type, String name) { }

	// RVA: 0xFFFFFFFF75A52CA4
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
internal sealed class PrimitiveParameterExpression<T0>
{
	// Properties
	public sealed override Type Type { get; }

	// Methods

	// RVA: -1
	internal Void .ctor(String name) { }

	// RVA: -1
	public sealed override Type get_Type() { }

}

// Namespace: System.Linq.Expressions
public sealed class RuntimeVariablesExpression
{
	// Fields
	private readonly ReadOnlyCollection<T0> <Variables>k__BackingField; // 0x10

	// Properties
	public ReadOnlyCollection<T0> Variables { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A50064
	public ReadOnlyCollection<T0> get_Variables() { }

}

// Namespace: System.Linq.Expressions
internal sealed class StackGuard
{
	// Fields
	private Int32 _executionStackCount; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A50814
	public Boolean TryEnterOnCurrentStack() { }

	// RVA: -1
	public Void RunOnEmptyStack(Action<T0, T1> action, T1 arg1, T2 arg2) { }

	// RVA: -1
	private R RunOnEmptyStackCore(Func<T0, T1> action, Object state) { }

	// RVA: 0xFFFFFFFF75A5089C
	public Void .ctor() { }

}

// Namespace: 
private sealed class <>c__3<T0, T1>
{
	// Fields
	public static readonly <>c__3<T0, T1> <>9; // 0x0
	public static Func<T0, T1> <>9__3_0; // 0x0

	// Methods

	// RVA: -1
	private static Void .cctor() { }

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	internal Object <RunOnEmptyStack>b__3_0(Object s) { }

}

// Namespace: System.Linq.Expressions
internal static class Strings
{
	// Properties
	internal static String ReducibleMustOverrideReduce { get; }
	internal static String MustReduceToDifferent { get; }
	internal static String ReducedNotCompatible { get; }
	internal static String SetterHasNoParams { get; }
	internal static String PropertyCannotHaveRefType { get; }
	internal static String IndexesOfSetGetMustMatch { get; }
	internal static String AccessorsCannotHaveVarArgs { get; }
	internal static String AccessorsCannotHaveByRefArgs { get; }
	internal static String BoundsCannotBeLessThanOne { get; }
	internal static String TypeMustNotBeByRef { get; }
	internal static String TypeMustNotBePointer { get; }
	internal static String SetterMustBeVoid { get; }
	internal static String PropertyTypeMustMatchGetter { get; }
	internal static String PropertyTypeMustMatchSetter { get; }
	internal static String BothAccessorsMustBeStatic { get; }
	internal static String OnlyStaticFieldsHaveNullInstance { get; }
	internal static String OnlyStaticPropertiesHaveNullInstance { get; }
	internal static String OnlyStaticMethodsHaveNullInstance { get; }
	internal static String PropertyTypeCannotBeVoid { get; }
	internal static String InvalidUnboxType { get; }
	internal static String ExpressionMustBeWriteable { get; }
	internal static String ArgumentMustNotHaveValueType { get; }
	internal static String MustBeReducible { get; }
	internal static String LabelMustBeVoidOrHaveExpression { get; }
	internal static String QuotedExpressionMustBeLambda { get; }
	internal static String CollectionModifiedWhileEnumerating { get; }
	internal static String FaultCannotHaveCatchOrFinally { get; }
	internal static String TryMustHaveCatchFinallyOrFault { get; }
	internal static String BodyOfCatchMustHaveSameTypeAsBodyOfTry { get; }
	internal static String ConversionIsNotSupportedForArithmeticTypes { get; }
	internal static String ArgumentMustBeArray { get; }
	internal static String ArgumentMustBeBoolean { get; }
	internal static String ArgumentMustBeFieldInfoOrPropertyInfoOrMethod { get; }
	internal static String ArgumentMustBeInstanceMember { get; }
	internal static String ArgumentMustBeInteger { get; }
	internal static String ArgumentMustBeArrayIndexType { get; }
	internal static String ArgumentMustBeSingleDimensionalArrayType { get; }
	internal static String ArgumentTypesMustMatch { get; }
	internal static String CoalesceUsedOnNonNullType { get; }
	internal static String IncorrectNumberOfIndexes { get; }
	internal static String IncorrectNumberOfLambdaDeclarationParameters { get; }
	internal static String IncorrectNumberOfMembersForGivenConstructor { get; }
	internal static String IncorrectNumberOfArgumentsForMembers { get; }
	internal static String LambdaTypeMustBeDerivedFromSystemDelegate { get; }
	internal static String ArgumentCannotBeOfTypeVoid { get; }
	internal static String ControlCannotLeaveFinally { get; }
	internal static String ControlCannotLeaveFilterTest { get; }
	internal static String ControlCannotEnterTry { get; }
	internal static String ControlCannotEnterExpression { get; }
	internal static String RethrowRequiresCatch { get; }
	internal static String NonStaticConstructorRequired { get; }
	internal static String NonAbstractConstructorRequired { get; }
	internal static String ExpressionMustBeReadable { get; }
	internal static String EnumerationIsDone { get; }
	internal static String InvalidArgumentValue { get; }
	internal static String IncorrectNumberOfLambdaArguments { get; }
	internal static String IncorrectNumberOfConstructorArguments { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A508A4
	internal static String get_ReducibleMustOverrideReduce() { }

	// RVA: 0xFFFFFFFF75A508E4
	internal static String get_MustReduceToDifferent() { }

	// RVA: 0xFFFFFFFF75A50924
	internal static String get_ReducedNotCompatible() { }

	// RVA: 0xFFFFFFFF75A50964
	internal static String get_SetterHasNoParams() { }

	// RVA: 0xFFFFFFFF75A509A4
	internal static String get_PropertyCannotHaveRefType() { }

	// RVA: 0xFFFFFFFF75A509E4
	internal static String get_IndexesOfSetGetMustMatch() { }

	// RVA: 0xFFFFFFFF75A50A24
	internal static String get_AccessorsCannotHaveVarArgs() { }

	// RVA: 0xFFFFFFFF75A50A64
	internal static String get_AccessorsCannotHaveByRefArgs() { }

	// RVA: 0xFFFFFFFF75A50AA4
	internal static String get_BoundsCannotBeLessThanOne() { }

	// RVA: 0xFFFFFFFF75A50AE4
	internal static String get_TypeMustNotBeByRef() { }

	// RVA: 0xFFFFFFFF75A50B24
	internal static String get_TypeMustNotBePointer() { }

	// RVA: 0xFFFFFFFF75A50B64
	internal static String get_SetterMustBeVoid() { }

	// RVA: 0xFFFFFFFF75A50BA4
	internal static String get_PropertyTypeMustMatchGetter() { }

	// RVA: 0xFFFFFFFF75A50BE4
	internal static String get_PropertyTypeMustMatchSetter() { }

	// RVA: 0xFFFFFFFF75A50C24
	internal static String get_BothAccessorsMustBeStatic() { }

	// RVA: 0xFFFFFFFF75A50C64
	internal static String get_OnlyStaticFieldsHaveNullInstance() { }

	// RVA: 0xFFFFFFFF75A50CA4
	internal static String get_OnlyStaticPropertiesHaveNullInstance() { }

	// RVA: 0xFFFFFFFF75A50CE4
	internal static String get_OnlyStaticMethodsHaveNullInstance() { }

	// RVA: 0xFFFFFFFF75A50D24
	internal static String get_PropertyTypeCannotBeVoid() { }

	// RVA: 0xFFFFFFFF75A50D64
	internal static String get_InvalidUnboxType() { }

	// RVA: 0xFFFFFFFF75A50DA4
	internal static String get_ExpressionMustBeWriteable() { }

	// RVA: 0xFFFFFFFF75A50DE4
	internal static String get_ArgumentMustNotHaveValueType() { }

	// RVA: 0xFFFFFFFF75A50E24
	internal static String get_MustBeReducible() { }

	// RVA: 0xFFFFFFFF75A50E64
	internal static String get_LabelMustBeVoidOrHaveExpression() { }

	// RVA: 0xFFFFFFFF75A50EA4
	internal static String get_QuotedExpressionMustBeLambda() { }

	// RVA: 0xFFFFFFFF75A50EE4
	internal static String get_CollectionModifiedWhileEnumerating() { }

	// RVA: 0xFFFFFFFF75A50EF0
	internal static String VariableMustNotBeByRef(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A50F4C
	internal static String DuplicateVariable(Object p0) { }

	// RVA: 0xFFFFFFFF75A50F98
	internal static String get_FaultCannotHaveCatchOrFinally() { }

	// RVA: 0xFFFFFFFF75A50FD8
	internal static String get_TryMustHaveCatchFinallyOrFault() { }

	// RVA: 0xFFFFFFFF75A51018
	internal static String get_BodyOfCatchMustHaveSameTypeAsBodyOfTry() { }

	// RVA: 0xFFFFFFFF75A51058
	internal static String ExtensionNodeMustOverrideProperty(Object p0) { }

	// RVA: 0xFFFFFFFF75A510A4
	internal static String UserDefinedOperatorMustBeStatic(Object p0) { }

	// RVA: 0xFFFFFFFF75A510F0
	internal static String UserDefinedOperatorMustNotBeVoid(Object p0) { }

	// RVA: 0xFFFFFFFF75A5113C
	internal static String CoercionOperatorNotDefined(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51198
	internal static String UnaryOperatorNotDefined(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A511F4
	internal static String BinaryOperatorNotDefined(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A51258
	internal static String ReferenceEqualityNotDefined(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A512B4
	internal static String OperandTypesDoNotMatchParameters(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51310
	internal static String OverloadOperatorTypeDoesNotMatchConversionType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A5136C
	internal static String get_ConversionIsNotSupportedForArithmeticTypes() { }

	// RVA: 0xFFFFFFFF75A513AC
	internal static String get_ArgumentMustBeArray() { }

	// RVA: 0xFFFFFFFF75A513EC
	internal static String get_ArgumentMustBeBoolean() { }

	// RVA: 0xFFFFFFFF75A5142C
	internal static String get_ArgumentMustBeFieldInfoOrPropertyInfoOrMethod() { }

	// RVA: 0xFFFFFFFF75A5146C
	internal static String get_ArgumentMustBeInstanceMember() { }

	// RVA: 0xFFFFFFFF75A514AC
	internal static String get_ArgumentMustBeInteger() { }

	// RVA: 0xFFFFFFFF75A514EC
	internal static String get_ArgumentMustBeArrayIndexType() { }

	// RVA: 0xFFFFFFFF75A5152C
	internal static String get_ArgumentMustBeSingleDimensionalArrayType() { }

	// RVA: 0xFFFFFFFF75A5156C
	internal static String get_ArgumentTypesMustMatch() { }

	// RVA: 0xFFFFFFFF75A515AC
	internal static String CannotAutoInitializeValueTypeMemberThroughProperty(Object p0) { }

	// RVA: 0xFFFFFFFF75A515F8
	internal static String IncorrectTypeForTypeAs(Object p0) { }

	// RVA: 0xFFFFFFFF75A51644
	internal static String get_CoalesceUsedOnNonNullType() { }

	// RVA: 0xFFFFFFFF75A51684
	internal static String ExpressionTypeCannotInitializeArrayType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A516E0
	internal static String ArgumentTypeDoesNotMatchMember(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A5173C
	internal static String ArgumentMemberNotDeclOnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51798
	internal static String ExpressionTypeDoesNotMatchReturn(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A517F4
	internal static String ExpressionTypeDoesNotMatchAssignment(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51850
	internal static String ExpressionTypeDoesNotMatchLabel(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A518AC
	internal static String ExpressionTypeNotInvocable(Object p0) { }

	// RVA: 0xFFFFFFFF75A518F8
	internal static String InstanceFieldNotDefinedForType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51954
	internal static String FieldInfoNotDefinedForType(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A519B8
	internal static String get_IncorrectNumberOfIndexes() { }

	// RVA: 0xFFFFFFFF75A519F8
	internal static String get_IncorrectNumberOfLambdaDeclarationParameters() { }

	// RVA: 0xFFFFFFFF75A51A38
	internal static String get_IncorrectNumberOfMembersForGivenConstructor() { }

	// RVA: 0xFFFFFFFF75A51A78
	internal static String get_IncorrectNumberOfArgumentsForMembers() { }

	// RVA: 0xFFFFFFFF75A51AB8
	internal static String get_LambdaTypeMustBeDerivedFromSystemDelegate() { }

	// RVA: 0xFFFFFFFF75A51AF8
	internal static String MemberNotFieldOrProperty(Object p0) { }

	// RVA: 0xFFFFFFFF75A51B44
	internal static String MethodContainsGenericParameters(Object p0) { }

	// RVA: 0xFFFFFFFF75A51B90
	internal static String MethodIsGeneric(Object p0) { }

	// RVA: 0xFFFFFFFF75A51BDC
	internal static String MethodNotPropertyAccessor(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51C38
	internal static String PropertyDoesNotHaveGetter(Object p0) { }

	// RVA: 0xFFFFFFFF75A51C84
	internal static String PropertyDoesNotHaveAccessor(Object p0) { }

	// RVA: 0xFFFFFFFF75A51CD0
	internal static String ParameterExpressionNotValidAsDelegate(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51D2C
	internal static String PropertyNotDefinedForType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51D88
	internal static String InstancePropertyNotDefinedForType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51DE4
	internal static String InstanceAndMethodTypeMismatch(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A51E48
	internal static String UnhandledBinary(Object p0) { }

	// RVA: 0xFFFFFFFF75A51E94
	internal static String UnhandledUnary(Object p0) { }

	// RVA: 0xFFFFFFFF75A51EE0
	internal static String UserDefinedOpMustHaveConsistentTypes(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51F3C
	internal static String UserDefinedOpMustHaveValidReturnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51F98
	internal static String LogicalOperatorMustHaveBooleanOperators(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A51FF4
	internal static String MethodWithArgsDoesNotExistOnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A52050
	internal static String GenericMethodWithArgsDoesNotExistOnType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A520AC
	internal static String MethodWithMoreThanOneMatch(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A52108
	internal static String get_ArgumentCannotBeOfTypeVoid() { }

	// RVA: 0xFFFFFFFF75A52148
	internal static String LabelTargetAlreadyDefined(Object p0) { }

	// RVA: 0xFFFFFFFF75A52194
	internal static String LabelTargetUndefined(Object p0) { }

	// RVA: 0xFFFFFFFF75A521E0
	internal static String get_ControlCannotLeaveFinally() { }

	// RVA: 0xFFFFFFFF75A52220
	internal static String get_ControlCannotLeaveFilterTest() { }

	// RVA: 0xFFFFFFFF75A52260
	internal static String AmbiguousJump(Object p0) { }

	// RVA: 0xFFFFFFFF75A522AC
	internal static String get_ControlCannotEnterTry() { }

	// RVA: 0xFFFFFFFF75A522EC
	internal static String get_ControlCannotEnterExpression() { }

	// RVA: 0xFFFFFFFF75A5232C
	internal static String NonLocalJumpWithValue(Object p0) { }

	// RVA: 0xFFFFFFFF75A52378
	internal static String InvalidLvalue(Object p0) { }

	// RVA: 0xFFFFFFFF75A523C4
	internal static String get_RethrowRequiresCatch() { }

	// RVA: 0xFFFFFFFF75A52404
	internal static String MustRewriteToSameNode(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A52468
	internal static String MustRewriteChildToSameType(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A524CC
	internal static String MustRewriteWithoutMethod(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A52528
	internal static String get_NonStaticConstructorRequired() { }

	// RVA: 0xFFFFFFFF75A52568
	internal static String get_NonAbstractConstructorRequired() { }

	// RVA: 0xFFFFFFFF75A525A8
	internal static String get_ExpressionMustBeReadable() { }

	// RVA: 0xFFFFFFFF75A525E8
	internal static String ExpressionTypeDoesNotMatchConstructorParameter(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A52644
	internal static String get_EnumerationIsDone() { }

	// RVA: 0xFFFFFFFF75A52650
	internal static String TypeContainsGenericParameters(Object p0) { }

	// RVA: 0xFFFFFFFF75A5269C
	internal static String TypeIsGeneric(Object p0) { }

	// RVA: 0xFFFFFFFF75A526E8
	internal static String get_InvalidArgumentValue() { }

	// RVA: 0xFFFFFFFF75A52728
	internal static String InvalidNullValue(Object p0) { }

	// RVA: 0xFFFFFFFF75A52774
	internal static String InvalidObjectType(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A527D0
	internal static String ExpressionTypeDoesNotMatchMethodParameter(Object p0, Object p1, Object p2) { }

	// RVA: 0xFFFFFFFF75A52834
	internal static String ExpressionTypeDoesNotMatchParameter(Object p0, Object p1) { }

	// RVA: 0xFFFFFFFF75A52890
	internal static String IncorrectNumberOfMethodCallArguments(Object p0) { }

	// RVA: 0xFFFFFFFF75A528DC
	internal static String get_IncorrectNumberOfLambdaArguments() { }

	// RVA: 0xFFFFFFFF75A5291C
	internal static String get_IncorrectNumberOfConstructorArguments() { }

}

// Namespace: System.Linq.Expressions
public sealed class SwitchCase
{
	// Fields
	private readonly ReadOnlyCollection<T0> <TestValues>k__BackingField; // 0x10
	private readonly Expression <Body>k__BackingField; // 0x18

	// Properties
	public ReadOnlyCollection<T0> TestValues { get; }
	public Expression Body { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A5295C
	public ReadOnlyCollection<T0> get_TestValues() { }

	// RVA: 0xFFFFFFFF75A52964
	public Expression get_Body() { }

}

// Namespace: System.Linq.Expressions
public sealed class SwitchExpression
{
	// Fields
	private readonly Expression <SwitchValue>k__BackingField; // 0x10
	private readonly ReadOnlyCollection<T0> <Cases>k__BackingField; // 0x18
	private readonly Expression <DefaultBody>k__BackingField; // 0x20
	private readonly MethodInfo <Comparison>k__BackingField; // 0x28

	// Properties
	public Expression SwitchValue { get; }
	public ReadOnlyCollection<T0> Cases { get; }
	public Expression DefaultBody { get; }
	public MethodInfo Comparison { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A5296C
	public Expression get_SwitchValue() { }

	// RVA: 0xFFFFFFFF75A52974
	public ReadOnlyCollection<T0> get_Cases() { }

	// RVA: 0xFFFFFFFF75A5297C
	public Expression get_DefaultBody() { }

	// RVA: 0xFFFFFFFF75A52984
	public MethodInfo get_Comparison() { }

}

// Namespace: System.Linq.Expressions
public class SymbolDocumentInfo
{
	// Fields
	private readonly String <FileName>k__BackingField; // 0x10
	internal static readonly Guid DocumentType_Text; // 0x0

	// Properties
	public String FileName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A5298C
	public String get_FileName() { }

	// RVA: 0xFFFFFFFF75A52994
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions
public sealed class TryExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x10
	private readonly Expression <Body>k__BackingField; // 0x18
	private readonly ReadOnlyCollection<T0> <Handlers>k__BackingField; // 0x20
	private readonly Expression <Finally>k__BackingField; // 0x28
	private readonly Expression <Fault>k__BackingField; // 0x30

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public Expression Body { get; }
	public ReadOnlyCollection<T0> Handlers { get; }
	public Expression Finally { get; }
	public Expression Fault { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A52A24
	internal Void .ctor(Type type, Expression body, Expression finally, Expression fault, ReadOnlyCollection<T0> handlers) { }

	// RVA: 0xFFFFFFFF75A52B00
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A52B08
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A52B10
	public Expression get_Body() { }

	// RVA: 0xFFFFFFFF75A52B18
	public ReadOnlyCollection<T0> get_Handlers() { }

	// RVA: 0xFFFFFFFF75A52B20
	public Expression get_Finally() { }

	// RVA: 0xFFFFFFFF75A52B28
	public Expression get_Fault() { }

	// RVA: 0xFFFFFFFF75A52B30
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A52B60
	public TryExpression Update(Expression body, IEnumerable<T0> handlers, Expression finally, Expression fault) { }

}

// Namespace: System.Linq.Expressions
public sealed class TypeBinaryExpression
{
	// Fields
	private readonly Expression <Expression>k__BackingField; // 0x10
	private readonly Type <TypeOperand>k__BackingField; // 0x18

	// Properties
	public Expression Expression { get; }
	public Type TypeOperand { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A52C58
	public Expression get_Expression() { }

	// RVA: 0xFFFFFFFF75A52C60
	public Type get_TypeOperand() { }

}

// Namespace: System.Linq.Expressions
public sealed class UnaryExpression
{
	// Fields
	private readonly Type <Type>k__BackingField; // 0x10
	private readonly ExpressionType <NodeType>k__BackingField; // 0x18
	private readonly Expression <Operand>k__BackingField; // 0x20
	private readonly MethodInfo <Method>k__BackingField; // 0x28

	// Properties
	public sealed override Type Type { get; }
	public sealed override ExpressionType NodeType { get; }
	public Expression Operand { get; }
	public MethodInfo Method { get; }
	public Boolean IsLifted { get; }
	public Boolean IsLiftedToNull { get; }
	public override Boolean CanReduce { get; }
	private Boolean IsPrefix { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A52CAC
	internal Void .ctor(ExpressionType nodeType, Expression expression, Type type, MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A52D60
	public sealed override Type get_Type() { }

	// RVA: 0xFFFFFFFF75A52D68
	public sealed override ExpressionType get_NodeType() { }

	// RVA: 0xFFFFFFFF75A52D70
	public Expression get_Operand() { }

	// RVA: 0xFFFFFFFF75A52D78
	public MethodInfo get_Method() { }

	// RVA: 0xFFFFFFFF75A52D80
	public Boolean get_IsLifted() { }

	// RVA: 0xFFFFFFFF75A52F60
	public Boolean get_IsLiftedToNull() { }

	// RVA: 0xFFFFFFFF75A52FA8
	protected internal override Expression Accept(ExpressionVisitor visitor) { }

	// RVA: 0xFFFFFFFF75A52FD8
	public override Boolean get_CanReduce() { }

	// RVA: 0xFFFFFFFF75A53004
	public override Expression Reduce() { }

	// RVA: 0xFFFFFFFF75A53B68
	private Boolean get_IsPrefix() { }

	// RVA: 0xFFFFFFFF75A53BC0
	private UnaryExpression FunctionalOp(Expression operand) { }

	// RVA: 0xFFFFFFFF75A5391C
	private Expression ReduceVariable() { }

	// RVA: 0xFFFFFFFF75A53598
	private Expression ReduceMember() { }

	// RVA: 0xFFFFFFFF75A53094
	private Expression ReduceIndex() { }

	// RVA: 0xFFFFFFFF75A53C9C
	public UnaryExpression Update(Expression operand) { }

}

// Namespace: System.Linq.Expressions
internal static class Utils
{
	// Fields
	public static readonly Object BoxedFalse; // 0x0
	public static readonly Object BoxedTrue; // 0x8
	public static readonly Object BoxedIntM1; // 0x10
	public static readonly Object BoxedInt0; // 0x18
	public static readonly Object BoxedInt1; // 0x20
	public static readonly Object BoxedInt2; // 0x28
	public static readonly Object BoxedInt3; // 0x30
	public static readonly Object BoxedDefaultSByte; // 0x38
	public static readonly Object BoxedDefaultChar; // 0x40
	public static readonly Object BoxedDefaultInt16; // 0x48
	public static readonly Object BoxedDefaultInt64; // 0x50
	public static readonly Object BoxedDefaultByte; // 0x58
	public static readonly Object BoxedDefaultUInt16; // 0x60
	public static readonly Object BoxedDefaultUInt32; // 0x68
	public static readonly Object BoxedDefaultUInt64; // 0x70
	public static readonly Object BoxedDefaultSingle; // 0x78
	public static readonly Object BoxedDefaultDouble; // 0x80
	public static readonly Object BoxedDefaultDecimal; // 0x88
	public static readonly Object BoxedDefaultDateTime; // 0x90
	private static readonly ConstantExpression s_true; // 0x98
	private static readonly ConstantExpression s_false; // 0xA0
	private static readonly ConstantExpression s_m1; // 0xA8
	private static readonly ConstantExpression s_0; // 0xB0
	private static readonly ConstantExpression s_1; // 0xB8
	private static readonly ConstantExpression s_2; // 0xC0
	private static readonly ConstantExpression s_3; // 0xC8
	public static readonly DefaultExpression Empty; // 0xD0
	public static readonly ConstantExpression Null; // 0xD8

	// Methods

	// RVA: 0xFFFFFFFF75A53D68
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class AddInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A166D4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A166DC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A166E4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A16724
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1672C
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class AddInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A16B88
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A16A2C
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A16CB4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A16A34
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A16DD0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A16A3C
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A17030
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1715C
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A17164
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A17290
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A17298
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A173C4
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A16EFC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A16A44
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A16A54
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A16A4C
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class AddOvfInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A173CC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A173D4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A173DC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1741C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1742C
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class AddOvfInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A176CC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1769C
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddOvfInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A1790C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A176A4
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddOvfInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A17B18
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A176AC
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddOvfUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A17CF0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A176B4
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddOvfUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A17F30
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A176BC
	public Void .ctor() { }

}

// Namespace: 
private sealed class AddOvfUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A180F0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A176C4
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class AndInstruction
{
	// Fields
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Int32; // 0x10
	private static Instruction s_Int64; // 0x18
	private static Instruction s_Byte; // 0x20
	private static Instruction s_UInt16; // 0x28
	private static Instruction s_UInt32; // 0x30
	private static Instruction s_UInt64; // 0x38
	private static Instruction s_Boolean; // 0x40

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A182AC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A182B4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A182BC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A182FC
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A18304
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class AndSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A18DB8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18658
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A18A7C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18660
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A18BB8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18668
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A18CDC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18670
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A18944
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18678
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A18EF4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18680
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A1902C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18688
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A19108
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18690
	public Void .ctor() { }

}

// Namespace: 
private sealed class AndBoolean
{
	// Methods

	// RVA: 0xFFFFFFFF75A186A0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A18698
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NewArrayInitInstruction
{
	// Fields
	private readonly Type _elementType; // 0x10
	private readonly Int32 _elementCount; // 0x18

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A42788
	internal Void .ctor(Type elementType, Int32 elementCount) { }

	// RVA: 0xFFFFFFFF75A427D0
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A427D8
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A427E0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A42820
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NewArrayInstruction
{
	// Fields
	private readonly Type _elementType; // 0x10

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A428B8
	internal Void .ctor(Type elementType) { }

	// RVA: 0xFFFFFFFF75A428EC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A428F4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A428FC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4293C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NewArrayBoundsInstruction
{
	// Fields
	private readonly Type _elementType; // 0x10
	private readonly Int32 _rank; // 0x18

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A425E0
	internal Void .ctor(Type elementType, Int32 rank) { }

	// RVA: 0xFFFFFFFF75A42628
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A42630
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A42638
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A42678
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class GetArrayItemInstruction
{
	// Fields
	internal static readonly GetArrayItemInstruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A223F8
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A22400
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A22408
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A22410
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A22450
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A224E0
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class SetArrayItemInstruction
{
	// Fields
	internal static readonly SetArrayItemInstruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A0A4
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A4A0AC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A0B4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A0F4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4A1A0
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ArrayLengthInstruction
{
	// Fields
	public static readonly ArrayLengthInstruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A19468
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A19470
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A19478
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A194B8
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A194C0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1953C
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class ConvertHelper
{
	// Methods

	// RVA: 0xFFFFFFFF75A1C2D8
	public static Int32 ToInt32NoNull(Object val) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct RuntimeLabel
{
	// Fields
	public readonly Int32 Index; // 0x10
	public readonly Int32 StackDepth; // 0x14
	public readonly Int32 ContinuationStackDepth; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF71144CD4
	public Void .ctor(Int32 index, Int32 continuationStackDepth, Int32 stackDepth) { }

	// RVA: 0xFFFFFFFF71144CE0
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class BranchLabel
{
	// Fields
	private Int32 _targetIndex; // 0x10
	private Int32 _stackDepth; // 0x14
	private Int32 _continuationStackDepth; // 0x18
	private List<T0> _forwardBranchFixups; // 0x20
	private Int32 <LabelIndex>k__BackingField; // 0x28

	// Properties
	internal Int32 LabelIndex { get; set; }
	internal Boolean HasRuntimeLabel { get; }
	internal Int32 TargetIndex { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A19F38
	internal Int32 get_LabelIndex() { }

	// RVA: 0xFFFFFFFF75A19F40
	internal Void set_LabelIndex(Int32 value) { }

	// RVA: 0xFFFFFFFF75A19F48
	internal Boolean get_HasRuntimeLabel() { }

	// RVA: 0xFFFFFFFF75A19F5C
	internal Int32 get_TargetIndex() { }

	// RVA: 0xFFFFFFFF75A19F64
	internal RuntimeLabel ToRuntimeLabel() { }

	// RVA: 0xFFFFFFFF75A19FA0
	internal Void Mark(InstructionList instructions) { }

	// RVA: 0xFFFFFFFF75A1A0F0
	internal Void AddBranch(InstructionList instructions, Int32 branchIndex) { }

	// RVA: 0xFFFFFFFF75A1A0C4
	internal Void FixupBranch(InstructionList instructions, Int32 branchIndex) { }

	// RVA: 0xFFFFFFFF75A1A27C
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class CallInstruction
{
	// Properties
	public abstract Int32 ArgumentCount { get; }
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: -1
	public abstract Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A1AD64
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1ADA4
	public static CallInstruction Create(MethodInfo info) { }

	// RVA: 0xFFFFFFFF75A1AE10
	public static CallInstruction Create(MethodInfo info, ParameterInfo[] parameters) { }

	// RVA: 0xFFFFFFFF75A1AF80
	private static CallInstruction GetArrayAccessor(MethodInfo info, Int32 argumentCount) { }

	// RVA: 0xFFFFFFFF75A1B308
	public static Void ArrayItemSetter1(Array array, Int32 index0, Object value) { }

	// RVA: 0xFFFFFFFF75A1B32C
	public static Void ArrayItemSetter2(Array array, Int32 index0, Int32 index1, Object value) { }

	// RVA: 0xFFFFFFFF75A1B354
	public static Void ArrayItemSetter3(Array array, Int32 index0, Int32 index1, Int32 index2, Object value) { }

	// RVA: 0xFFFFFFFF75A1B380
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1A90C
	protected static Boolean TryGetLightLambdaTarget(Object instance, out LightLambda lightLambda) { }

	// RVA: 0xFFFFFFFF75A1AA60
	protected Object InterpretLambdaInvoke(LightLambda targetLambda, Object[] args) { }

	// RVA: 0xFFFFFFFF75A1B390
	protected Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class MethodInfoCallInstruction
{
	// Fields
	protected readonly MethodInfo _target; // 0x10
	protected readonly Int32 _argumentCount; // 0x18

	// Properties
	public override Int32 ArgumentCount { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3EB64
	public override Int32 get_ArgumentCount() { }

	// RVA: 0xFFFFFFFF75A3EB6C
	internal Void .ctor(MethodInfo target, Int32 argumentCount) { }

	// RVA: 0xFFFFFFFF75A3EBB4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3EC30
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3EEE8
	protected Object[] GetArgs(InterpretedFrame frame, Int32 first, Int32 skip) { }

	// RVA: 0xFFFFFFFF75A3F050
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class ByRefMethodInfoCallInstruction
{
	// Fields
	private readonly ByRefUpdater[] _byrefArgs; // 0x20

	// Properties
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1A3D8
	internal Void .ctor(MethodInfo target, Int32 argumentCount, ByRefUpdater[] byrefArgs) { }

	// RVA: 0xFFFFFFFF75A1A40C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1A488
	public sealed override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class OffsetInstruction
{
	// Fields
	protected Int32 _offset; // 0x10

	// Properties
	public abstract Instruction[] Cache { get; }

	// Methods

	// RVA: -1
	public abstract Instruction[] get_Cache() { }

	// RVA: 0xFFFFFFFF75A475E8
	public Instruction Fixup(Int32 offset) { }

	// RVA: 0xFFFFFFFF75A4765C
	public override String ToString() { }

	// RVA: 0xFFFFFFFF75A47714
	protected Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class BranchFalseInstruction
{
	// Fields
	private static Instruction[] s_cache; // 0x0

	// Properties
	public override Instruction[] Cache { get; }
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A19B5C
	public override Instruction[] get_Cache() { }

	// RVA: 0xFFFFFFFF75A19BE4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A19C24
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A19C2C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A19C94
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class BranchTrueInstruction
{
	// Fields
	private static Instruction[] s_cache; // 0x0

	// Properties
	public override Instruction[] Cache { get; }
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1A298
	public override Instruction[] get_Cache() { }

	// RVA: 0xFFFFFFFF75A1A320
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1A360
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1A368
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1A3D0
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CoalescingBranchInstruction
{
	// Fields
	private static Instruction[] s_cache; // 0x0

	// Properties
	public override Instruction[] Cache { get; }
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1C1BC
	public override Instruction[] get_Cache() { }

	// RVA: 0xFFFFFFFF75A1C244
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1C284
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1C28C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1C294
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1C2D0
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class BranchInstruction
{
	// Fields
	private static Instruction[][][] s_caches; // 0x0
	internal readonly Boolean _hasResult; // 0x14
	internal readonly Boolean _hasValue; // 0x15

	// Properties
	public override Instruction[] Cache { get; }
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A19C9C
	public override Instruction[] get_Cache() { }

	// RVA: 0xFFFFFFFF75A19E7C
	internal Void .ctor() { }

	// RVA: 0xFFFFFFFF75A19EA4
	public Void .ctor(Boolean hasResult, Boolean hasValue) { }

	// RVA: 0xFFFFFFFF75A19EE0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A19F20
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A19F28
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A19F30
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class IndexedBranchInstruction
{
	// Fields
	internal readonly Int32 _labelIndex; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A1E86C
	public Void .ctor(Int32 labelIndex) { }

	// RVA: 0xFFFFFFFF75A1EA34
	public RuntimeLabel GetLabel(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25EA0
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class GotoInstruction
{
	// Fields
	private static readonly GotoInstruction[] s_cache; // 0x0
	private readonly Boolean _hasResult; // 0x14
	private readonly Boolean _hasValue; // 0x15
	private readonly Boolean _labelTargetGetsValue; // 0x16

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A22540
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A22580
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A22588
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A22590
	private Void .ctor(Int32 targetIndex, Boolean hasResult, Boolean hasValue, Boolean labelTargetGetsValue) { }

	// RVA: 0xFFFFFFFF75A225E4
	internal static GotoInstruction Create(Int32 labelIndex, Boolean hasResult, Boolean hasValue, Boolean labelTargetGetsValue) { }

	// RVA: 0xFFFFFFFF75A22740
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A22814
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterTryCatchFinallyInstruction
{
	// Fields
	private readonly Boolean _hasFinally; // 0x14
	private TryCatchFinallyHandler _tryHandler; // 0x18

	// Properties
	public override Int32 ProducedContinuations { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1EE0C
	internal Void SetTryHandler(TryCatchFinallyHandler tryHandler) { }

	// RVA: 0xFFFFFFFF75A1EE14
	public override Int32 get_ProducedContinuations() { }

	// RVA: 0xFFFFFFFF75A1EE1C
	private Void .ctor(Int32 targetIndex, Boolean hasFinally) { }

	// RVA: 0xFFFFFFFF75A1EE58
	internal static EnterTryCatchFinallyInstruction CreateTryFinally(Int32 labelIndex) { }

	// RVA: 0xFFFFFFFF75A1EEBC
	internal static EnterTryCatchFinallyInstruction CreateTryCatch() { }

	// RVA: 0xFFFFFFFF75A1EF1C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1F578
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1F5E8
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterTryFaultInstruction
{
	// Fields
	private TryFaultHandler _tryHandler; // 0x18

	// Properties
	public override String InstructionName { get; }
	public override Int32 ProducedContinuations { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1F680
	internal Void .ctor(Int32 targetIndex) { }

	// RVA: 0xFFFFFFFF75A1F6AC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1F6EC
	public override Int32 get_ProducedContinuations() { }

	// RVA: 0xFFFFFFFF75A1F6F4
	internal Void SetTryHandler(TryFaultHandler tryHandler) { }

	// RVA: 0xFFFFFFFF75A1F6FC
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterFinallyInstruction
{
	// Fields
	private static readonly EnterFinallyInstruction[] s_cache; // 0x0

	// Properties
	public override String InstructionName { get; }
	public override Int32 ProducedStack { get; }
	public override Int32 ConsumedContinuations { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1EBB8
	private Void .ctor(Int32 labelIndex) { }

	// RVA: 0xFFFFFFFF75A1EBE4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1EC24
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1EC2C
	public override Int32 get_ConsumedContinuations() { }

	// RVA: 0xFFFFFFFF75A1EC34
	internal static EnterFinallyInstruction Create(Int32 labelIndex) { }

	// RVA: 0xFFFFFFFF75A1ED30
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1EDA4
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveFinallyInstruction
{
	// Fields
	internal static readonly Instruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2DACC
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A2DAD4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2DADC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2DB1C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DB64
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterFaultInstruction
{
	// Fields
	private static readonly EnterFaultInstruction[] s_cache; // 0x0

	// Properties
	public override String InstructionName { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1E840
	private Void .ctor(Int32 labelIndex) { }

	// RVA: 0xFFFFFFFF75A1E898
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1E8D8
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1E8E0
	internal static EnterFaultInstruction Create(Int32 labelIndex) { }

	// RVA: 0xFFFFFFFF75A1E9DC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1EB50
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveFaultInstruction
{
	// Fields
	internal static readonly Instruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ConsumedContinuations { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2D9F0
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A2D9F8
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2DA00
	public override Int32 get_ConsumedContinuations() { }

	// RVA: 0xFFFFFFFF75A2DA08
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2DA48
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DA6C
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterExceptionFilterInstruction
{
	// Fields
	internal static readonly EnterExceptionFilterInstruction Instance; // 0x0

	// Properties
	public override String InstructionName { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1E670
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1E678
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1E6B8
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1E6C0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1E6C8
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveExceptionFilterInstruction
{
	// Fields
	internal static readonly LeaveExceptionFilterInstruction Instance; // 0x0

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2D814
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A2D81C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2D85C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2D864
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2D86C
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterExceptionHandlerInstruction
{
	// Fields
	internal static readonly EnterExceptionHandlerInstruction Void; // 0x0
	internal static readonly EnterExceptionHandlerInstruction NonVoid; // 0x8
	private readonly Boolean _hasValue; // 0x10

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1E728
	private Void .ctor(Boolean hasValue) { }

	// RVA: 0xFFFFFFFF75A1E754
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1E794
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1E79C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1E7A4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1E7AC
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveExceptionHandlerInstruction
{
	// Fields
	private static readonly LeaveExceptionHandlerInstruction[] s_cache; // 0x0
	private readonly Boolean _hasValue; // 0x14

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2D8CC
	private Void .ctor(Int32 labelIndex, Boolean hasValue) { }

	// RVA: 0xFFFFFFFF75A2D908
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2D948
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2D950
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A2BB70
	internal static LeaveExceptionHandlerInstruction Create(Int32 labelIndex, Boolean hasValue) { }

	// RVA: 0xFFFFFFFF75A2D958
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2D988
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ThrowInstruction
{
	// Fields
	internal static readonly ThrowInstruction Throw; // 0x0
	internal static readonly ThrowInstruction VoidThrow; // 0x8
	internal static readonly ThrowInstruction Rethrow; // 0x10
	internal static readonly ThrowInstruction VoidRethrow; // 0x18
	private static ConstructorInfo _runtimeWrappedExceptionCtor; // 0x20
	private readonly Boolean _hasResult; // 0x10
	private readonly Boolean _rethrow; // 0x11

	// Properties
	public override String InstructionName { get; }
	public override Int32 ProducedStack { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4C358
	private Void .ctor(Boolean hasResult, Boolean isRethrow) { }

	// RVA: 0xFFFFFFFF75A4C394
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4C3D4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4C3DC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4C3E4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4C4A8
	private static Exception WrapThrownObject(Object thrown) { }

	// RVA: 0xFFFFFFFF75A4C548
	private static RuntimeWrappedException RuntimeWrap(Object thrown) { }

	// RVA: 0xFFFFFFFF75A4C6CC
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class IntSwitchInstruction<T0>
{
	// Fields
	private readonly Dictionary<T0, T1> _cases; // 0x0

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: -1
	internal Void .ctor(Dictionary<T0, T1> cases) { }

	// RVA: -1
	public override String get_InstructionName() { }

	// RVA: -1
	public override Int32 get_ConsumedStack() { }

	// RVA: -1
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StringSwitchInstruction
{
	// Fields
	private readonly Dictionary<T0, T1> _cases; // 0x10
	private readonly StrongBox<T0> _nullCase; // 0x18

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A684
	internal Void .ctor(Dictionary<T0, T1> cases, StrongBox<T0> nullCase) { }

	// RVA: 0xFFFFFFFF75A4A6D4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A714
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A71C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class DecrementInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1C930
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1C938
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1C940
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1C980
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1C988
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class DecrementInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CD68
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CC94
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CDE4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CC9C
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CE5C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CCA4
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CF80
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CCAC
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CFFC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CCB4
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A1D08C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CCBC
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CEEC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CCC4
	public Void .ctor() { }

}

// Namespace: 
private sealed class DecrementDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A1CCD4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1CCCC
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class DefaultValueInstruction
{
	// Fields
	private readonly Type _type; // 0x10

	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1D11C
	internal Void .ctor(Type type) { }

	// RVA: 0xFFFFFFFF75A1D150
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1D158
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1D198
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1D1D8
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class DivInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1D82C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1D834
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1D83C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1D87C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1D884
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class DivInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A1DD04
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DB90
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A1DE30
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DB98
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A1DF4C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DBA0
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A1E1AC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DBA8
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A1E2D8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DBB0
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A1E404
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DBB8
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A1E078
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DBC0
	public Void .ctor() { }

}

// Namespace: 
private sealed class DivDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A1DBD0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1DBC8
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class EqualInstruction
{
	// Fields
	private static Instruction s_reference; // 0x0
	private static Instruction s_Boolean; // 0x8
	private static Instruction s_SByte; // 0x10
	private static Instruction s_Int16; // 0x18
	private static Instruction s_Char; // 0x20
	private static Instruction s_Int32; // 0x28
	private static Instruction s_Int64; // 0x30
	private static Instruction s_Byte; // 0x38
	private static Instruction s_UInt16; // 0x40
	private static Instruction s_UInt32; // 0x48
	private static Instruction s_UInt64; // 0x50
	private static Instruction s_Single; // 0x58
	private static Instruction s_Double; // 0x60
	private static Instruction s_BooleanLiftedToNull; // 0x68
	private static Instruction s_SByteLiftedToNull; // 0x70
	private static Instruction s_Int16LiftedToNull; // 0x78
	private static Instruction s_CharLiftedToNull; // 0x80
	private static Instruction s_Int32LiftedToNull; // 0x88
	private static Instruction s_Int64LiftedToNull; // 0x90
	private static Instruction s_ByteLiftedToNull; // 0x98
	private static Instruction s_UInt16LiftedToNull; // 0xA0
	private static Instruction s_UInt32LiftedToNull; // 0xA8
	private static Instruction s_UInt64LiftedToNull; // 0xB0
	private static Instruction s_SingleLiftedToNull; // 0xB8
	private static Instruction s_DoubleLiftedToNull; // 0xC0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1F908
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1F910
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1F918
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1F958
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1F960
	public static Instruction Create(Type type, Boolean liftedToNull) { }

}

// Namespace: 
private sealed class EqualBoolean
{
	// Methods

	// RVA: 0xFFFFFFFF75A2022C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201C4
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A20CEC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201CC
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2082C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201D4
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualChar
{
	// Methods

	// RVA: 0xFFFFFFFF75A20524
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201DC
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A209A8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201E4
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A20B24
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201EC
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A203A8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201F4
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A20FF4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201FC
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A21170
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20204
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A212EC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2020C
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A20E68
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20214
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A206A0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2021C
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualReference
{
	// Methods

	// RVA: 0xFFFFFFFF75A20CA0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20224
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualBooleanLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A202E8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20164
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualSByteLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A20DA8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2016C
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualInt16LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A208E8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20174
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualCharLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A205E0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2017C
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualInt32LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A20A64
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20184
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualInt64LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A20BE0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2018C
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualByteLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A20464
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A20194
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualUInt16LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A210B0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2019C
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualUInt32LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A2122C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201A4
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualUInt64LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A213A8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201AC
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualSingleLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A20F2C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201B4
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualDoubleLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A20764
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A201BC
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class ExclusiveOrInstruction
{
	// Fields
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Int32; // 0x10
	private static Instruction s_Int64; // 0x18
	private static Instruction s_Byte; // 0x20
	private static Instruction s_UInt16; // 0x28
	private static Instruction s_UInt32; // 0x30
	private static Instruction s_UInt64; // 0x38
	private static Instruction s_Boolean; // 0x40

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A21628
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A21630
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A21638
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A21678
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A21680
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class ExclusiveOrSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A21E10
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A219D4
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A21BA8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A219DC
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A21C70
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A219E4
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A21D34
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A219EC
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A21AE4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A219F4
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A21ED8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A219FC
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A21F9C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A21A04
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A22078
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A21A0C
	public Void .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrBoolean
{
	// Methods

	// RVA: 0xFFFFFFFF75A21A1C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A21A14
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class FieldInstruction
{
	// Fields
	protected readonly FieldInfo _field; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A22330
	public Void .ctor(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A22364
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadStaticFieldInstruction
{
	// Properties
	public override String InstructionName { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3E130
	public Void .ctor(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A3E138
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3E178
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3E180
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadFieldInstruction
{
	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3D930
	public Void .ctor(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A3D938
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3D978
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A3D980
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3D988
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreFieldInstruction
{
	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A200
	public Void .ctor(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A4A208
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A248
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A250
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreStaticFieldInstruction
{
	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A5E8
	public Void .ctor(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A4A5F0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A630
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A638
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class GreaterThanInstruction
{
	// Fields
	private readonly Object _nullValue; // 0x10
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Char; // 0x10
	private static Instruction s_Int32; // 0x18
	private static Instruction s_Int64; // 0x20
	private static Instruction s_Byte; // 0x28
	private static Instruction s_UInt16; // 0x30
	private static Instruction s_UInt32; // 0x38
	private static Instruction s_UInt64; // 0x40
	private static Instruction s_Single; // 0x48
	private static Instruction s_Double; // 0x50
	private static Instruction s_liftedToNullSByte; // 0x58
	private static Instruction s_liftedToNullInt16; // 0x60
	private static Instruction s_liftedToNullChar; // 0x68
	private static Instruction s_liftedToNullInt32; // 0x70
	private static Instruction s_liftedToNullInt64; // 0x78
	private static Instruction s_liftedToNullByte; // 0x80
	private static Instruction s_liftedToNullUInt16; // 0x88
	private static Instruction s_liftedToNullUInt32; // 0x90
	private static Instruction s_liftedToNullUInt64; // 0x98
	private static Instruction s_liftedToNullSingle; // 0xA0
	private static Instruction s_liftedToNullDouble; // 0xA8

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2287C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A22884
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A2288C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A228CC
	private Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A22900
	public static Instruction Create(Type type, Boolean liftedToNull) { }

}

// Namespace: 
private sealed class GreaterThanSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A232EC
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A239C8
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A23320
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2377C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanChar
{
	// Methods

	// RVA: 0xFFFFFFFF75A23354
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A235EC
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A23388
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23840
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A233BC
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23904
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A233F0
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23528
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A23424
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23B58
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A23458
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23C1C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2348C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23CE0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A234C0
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23A8C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A234F4
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A236B0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class GreaterThanOrEqualInstruction
{
	// Fields
	private readonly Object _nullValue; // 0x10
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Char; // 0x10
	private static Instruction s_Int32; // 0x18
	private static Instruction s_Int64; // 0x20
	private static Instruction s_Byte; // 0x28
	private static Instruction s_UInt16; // 0x30
	private static Instruction s_UInt32; // 0x38
	private static Instruction s_UInt64; // 0x40
	private static Instruction s_Single; // 0x48
	private static Instruction s_Double; // 0x50
	private static Instruction s_liftedToNullSByte; // 0x58
	private static Instruction s_liftedToNullInt16; // 0x60
	private static Instruction s_liftedToNullChar; // 0x68
	private static Instruction s_liftedToNullInt32; // 0x70
	private static Instruction s_liftedToNullInt64; // 0x78
	private static Instruction s_liftedToNullByte; // 0x80
	private static Instruction s_liftedToNullUInt16; // 0x88
	private static Instruction s_liftedToNullUInt32; // 0x90
	private static Instruction s_liftedToNullUInt64; // 0x98
	private static Instruction s_liftedToNullSingle; // 0xA0
	private static Instruction s_liftedToNullDouble; // 0xA8

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A23DA4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A23DAC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A23DB4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A23DF4
	private Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A23E28
	public static Instruction Create(Type type, Boolean liftedToNull) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A24814
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24EF0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A24848
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24CA4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualChar
{
	// Methods

	// RVA: 0xFFFFFFFF75A2487C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24B14
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A248B0
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24D68
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A248E4
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24E2C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A24918
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24A50
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2494C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A25080
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A24980
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A25144
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A249B4
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A25208
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A249E8
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24FB4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A24A1C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A24BD8
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class IncrementInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A252CC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A252D4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A252DC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2531C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A25324
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class IncrementInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A25704
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25630
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A25780
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25638
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A257F8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25640
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2591C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25648
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A25998
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25650
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A25A28
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25658
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A25888
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25660
	public Void .ctor() { }

}

// Namespace: 
private sealed class IncrementDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A25670
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A25668
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class Instruction
{
	// Properties
	public virtual Int32 ConsumedStack { get; }
	public virtual Int32 ProducedStack { get; }
	public virtual Int32 ConsumedContinuations { get; }
	public virtual Int32 ProducedContinuations { get; }
	public abstract String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A26AA4
	public virtual Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A26AAC
	public virtual Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A26AB4
	public virtual Int32 get_ConsumedContinuations() { }

	// RVA: 0xFFFFFFFF75A26ABC
	public virtual Int32 get_ProducedContinuations() { }

	// RVA: -1
	public abstract Int32 Run(InterpretedFrame frame) { }

	// RVA: -1
	public abstract String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A26AC4
	public override String ToString() { }

	// RVA: 0xFFFFFFFF75A1A8F8
	protected static Void NullCheck(Object o) { }

	// RVA: 0xFFFFFFFF75A17424
	protected Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct InstructionArray
{
	// Fields
	internal readonly Int32 MaxStackDepth; // 0x10
	internal readonly Int32 MaxContinuationDepth; // 0x14
	internal readonly Instruction[] Instructions; // 0x18
	internal readonly Object[] Objects; // 0x20
	internal readonly RuntimeLabel[] Labels; // 0x28
	internal readonly List<T0> DebugCookies; // 0x30

	// Methods

	// RVA: 0xFFFFFFFF71144BD8
	internal Void .ctor(Int32 maxStackDepth, Int32 maxContinuationDepth, Instruction[] instructions, Object[] objects, RuntimeLabel[] labels, List<T0> debugCookies) { }

}

// Namespace: 
internal sealed class DebugView
{}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class InstructionList
{
	// Fields
	private readonly List<T0> _instructions; // 0x10
	private List<T0> _objects; // 0x18
	private Int32 _currentStackDepth; // 0x20
	private Int32 _maxStackDepth; // 0x24
	private Int32 _currentContinuationsDepth; // 0x28
	private Int32 _maxContinuationDepth; // 0x2C
	private Int32 _runtimeLabelCount; // 0x30
	private List<T0> _labels; // 0x38
	private List<T0> _debugCookies; // 0x40
	private static Instruction s_null; // 0x0
	private static Instruction s_true; // 0x8
	private static Instruction s_false; // 0x10
	private static Instruction[] s_Ints; // 0x18
	private static Instruction[] s_loadObjectCached; // 0x20
	private static Instruction[] s_loadLocal; // 0x28
	private static Instruction[] s_loadLocalBoxed; // 0x30
	private static Instruction[] s_loadLocalFromClosure; // 0x38
	private static Instruction[] s_loadLocalFromClosureBoxed; // 0x40
	private static Instruction[] s_assignLocal; // 0x48
	private static Instruction[] s_storeLocal; // 0x50
	private static Instruction[] s_assignLocalBoxed; // 0x58
	private static Instruction[] s_storeLocalBoxed; // 0x60
	private static Instruction[] s_assignLocalToClosure; // 0x68
	private static readonly Dictionary<T0, T1> s_loadFields; // 0x70
	private static readonly RuntimeLabel[] s_emptyRuntimeLabels; // 0x78

	// Properties
	public Int32 Count { get; }
	public Int32 CurrentStackDepth { get; }
	public Int32 CurrentContinuationsDepth { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A26B5C
	public Void Emit(Instruction instruction) { }

	// RVA: 0xFFFFFFFF75A26BC8
	private Void UpdateStackDepth(Instruction instruction) { }

	// RVA: 0xFFFFFFFF75A26C90
	public Void UnEmit() { }

	// RVA: 0xFFFFFFFF75A1941C
	public Int32 get_Count() { }

	// RVA: 0xFFFFFFFF75A26DB4
	public Int32 get_CurrentStackDepth() { }

	// RVA: 0xFFFFFFFF75A26DBC
	public Int32 get_CurrentContinuationsDepth() { }

	// RVA: 0xFFFFFFFF75A26DC4
	internal Instruction GetInstruction(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26E38
	public InstructionArray ToArray() { }

	// RVA: 0xFFFFFFFF75A27124
	public Void EmitLoad(Object value) { }

	// RVA: 0xFFFFFFFF75A274EC
	public Void EmitLoad(Boolean value) { }

	// RVA: 0xFFFFFFFF75A2712C
	public Void EmitLoad(Object value, Type type) { }

	// RVA: 0xFFFFFFFF75A27660
	public Void EmitDup() { }

	// RVA: 0xFFFFFFFF75A276C8
	public Void EmitPop() { }

	// RVA: 0xFFFFFFFF75A27730
	internal Void SwitchToBoxed(Int32 index, Int32 instructionIndex) { }

	// RVA: 0xFFFFFFFF75A27868
	public Void EmitLoadLocal(Int32 index) { }

	// RVA: 0xFFFFFFFF75A279C8
	public Void EmitLoadLocalBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A27A3C
	internal static Instruction LoadLocalBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A27B94
	public Void EmitLoadLocalFromClosure(Int32 index) { }

	// RVA: 0xFFFFFFFF75A27CF4
	public Void EmitLoadLocalFromClosureBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A27E54
	public Void EmitAssignLocal(Int32 index) { }

	// RVA: 0xFFFFFFFF75A27FB4
	public Void EmitStoreLocal(Int32 index) { }

	// RVA: 0xFFFFFFFF75A28114
	public Void EmitAssignLocalBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A198B4
	internal static Instruction AssignLocalBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A28188
	public Void EmitStoreLocalBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A281FC
	internal static Instruction StoreLocalBoxed(Int32 index) { }

	// RVA: 0xFFFFFFFF75A28354
	public Void EmitAssignLocalToClosure(Int32 index) { }

	// RVA: 0xFFFFFFFF75A284B4
	public Void EmitStoreLocalToClosure(Int32 index) { }

	// RVA: 0xFFFFFFFF75A284D8
	public Void EmitInitializeLocal(Int32 index, Type type) { }

	// RVA: 0xFFFFFFFF75A28658
	internal Void EmitInitializeParameter(Int32 index) { }

	// RVA: 0xFFFFFFFF75A286CC
	internal static Instruction Parameter(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26770
	internal static Instruction ParameterBox(Int32 index) { }

	// RVA: 0xFFFFFFFF75A285FC
	internal static Instruction InitReference(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26A08
	internal static Instruction InitImmutableRefBox(Int32 index) { }

	// RVA: 0xFFFFFFFF75A28728
	public Void EmitNewRuntimeVariables(Int32 count) { }

	// RVA: 0xFFFFFFFF75A28794
	public Void EmitGetArrayItem() { }

	// RVA: 0xFFFFFFFF75A287FC
	public Void EmitSetArrayItem() { }

	// RVA: 0xFFFFFFFF75A28864
	public Void EmitNewArray(Type elementType) { }

	// RVA: 0xFFFFFFFF75A288D0
	public Void EmitNewArrayBounds(Type elementType, Int32 rank) { }

	// RVA: 0xFFFFFFFF75A28944
	public Void EmitNewArrayInit(Type elementType, Int32 elementCount) { }

	// RVA: 0xFFFFFFFF75A289B8
	public Void EmitAdd(Type type, Boolean checked) { }

	// RVA: 0xFFFFFFFF75A289FC
	public Void EmitSub(Type type, Boolean checked) { }

	// RVA: 0xFFFFFFFF75A28A40
	public Void EmitMul(Type type, Boolean checked) { }

	// RVA: 0xFFFFFFFF75A28A84
	public Void EmitDiv(Type type) { }

	// RVA: 0xFFFFFFFF75A28AB0
	public Void EmitModulo(Type type) { }

	// RVA: 0xFFFFFFFF75A28AE0
	public Void EmitExclusiveOr(Type type) { }

	// RVA: 0xFFFFFFFF75A28B0C
	public Void EmitAnd(Type type) { }

	// RVA: 0xFFFFFFFF75A28B38
	public Void EmitOr(Type type) { }

	// RVA: 0xFFFFFFFF75A28B68
	public Void EmitLeftShift(Type type) { }

	// RVA: 0xFFFFFFFF75A28EA0
	public Void EmitRightShift(Type type) { }

	// RVA: 0xFFFFFFFF75A28ED0
	public Void EmitEqual(Type type, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A28F00
	public Void EmitNotEqual(Type type, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A28F34
	public Void EmitLessThan(Type type, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A29950
	public Void EmitLessThanOrEqual(Type type, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A2A36C
	public Void EmitGreaterThan(Type type, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A2A39C
	public Void EmitGreaterThanOrEqual(Type type, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A2A3CC
	public Void EmitNumericConvertChecked(TypeCode from, TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A2A450
	public Void EmitNumericConvertUnchecked(TypeCode from, TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A2A4D4
	public Void EmitConvertToUnderlying(TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A2A548
	public Void EmitCast(Type toType) { }

	// RVA: 0xFFFFFFFF75A2A574
	public Void EmitCastToEnum(Type toType) { }

	// RVA: 0xFFFFFFFF75A2A5EC
	public Void EmitCastReferenceToEnum(Type toType) { }

	// RVA: 0xFFFFFFFF75A2A664
	public Void EmitNot(Type type) { }

	// RVA: 0xFFFFFFFF75A2A694
	public Void EmitDefaultValue(Type type) { }

	// RVA: 0xFFFFFFFF75A2A70C
	public Void EmitNew(ConstructorInfo constructorInfo, ParameterInfo[] parameters) { }

	// RVA: 0xFFFFFFFF75A2A788
	public Void EmitByRefNew(ConstructorInfo constructorInfo, ParameterInfo[] parameters, ByRefUpdater[] updaters) { }

	// RVA: 0xFFFFFFFF75A2A820
	internal Void EmitCreateDelegate(LightDelegateCreator creator) { }

	// RVA: 0xFFFFFFFF75A2A898
	public Void EmitTypeEquals() { }

	// RVA: 0xFFFFFFFF75A2A900
	public Void EmitArrayLength() { }

	// RVA: 0xFFFFFFFF75A2A968
	public Void EmitNegate(Type type) { }

	// RVA: 0xFFFFFFFF75A2A998
	public Void EmitNegateChecked(Type type) { }

	// RVA: 0xFFFFFFFF75A2A9C8
	public Void EmitIncrement(Type type) { }

	// RVA: 0xFFFFFFFF75A2A9F4
	public Void EmitDecrement(Type type) { }

	// RVA: 0xFFFFFFFF75A2AA20
	public Void EmitTypeIs(Type type) { }

	// RVA: 0xFFFFFFFF75A2AA8C
	public Void EmitTypeAs(Type type) { }

	// RVA: 0xFFFFFFFF75A2AAF8
	public Void EmitLoadField(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A2AB20
	private Instruction GetLoadField(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A2ACF4
	public Void EmitStoreField(FieldInfo field) { }

	// RVA: 0xFFFFFFFF75A2ADA4
	public Void EmitCall(MethodInfo method) { }

	// RVA: 0xFFFFFFFF75A2AE28
	public Void EmitCall(MethodInfo method, ParameterInfo[] parameters) { }

	// RVA: 0xFFFFFFFF75A2AE58
	public Void EmitByRefCall(MethodInfo method, ParameterInfo[] parameters, ByRefUpdater[] byrefArgs) { }

	// RVA: 0xFFFFFFFF75A2AF1C
	public Void EmitNullableCall(MethodInfo method, ParameterInfo[] parameters) { }

	// RVA: 0xFFFFFFFF75A26EFC
	private RuntimeLabel[] BuildRuntimeLabels() { }

	// RVA: 0xFFFFFFFF75A2AF80
	public BranchLabel MakeLabel() { }

	// RVA: 0xFFFFFFFF75A1A194
	internal Void FixupBranch(Int32 branchIndex, Int32 offset) { }

	// RVA: 0xFFFFFFFF75A2B060
	private Int32 EnsureLabelIndex(BranchLabel label) { }

	// RVA: 0xFFFFFFFF75A2B09C
	public Int32 MarkRuntimeLabel() { }

	// RVA: 0xFFFFFFFF75A2B0F0
	public Void MarkLabel(BranchLabel label) { }

	// RVA: 0xFFFFFFFF75A2B110
	public Void EmitGoto(BranchLabel label, Boolean hasResult, Boolean hasValue, Boolean labelTargetGetsValue) { }

	// RVA: 0xFFFFFFFF75A2B1CC
	private Void EmitBranch(OffsetInstruction instruction, BranchLabel label) { }

	// RVA: 0xFFFFFFFF75A2B238
	public Void EmitBranch(BranchLabel label) { }

	// RVA: 0xFFFFFFFF75A2B2A8
	public Void EmitBranch(BranchLabel label, Boolean hasResult, Boolean hasValue) { }

	// RVA: 0xFFFFFFFF75A2B32C
	public Void EmitCoalescingBranch(BranchLabel leftNotNull) { }

	// RVA: 0xFFFFFFFF75A2B398
	public Void EmitBranchTrue(BranchLabel elseLabel) { }

	// RVA: 0xFFFFFFFF75A2B404
	public Void EmitBranchFalse(BranchLabel elseLabel) { }

	// RVA: 0xFFFFFFFF75A2B470
	public Void EmitThrow() { }

	// RVA: 0xFFFFFFFF75A2B4D8
	public Void EmitThrowVoid() { }

	// RVA: 0xFFFFFFFF75A2B540
	public Void EmitRethrow() { }

	// RVA: 0xFFFFFFFF75A2B5A8
	public Void EmitRethrowVoid() { }

	// RVA: 0xFFFFFFFF75A2B610
	public Void EmitEnterTryFinally(BranchLabel finallyStartLabel) { }

	// RVA: 0xFFFFFFFF75A2B660
	public Void EmitEnterTryCatch() { }

	// RVA: 0xFFFFFFFF75A2B688
	public EnterTryFaultInstruction EmitEnterTryFault(BranchLabel tryEnd) { }

	// RVA: 0xFFFFFFFF75A2B724
	public Void EmitEnterFinally(BranchLabel finallyStartLabel) { }

	// RVA: 0xFFFFFFFF75A2B7C0
	public Void EmitLeaveFinally() { }

	// RVA: 0xFFFFFFFF75A2B828
	public Void EmitEnterFault(BranchLabel faultStartLabel) { }

	// RVA: 0xFFFFFFFF75A2B8C4
	public Void EmitLeaveFault() { }

	// RVA: 0xFFFFFFFF75A2B92C
	public Void EmitEnterExceptionFilter() { }

	// RVA: 0xFFFFFFFF75A2B994
	public Void EmitLeaveExceptionFilter() { }

	// RVA: 0xFFFFFFFF75A2B9FC
	public Void EmitEnterExceptionHandlerNonVoid() { }

	// RVA: 0xFFFFFFFF75A2BA64
	public Void EmitEnterExceptionHandlerVoid() { }

	// RVA: 0xFFFFFFFF75A2BACC
	public Void EmitLeaveExceptionHandler(Boolean hasValue, BranchLabel tryExpressionEndLabel) { }

	// RVA: -1
	public Void EmitIntSwitch(Dictionary<T0, T1> cases) { }

	// RVA: 0xFFFFFFFF75A2BC8C
	public Void EmitStringSwitch(Dictionary<T0, T1> cases, StrongBox<T0> nullCase) { }

	// RVA: 0xFFFFFFFF75A2BD00
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A2BD7C
	private static Void .cctor() { }

}

// Namespace: 
internal sealed class DebugView
{}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class InterpretedFrame
{
	// Fields
	private static InterpretedFrame s_currentFrame; // 0xFFFFFFFFFFFFFFFF
	internal readonly Interpreter Interpreter; // 0x10
	internal InterpretedFrame _parent; // 0x18
	private readonly Int32[] _continuations; // 0x20
	private Int32 _continuationIndex; // 0x28
	private Int32 _pendingContinuation; // 0x2C
	private Object _pendingValue; // 0x30
	public readonly Object[] Data; // 0x38
	public readonly IStrongBox[] Closure; // 0x40
	public Int32 StackIndex; // 0x48
	public Int32 InstructionIndex; // 0x4C

	// Properties
	public String Name { get; }
	public InterpretedFrame Parent { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2BE6C
	internal Void .ctor(Interpreter interpreter, IStrongBox[] closure) { }

	// RVA: 0xFFFFFFFF75A2BF7C
	public DebugInfo GetDebugInfo(Int32 instructionIndex) { }

	// RVA: 0xFFFFFFFF75A2BFF8
	public String get_Name() { }

	// RVA: 0xFFFFFFFF75A18830
	public Void Push(Object value) { }

	// RVA: 0xFFFFFFFF75A18878
	public Void Push(Boolean value) { }

	// RVA: 0xFFFFFFFF75A18C7C
	public Void Push(Int32 value) { }

	// RVA: 0xFFFFFFFF75A18A08
	public Void Push(Byte value) { }

	// RVA: 0xFFFFFFFF75A18E80
	public Void Push(SByte value) { }

	// RVA: 0xFFFFFFFF75A18B44
	public Void Push(Int16 value) { }

	// RVA: 0xFFFFFFFF75A18FB8
	public Void Push(UInt16 value) { }

	// RVA: 0xFFFFFFFF75A187E8
	public Object Pop() { }

	// RVA: 0xFFFFFFFF75A1EA88
	internal Void SetStackDepth(Int32 depth) { }

	// RVA: 0xFFFFFFFF75A19730
	public Object Peek() { }

	// RVA: 0xFFFFFFFF75A1E5A4
	public Void Dup() { }

	// RVA: 0xFFFFFFFF75A2C018
	public InterpretedFrame get_Parent() { }

	// RVA: 0xFFFFFFFF75A2C020
	public IEnumerable<T0> GetStackTraceDebugInfo() { }

	// RVA: 0xFFFFFFFF75A2C0D4
	internal Void SaveTraceToException(Exception exception) { }

	// RVA: 0xFFFFFFFF75A2C2E8
	internal InterpretedFrame Enter() { }

	// RVA: 0xFFFFFFFF75A2C364
	internal Void Leave(InterpretedFrame prevFrame) { }

	// RVA: 0xFFFFFFFF75A1ED94
	internal Boolean IsJumpHappened() { }

	// RVA: 0xFFFFFFFF75A1EB40
	public Void RemoveContinuation() { }

	// RVA: 0xFFFFFFFF75A1F400
	public Void PushContinuation(Int32 continuation) { }

	// RVA: 0xFFFFFFFF75A2C3B4
	public Int32 YieldToCurrentContinuation() { }

	// RVA: 0xFFFFFFFF75A2C434
	public Int32 YieldToPendingContinuation() { }

	// RVA: 0xFFFFFFFF75A1EAB0
	internal Void PushPendingContinuation() { }

	// RVA: 0xFFFFFFFF75A2C5B4
	internal Void PopPendingContinuation() { }

	// RVA: 0xFFFFFFFF75A1F448
	public Int32 Goto(Int32 labelIndex, Object value, Boolean gotoExceptionHandler) { }

}

// Namespace: 
private sealed class <GetStackTraceDebugInfo>d__29
{
	// Fields
	private Int32 <>1__state; // 0x10
	private InterpretedFrameInfo <>2__current; // 0x18
	private Int32 <>l__initialThreadId; // 0x28
	public InterpretedFrame <>4__this; // 0x30
	private InterpretedFrame <frame>5__1; // 0x38

	// Properties
	private InterpretedFrameInfo System.Collections.Generic.IEnumerator<System.Linq.Expressions.Interpreter.InterpretedFrameInfo>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2C09C
	public Void .ctor(Int32 <>1__state) { }

	// RVA: 0xFFFFFFFF75A2C620
	private Void System.IDisposable.Dispose() { }

	// RVA: 0xFFFFFFFF75A2C624
	private Boolean MoveNext() { }

	// RVA: 0xFFFFFFFF75A2C750
	private InterpretedFrameInfo System.Collections.Generic.IEnumerator<System.Linq.Expressions.Interpreter.InterpretedFrameInfo>.get_Current() { }

	// RVA: 0xFFFFFFFF75A2C75C
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: 0xFFFFFFFF75A2C7B0
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0xFFFFFFFF75A2C80C
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<System.Linq.Expressions.Interpreter.InterpretedFrameInfo>.GetEnumerator() { }

	// RVA: 0xFFFFFFFF75A2C8B0
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class Interpreter
{
	// Fields
	internal static readonly Object NoValue; // 0x0
	private readonly InstructionArray _instructions; // 0x10
	internal readonly Object[] _objects; // 0x38
	internal readonly RuntimeLabel[] _labels; // 0x40
	internal readonly DebugInfo[] _debugInfos; // 0x48
	private readonly String <Name>k__BackingField; // 0x50
	private readonly Int32 <LocalCount>k__BackingField; // 0x58
	private readonly Dictionary<T0, T1> <ClosureVariables>k__BackingField; // 0x60

	// Properties
	internal String Name { get; }
	internal Int32 LocalCount { get; }
	internal Int32 ClosureSize { get; }
	internal InstructionArray Instructions { get; }
	internal Dictionary<T0, T1> ClosureVariables { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2C910
	internal Void .ctor(String name, LocalVariables locals, InstructionArray instructions, DebugInfo[] debugInfos) { }

	// RVA: 0xFFFFFFFF75A2C9CC
	internal String get_Name() { }

	// RVA: 0xFFFFFFFF75A2C9D4
	internal Int32 get_LocalCount() { }

	// RVA: 0xFFFFFFFF75A1C400
	internal Int32 get_ClosureSize() { }

	// RVA: 0xFFFFFFFF75A2C9DC
	internal InstructionArray get_Instructions() { }

	// RVA: 0xFFFFFFFF75A2C9F0
	internal Dictionary<T0, T1> get_ClosureVariables() { }

	// RVA: 0xFFFFFFFF75A2C9F8
	public Void Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2CA7C
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LabelInfo
{
	// Fields
	private readonly LabelTarget _node; // 0x10
	private BranchLabel _label; // 0x18
	private Object _definitions; // 0x20
	private readonly List<T0> _references; // 0x28
	private Boolean _acrossBlockJump; // 0x30

	// Properties
	private Boolean HasDefinitions { get; }
	private Boolean HasMultipleDefinitions { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2CAE0
	internal Void .ctor(LabelTarget node) { }

	// RVA: 0xFFFFFFFF75A2CB78
	internal BranchLabel GetLabel(LightCompiler compiler) { }

	// RVA: 0xFFFFFFFF75A2CBEC
	internal Void Reference(LabelScopeInfo block) { }

	// RVA: 0xFFFFFFFF75A2CEF0
	internal Void Define(LabelScopeInfo block) { }

	// RVA: 0xFFFFFFFF75A2CC80
	private Void ValidateJump(LabelScopeInfo reference) { }

	// RVA: 0xFFFFFFFF75A2D634
	internal Void ValidateFinish() { }

	// RVA: 0xFFFFFFFF75A2CB9C
	private Void EnsureLabel(LightCompiler compiler) { }

	// RVA: 0xFFFFFFFF75A2D3DC
	private Boolean DefinedIn(LabelScopeInfo scope) { }

	// RVA: 0xFFFFFFFF75A2CC70
	private Boolean get_HasDefinitions() { }

	// RVA: 0xFFFFFFFF75A2D498
	private LabelScopeInfo FirstDefinition() { }

	// RVA: 0xFFFFFFFF75A2D17C
	private Void AddDefinition(LabelScopeInfo scope) { }

	// RVA: 0xFFFFFFFF75A2D360
	private Boolean get_HasMultipleDefinitions() { }

	// RVA: -1
	internal static T CommonNode(T first, T second, Func<T0, T1> parent) { }

}

// Namespace: 
private sealed class <>c
{
	// Fields
	public static readonly <>c <>9; // 0x0
	public static Func<T0, T1> <>9__9_0; // 0x8

	// Methods

	// RVA: 0xFFFFFFFF75A2D6C0
	private static Void .cctor() { }

	// RVA: 0xFFFFFFFF75A2D720
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A2D728
	internal LabelScopeInfo <ValidateJump>b__9_0(LabelScopeInfo b) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal enum LabelScopeKind
{
	// Fields
	public Int32 value__; // 0x10
	public const LabelScopeKind Statement = 0;
	public const LabelScopeKind Block = 1;
	public const LabelScopeKind Switch = 2;
	public const LabelScopeKind Lambda = 3;
	public const LabelScopeKind Try = 4;
	public const LabelScopeKind Catch = 5;
	public const LabelScopeKind Finally = 6;
	public const LabelScopeKind Filter = 7;
	public const LabelScopeKind Expression = 8;
}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LabelScopeInfo
{
	// Fields
	private HybridReferenceDictionary<T0, T1> _labels; // 0x10
	internal readonly LabelScopeKind Kind; // 0x18
	internal readonly LabelScopeInfo Parent; // 0x20

	// Properties
	internal Boolean CanJumpInto { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2D744
	internal Void .ctor(LabelScopeInfo parent, LabelScopeKind kind) { }

	// RVA: 0xFFFFFFFF75A2D624
	internal Boolean get_CanJumpInto() { }

	// RVA: 0xFFFFFFFF75A2D110
	internal Boolean ContainsTarget(LabelTarget target) { }

	// RVA: 0xFFFFFFFF75A2D78C
	internal Boolean TryGetLabelInfo(LabelTarget target, out LabelInfo info) { }

	// RVA: 0xFFFFFFFF75A2D2AC
	internal Void AddLabelInfo(LabelTarget target, LabelInfo info) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LeftShiftInstruction
{
	// Fields
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Int32; // 0x10
	private static Instruction s_Int64; // 0x18
	private static Instruction s_Byte; // 0x20
	private static Instruction s_UInt16; // 0x28
	private static Instruction s_UInt32; // 0x30
	private static Instruction s_UInt64; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2DBC4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2DBCC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A2DBD4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2DC14
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A28B94
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class LeftShiftSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A2DF78
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC1C
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2DD20
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC24
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A2DDE4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC2C
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2DEA0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC34
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A2DC5C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC3C
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E03C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC44
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E100
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC4C
	public Void .ctor() { }

}

// Namespace: 
private sealed class LeftShiftUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E1D8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2DC54
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LessThanInstruction
{
	// Fields
	private readonly Object _nullValue; // 0x10
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Char; // 0x10
	private static Instruction s_Int32; // 0x18
	private static Instruction s_Int64; // 0x20
	private static Instruction s_Byte; // 0x28
	private static Instruction s_UInt16; // 0x30
	private static Instruction s_UInt32; // 0x38
	private static Instruction s_UInt64; // 0x40
	private static Instruction s_Single; // 0x48
	private static Instruction s_Double; // 0x50
	private static Instruction s_liftedToNullSByte; // 0x58
	private static Instruction s_liftedToNullInt16; // 0x60
	private static Instruction s_liftedToNullChar; // 0x68
	private static Instruction s_liftedToNullInt32; // 0x70
	private static Instruction s_liftedToNullInt64; // 0x78
	private static Instruction s_liftedToNullByte; // 0x80
	private static Instruction s_liftedToNullUInt16; // 0x88
	private static Instruction s_liftedToNullUInt32; // 0x90
	private static Instruction s_liftedToNullUInt64; // 0x98
	private static Instruction s_liftedToNullSingle; // 0xA0
	private static Instruction s_liftedToNullDouble; // 0xA8

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2E2B0
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2E2B8
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A2E2C0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2E300
	private Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A28F64
	public static Instruction Create(Type type, Boolean liftedToNull) { }

}

// Namespace: 
private sealed class LessThanSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E334
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2EA10
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E368
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2E7C4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanChar
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E39C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2E634
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E3D0
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2E888
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E404
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2E94C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E438
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2E570
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E46C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2EBA0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E4A0
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2EC64
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E4D4
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2ED28
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E508
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2EAD4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A2E53C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2E6F8
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LessThanOrEqualInstruction
{
	// Fields
	private readonly Object _nullValue; // 0x10
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Char; // 0x10
	private static Instruction s_Int32; // 0x18
	private static Instruction s_Int64; // 0x20
	private static Instruction s_Byte; // 0x28
	private static Instruction s_UInt16; // 0x30
	private static Instruction s_UInt32; // 0x38
	private static Instruction s_UInt64; // 0x40
	private static Instruction s_Single; // 0x48
	private static Instruction s_Double; // 0x50
	private static Instruction s_liftedToNullSByte; // 0x58
	private static Instruction s_liftedToNullInt16; // 0x60
	private static Instruction s_liftedToNullChar; // 0x68
	private static Instruction s_liftedToNullInt32; // 0x70
	private static Instruction s_liftedToNullInt64; // 0x78
	private static Instruction s_liftedToNullByte; // 0x80
	private static Instruction s_liftedToNullUInt16; // 0x88
	private static Instruction s_liftedToNullUInt32; // 0x90
	private static Instruction s_liftedToNullUInt64; // 0x98
	private static Instruction s_liftedToNullSingle; // 0xA0
	private static Instruction s_liftedToNullDouble; // 0xA8

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2EDEC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A2EDF4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A2EDFC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A2EE3C
	private Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A29980
	public static Instruction Create(Type type, Boolean liftedToNull) { }

}

// Namespace: 
private sealed class LessThanOrEqualSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EE70
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F54C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EEA4
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F300
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualChar
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EED8
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F170
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EF0C
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F3C4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EF40
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F488
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EF74
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F0AC
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EFA8
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F6DC
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A2EFDC
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F7A0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A2F010
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F864
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A2F044
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F610
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A2F078
	public Void .ctor(Object nullValue) { }

	// RVA: 0xFFFFFFFF75A2F234
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ExceptionFilter
{
	// Fields
	public readonly Int32 LabelIndex; // 0x10
	public readonly Int32 StartIndex; // 0x14
	public readonly Int32 EndIndex; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A21468
	internal Void .ctor(Int32 labelIndex, Int32 start, Int32 end) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ExceptionHandler
{
	// Fields
	private readonly Type _exceptionType; // 0x10
	public readonly Int32 LabelIndex; // 0x18
	public readonly Int32 HandlerStartIndex; // 0x1C
	public readonly Int32 HandlerEndIndex; // 0x20
	public readonly ExceptionFilter Filter; // 0x28

	// Methods

	// RVA: 0xFFFFFFFF75A214A8
	internal Void .ctor(Int32 labelIndex, Int32 handlerStartIndex, Int32 handlerEndIndex, Type exceptionType, ExceptionFilter filter) { }

	// RVA: 0xFFFFFFFF75A21514
	public Boolean Matches(Type exceptionType) { }

	// RVA: 0xFFFFFFFF75A2153C
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TryCatchFinallyHandler
{
	// Fields
	internal readonly Int32 TryStartIndex; // 0x10
	internal readonly Int32 TryEndIndex; // 0x14
	internal readonly Int32 FinallyStartIndex; // 0x18
	internal readonly Int32 FinallyEndIndex; // 0x1C
	internal readonly Int32 GotoEndTargetIndex; // 0x20
	private readonly ExceptionHandler[] _handlers; // 0x28

	// Properties
	internal Boolean IsFinallyBlockExist { get; }
	internal Boolean IsCatchBlockExist { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4C7C0
	internal Boolean get_IsFinallyBlockExist() { }

	// RVA: 0xFFFFFFFF75A4C7D4
	internal Boolean get_IsCatchBlockExist() { }

	// RVA: 0xFFFFFFFF75A4C7E4
	internal Void .ctor(Int32 tryStart, Int32 tryEnd, Int32 gotoEndTargetIndex, ExceptionHandler[] handlers) { }

	// RVA: 0xFFFFFFFF75A4C844
	internal Void .ctor(Int32 tryStart, Int32 tryEnd, Int32 gotoEndLabelIndex, Int32 finallyStart, Int32 finallyEnd, ExceptionHandler[] handlers) { }

	// RVA: 0xFFFFFFFF75A4C8B0
	internal Boolean HasHandler(InterpretedFrame frame, Exception exception, out ExceptionHandler handler, out Object unwrappedException) { }

	// RVA: 0xFFFFFFFF75A4CA14
	private static Boolean FilterPasses(InterpretedFrame frame, ref Object exception, ExceptionFilter filter) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TryFaultHandler
{
	// Fields
	internal readonly Int32 TryStartIndex; // 0x10
	internal readonly Int32 TryEndIndex; // 0x14
	internal readonly Int32 FinallyStartIndex; // 0x18
	internal readonly Int32 FinallyEndIndex; // 0x1C

	// Methods

	// RVA: 0xFFFFFFFF75A4CC40
	internal Void .ctor(Int32 tryStart, Int32 tryEnd, Int32 finallyStart, Int32 finallyEnd) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class RethrowException
{
	// Methods

	// RVA: 0xFFFFFFFF75A48F7C
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class DebugInfo
{
	// Fields
	public Int32 StartLine; // 0x10
	public Int32 EndLine; // 0x14
	public Int32 Index; // 0x18
	public String FileName; // 0x20
	public Boolean IsClear; // 0x28
	private static readonly DebugInfoComparer s_debugComparer; // 0x0

	// Methods

	// RVA: 0xFFFFFFFF75A1C60C
	public static DebugInfo GetMatchingDebugInfo(DebugInfo[] debugInfos, Int32 index) { }

	// RVA: 0xFFFFFFFF75A1C704
	public override String ToString() { }

	// RVA: 0xFFFFFFFF75A1C6FC
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1C888
	private static Void .cctor() { }

}

// Namespace: 
private class DebugInfoComparer
{
	// Methods

	// RVA: 0xFFFFFFFF75A1C900
	private Int32 System.Collections.Generic.IComparer<System.Linq.Expressions.Interpreter.DebugInfo>.Compare(DebugInfo d1, DebugInfo d2) { }

	// RVA: 0xFFFFFFFF75A1C8F8
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct InterpretedFrameInfo
{
	// Fields
	private readonly String _methodName; // 0x10
	private readonly DebugInfo _debugInfo; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF71144C1C
	public Void .ctor(String methodName, DebugInfo info) { }

	// RVA: 0xFFFFFFFF71144C50
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LightCompiler
{
	// Fields
	private readonly InstructionList _instructions; // 0x10
	private readonly LocalVariables _locals; // 0x18
	private readonly List<T0> _debugInfos; // 0x20
	private readonly HybridReferenceDictionary<T0, T1> _treeLabels; // 0x28
	private LabelScopeInfo _labelBlock; // 0x30
	private readonly Stack<T0> _exceptionForRethrowStack; // 0x38
	private readonly LightCompiler _parent; // 0x40
	private readonly StackGuard _guard; // 0x48
	private static readonly LocalDefinition[] s_emptyLocals; // 0x0

	// Properties
	public InstructionList Instructions { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2F928
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A2FB10
	private Void .ctor(LightCompiler parent) { }

	// RVA: 0xFFFFFFFF75A2FB40
	public InstructionList get_Instructions() { }

	// RVA: 0xFFFFFFFF75A2FB48
	public LightDelegateCreator CompileTop(LambdaExpression node) { }

	// RVA: 0xFFFFFFFF75A2FD60
	private Interpreter MakeInterpreter(String lambdaName) { }

	// RVA: 0xFFFFFFFF75A30080
	private Void CompileConstantExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A30130
	private Void CompileDefaultExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A30174
	private Void CompileDefaultExpression(Type type) { }

	// RVA: 0xFFFFFFFF75A30248
	private LocalVariable EnsureAvailableForClosure(ParameterExpression expr) { }

	// RVA: 0xFFFFFFFF75A30370
	private LocalVariable ResolveLocal(ParameterExpression variable) { }

	// RVA: 0xFFFFFFFF75A303CC
	private Void CompileGetVariable(ParameterExpression variable) { }

	// RVA: 0xFFFFFFFF75A30498
	private Void EmitCopyValueType(Type valueType) { }

	// RVA: 0xFFFFFFFF75A30414
	private Void LoadLocalNoValueTypeCopy(ParameterExpression variable) { }

	// RVA: 0xFFFFFFFF75A30534
	private Boolean MaybeMutableValueType(Type type) { }

	// RVA: 0xFFFFFFFF75A30598
	private Void CompileGetBoxedVariable(ParameterExpression variable) { }

	// RVA: 0xFFFFFFFF75A305F4
	private Void CompileSetVariable(ParameterExpression variable, Boolean isVoid) { }

	// RVA: 0xFFFFFFFF75A306F0
	private Void CompileParameterExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A3077C
	private Void CompileBlockExpression(Expression expr, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A308C0
	private LocalDefinition[] CompileBlockStart(BlockExpression node) { }

	// RVA: 0xFFFFFFFF75A30CE0
	private Void CompileBlockEnd(LocalDefinition[] locals) { }

	// RVA: 0xFFFFFFFF75A30F0C
	private Void CompileIndexExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A30FE0
	private Void EmitIndexGet(IndexExpression index) { }

	// RVA: 0xFFFFFFFF75A310E0
	private Void CompileIndexAssignment(BinaryExpression node, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A313B8
	private Void CompileMemberAssignment(BinaryExpression node, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A31480
	private Void CompileMemberAssignment(Boolean asVoid, MemberInfo refMember, Expression value, Boolean forBinding) { }

	// RVA: 0xFFFFFFFF75A3182C
	private Void CompileVariableAssignment(BinaryExpression node, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A318D8
	private Void CompileAssignBinaryExpression(Expression expr, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A31A1C
	private Void CompileBinaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A32820
	private Void CompileEqual(Expression left, Expression right, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A32894
	private Void CompileNotEqual(Expression left, Expression right, Boolean liftedToNull) { }

	// RVA: 0xFFFFFFFF75A3290C
	private Void CompileComparison(BinaryExpression node) { }

	// RVA: 0xFFFFFFFF75A325F0
	private Void CompileArithmetic(ExpressionType nodeType, Expression left, Expression right) { }

	// RVA: 0xFFFFFFFF75A32AC8
	private Void CompileConvertUnaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A32FD4
	private Void CompileConvertToType(Type typeFrom, Type typeTo, Boolean isChecked, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A33480
	private Void CompileNotExpression(UnaryExpression node) { }

	// RVA: 0xFFFFFFFF75A334E0
	private Void CompileUnaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A33800
	private Void EmitUnaryMethodCall(UnaryExpression node) { }

	// RVA: 0xFFFFFFFF75A33914
	private Void EmitUnaryBoolCheck(UnaryExpression node) { }

	// RVA: 0xFFFFFFFF75A33A9C
	private Void CompileAndAlsoBinaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A33C98
	private Void CompileOrElseBinaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A33B2C
	private Void CompileLogicalBinaryExpression(BinaryExpression b, Boolean andAlso) { }

	// RVA: 0xFFFFFFFF75A33D28
	private Void CompileMethodLogicalBinaryExpression(BinaryExpression expr, Boolean andAlso) { }

	// RVA: 0xFFFFFFFF75A33E44
	private Void CompileLiftedLogicalBinaryExpression(BinaryExpression node, Boolean andAlso) { }

	// RVA: 0xFFFFFFFF75A34460
	private Void CompileUnliftedLogicalBinaryExpression(BinaryExpression expr, Boolean andAlso) { }

	// RVA: 0xFFFFFFFF75A34524
	private Void CompileConditionalExpression(Expression expr, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A346E0
	private Void CompileLoopExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A349AC
	private Void CompileSwitchExpression(Expression expr) { }

	// RVA: -1
	private Void CompileIntSwitchExpression(SwitchExpression node) { }

	// RVA: 0xFFFFFFFF75A353BC
	private Void CompileStringSwitchExpression(SwitchExpression node) { }

	// RVA: 0xFFFFFFFF75A35964
	private Void CompileLabelExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A35AEC
	private Void CompileGotoExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A34878
	private Void PushLabelBlock(LabelScopeKind type) { }

	// RVA: 0xFFFFFFFF75A34988
	private Void PopLabelBlock(LabelScopeKind kind) { }

	// RVA: 0xFFFFFFFF75A35CAC
	private LabelInfo EnsureLabel(LabelTarget node) { }

	// RVA: 0xFFFFFFFF75A35C74
	private LabelInfo ReferenceLabel(LabelTarget node) { }

	// RVA: 0xFFFFFFFF75A348FC
	private LabelInfo DefineLabel(LabelTarget node) { }

	// RVA: 0xFFFFFFFF75A35D7C
	private Boolean TryPushLabelBlock(Expression node) { }

	// RVA: 0xFFFFFFFF75A361B0
	private Void DefineBlockLabels(Expression node) { }

	// RVA: 0xFFFFFFFF75A362DC
	private Void CheckRethrow() { }

	// RVA: 0xFFFFFFFF75A36350
	private Void CompileThrowUnaryExpression(Expression expr, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A36454
	private Void CompileTryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A36F34
	private Void CompileTryFaultExpression(TryExpression expr) { }

	// RVA: 0xFFFFFFFF75A3719C
	private Void CompileMethodCallExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A37240
	private Void CompileMethodCallExpression(Expression object, MethodInfo method, IArgumentProvider arguments) { }

	// RVA: 0xFFFFFFFF75A38034
	private ByRefUpdater CompileArrayIndexAddress(Expression array, Expression index, Int32 argumentIndex) { }

	// RVA: 0xFFFFFFFF75A30FD8
	private Void EmitThisForMethodCall(Expression node) { }

	// RVA: 0xFFFFFFFF75A3825C
	private static Boolean ShouldWritebackNode(Expression node) { }

	// RVA: 0xFFFFFFFF75A376C8
	private ByRefUpdater CompileAddress(Expression node, Int32 index) { }

	// RVA: 0xFFFFFFFF75A383D8
	private ByRefUpdater CompileMultiDimArrayAccess(Expression array, IArgumentProvider arguments, Int32 index) { }

	// RVA: 0xFFFFFFFF75A387E0
	private Void CompileNewExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A38B24
	private Void CompileMemberExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A38BCC
	private Void CompileMember(Expression from, MemberInfo member, Boolean forBinding) { }

	// RVA: 0xFFFFFFFF75A38F44
	private Void CompileNewArrayExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A39298
	private Void CompileDebugInfoExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A39404
	private Void CompileRuntimeVariablesExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A396E8
	private Void CompileLambdaExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A39934
	private Void CompileCoalesceBinaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A39CF8
	private Void CompileInvocationExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A39F5C
	private Void CompileListInitExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A39FE0
	private Void CompileListInit(ReadOnlyCollection<T0> initializers) { }

	// RVA: 0xFFFFFFFF75A3A328
	private Void CompileMemberInitExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A3A3AC
	private Void CompileMemberInit(ReadOnlyCollection<T0> bindings) { }

	// RVA: 0xFFFFFFFF75A3A800
	private static Type GetMemberType(MemberInfo member) { }

	// RVA: 0xFFFFFFFF75A3A968
	private Void CompileQuoteUnaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A3ABEC
	private Void CompileUnboxUnaryExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A3ACF8
	private Void CompileTypeEqualExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A338C0
	private Void CompileTypeAsExpression(UnaryExpression node) { }

	// RVA: 0xFFFFFFFF75A3AE7C
	private Void CompileTypeIsExpression(Expression expr) { }

	// RVA: 0xFFFFFFFF75A30CD4
	private Void Compile(Expression expr, Boolean asVoid) { }

	// RVA: 0xFFFFFFFF75A30DA8
	private Void CompileAsVoid(Expression expr) { }

	// RVA: 0xFFFFFFFF75A3B070
	private Void CompileNoLabelPush(Expression expr) { }

	// RVA: 0xFFFFFFFF75A2FCF8
	private Void Compile(Expression expr) { }

	// RVA: 0xFFFFFFFF75A3B71C
	private static Void .cctor() { }

}

// Namespace: 
private sealed class QuoteVisitor
{
	// Fields
	private readonly Dictionary<T0, T1> _definedParameters; // 0x10
	public readonly HashSet<T0> _hoistedParameters; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A3B9F8
	protected internal override Expression VisitParameter(ParameterExpression node) { }

	// RVA: 0xFFFFFFFF75A3BA88
	protected internal override Expression VisitBlock(BlockExpression node) { }

	// RVA: 0xFFFFFFFF75A3C094
	protected override CatchBlock VisitCatchBlock(CatchBlock node) { }

	// RVA: -1
	protected internal override Expression VisitLambda(Expression<T0> node) { }

	// RVA: 0xFFFFFFFF75A3BAF4
	private Void PushParameters(IEnumerable<T0> parameters) { }

	// RVA: 0xFFFFFFFF75A3BDC8
	private Void PopParameters(IEnumerable<T0> parameters) { }

	// RVA: 0xFFFFFFFF75A3C188
	public Void .ctor() { }

}

// Namespace: 
private sealed class <>c
{
	// Fields
	public static readonly <>c <>9; // 0x0
	public static Func<T0, T1> <>9__56_1; // 0x8
	public static Func<T0, T1> <>9__56_0; // 0x10
	public static Action<T0, T1> <>9__101_0; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A3B7FC
	private static Void .cctor() { }

	// RVA: 0xFFFFFFFF75A3B85C
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A3B864
	internal Boolean <CompileSwitchExpression>b__56_0(SwitchCase c) { }

	// RVA: 0xFFFFFFFF75A3B960
	internal Boolean <CompileSwitchExpression>b__56_1(Expression t) { }

	// RVA: 0xFFFFFFFF75A3B9D8
	internal Void <CompileNoLabelPush>b__101_0(LightCompiler this, Expression e) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class ByRefUpdater
{
	// Fields
	public readonly Int32 ArgumentIndex; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A19254
	public Void .ctor(Int32 argumentIndex) { }

	// RVA: -1
	public abstract Void Update(InterpretedFrame frame, Object value) { }

	// RVA: 0xFFFFFFFF75A1AD60
	public virtual Void UndefineTemps(InstructionList instructions, LocalVariables locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ParameterByRefUpdater
{
	// Fields
	private readonly LocalVariable _parameter; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A48354
	public Void .ctor(LocalVariable parameter, Int32 argumentIndex) { }

	// RVA: 0xFFFFFFFF75A4838C
	public override Void Update(InterpretedFrame frame, Object value) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ArrayByRefUpdater
{
	// Fields
	private readonly LocalDefinition _array; // 0x18
	private readonly LocalDefinition _index; // 0x28

	// Methods

	// RVA: 0xFFFFFFFF75A191E4
	public Void .ctor(LocalDefinition array, LocalDefinition index, Int32 argumentIndex) { }

	// RVA: 0xFFFFFFFF75A19280
	public override Void Update(InterpretedFrame frame, Object value) { }

	// RVA: 0xFFFFFFFF75A1935C
	public override Void UndefineTemps(InstructionList instructions, LocalVariables locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class FieldByRefUpdater
{
	// Fields
	private readonly Nullable<T0> _object; // 0x18
	private readonly FieldInfo _field; // 0x30

	// Methods

	// RVA: 0xFFFFFFFF75A22154
	public Void .ctor(Nullable<T0> obj, FieldInfo field, Int32 argumentIndex) { }

	// RVA: 0xFFFFFFFF75A221B8
	public override Void Update(InterpretedFrame frame, Object value) { }

	// RVA: 0xFFFFFFFF75A22268
	public override Void UndefineTemps(InstructionList instructions, LocalVariables locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class PropertyByRefUpdater
{
	// Fields
	private readonly Nullable<T0> _object; // 0x18
	private readonly PropertyInfo _property; // 0x30

	// Methods

	// RVA: 0xFFFFFFFF75A48640
	public Void .ctor(Nullable<T0> obj, PropertyInfo property, Int32 argumentIndex) { }

	// RVA: 0xFFFFFFFF75A486A0
	public override Void Update(InterpretedFrame frame, Object value) { }

	// RVA: 0xFFFFFFFF75A487F4
	public override Void UndefineTemps(InstructionList instructions, LocalVariables locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class IndexMethodByRefUpdater
{
	// Fields
	private readonly MethodInfo _indexer; // 0x18
	private readonly Nullable<T0> _obj; // 0x20
	private readonly LocalDefinition[] _args; // 0x38

	// Methods

	// RVA: 0xFFFFFFFF75A25AB8
	public Void .ctor(Nullable<T0> obj, LocalDefinition[] args, MethodInfo indexer, Int32 argumentIndex) { }

	// RVA: 0xFFFFFFFF75A25B38
	public override Void Update(InterpretedFrame frame, Object value) { }

	// RVA: 0xFFFFFFFF75A25D5C
	public override Void UndefineTemps(InstructionList instructions, LocalVariables locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LightDelegateCreator
{
	// Fields
	private readonly LambdaExpression _lambda; // 0x10
	private readonly Interpreter <Interpreter>k__BackingField; // 0x18

	// Properties
	internal Interpreter Interpreter { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3C248
	internal Void .ctor(Interpreter interpreter, LambdaExpression lambda) { }

	// RVA: 0xFFFFFFFF75A3C298
	internal Interpreter get_Interpreter() { }

	// RVA: 0xFFFFFFFF75A3C2A0
	public Delegate CreateDelegate() { }

	// RVA: 0xFFFFFFFF75A3C2A8
	internal Delegate CreateDelegate(IStrongBox[] closure) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class LightLambda
{
	// Fields
	private readonly IStrongBox[] _closure; // 0x10
	private readonly Interpreter _interpreter; // 0x18
	private static readonly CacheDict<T0, T1> _runCache; // 0x0
	private readonly LightDelegateCreator _delegateCreator; // 0x20

	// Methods

	// RVA: 0xFFFFFFFF75A3C42C
	internal Void RunVoid0() { }

	// RVA: 0xFFFFFFFF75A3C330
	internal Void .ctor(LightDelegateCreator delegateCreator, IStrongBox[] closure) { }

	// RVA: 0xFFFFFFFF75A3C548
	private static Func<T0, T1> GetRunDelegateCtor(Type delegateType) { }

	// RVA: 0xFFFFFFFF75A3C680
	private static Func<T0, T1> MakeRunDelegateCtor(Type delegateType) { }

	// RVA: 0xFFFFFFFF75A3CD90
	private Delegate CreateCustomDelegate(Type delegateType) { }

	// RVA: 0xFFFFFFFF75A3C398
	internal Delegate MakeDelegate(Type delegateType) { }

	// RVA: 0xFFFFFFFF75A3C4DC
	private InterpretedFrame MakeFrame() { }

	// RVA: -1
	internal Void RunVoidRef2(ref T0 arg0, ref T1 arg1) { }

	// RVA: 0xFFFFFFFF75A3D464
	public Object Run(Object[] arguments) { }

	// RVA: 0xFFFFFFFF75A3D5BC
	public Object RunVoid(Object[] arguments) { }

	// RVA: 0xFFFFFFFF75A3D710
	private static Void .cctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass74_0
{
	// Fields
	public MethodInfo targetMethod; // 0x10
	public Type delegateType; // 0x18

	// Methods

	// RVA: 0xFFFFFFFF75A3CD88
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A3D794
	internal Delegate <MakeRunDelegateCtor>b__0(LightLambda lambda) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal interface IBoxableInstruction
{
	// Methods

	// RVA: -1
	public abstract Instruction BoxIfIndexMatches(Int32 index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LocalAccessInstruction
{
	// Fields
	internal readonly Int32 _index; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A3DA2C
	protected Void .ctor(Int32 index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalInstruction
{
	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3DE90
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A3DEBC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3DEC4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3DF04
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3DF6C
	public Instruction BoxIfIndexMatches(Int32 index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalBoxedInstruction
{
	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3DA00
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A3DA58
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3DA60
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3DAA0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalFromClosureInstruction
{
	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3DD08
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A3DD34
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3DD3C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3DD7C
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalFromClosureBoxedInstruction
{
	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3DBEC
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A3DC18
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3DC20
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3DC60
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class AssignLocalInstruction
{
	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A19774
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A1977C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A19784
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1978C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A197CC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1982C
	public Instruction BoxIfIndexMatches(Int32 index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreLocalInstruction
{
	// Properties
	public override Int32 ConsumedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A484
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4A4B0
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A4B8
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A4F8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4A55C
	public Instruction BoxIfIndexMatches(Int32 index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class AssignLocalBoxedInstruction
{
	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1959C
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A195A4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A195AC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A195B4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A195F4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreLocalBoxedInstruction
{
	// Properties
	public override Int32 ConsumedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A2C4
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A4A2F0
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A2F8
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A338
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class AssignLocalToClosureInstruction
{
	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A19A0C
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A19A14
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A19A1C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A19A24
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A19A64
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ValueTypeCopyInstruction
{
	// Fields
	public static readonly ValueTypeCopyInstruction Instruction; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4D058
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4D060
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4D068
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4D0A8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4D0F8
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A4D100
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class InitializeLocalInstruction
{
	// Methods

	// RVA: 0xFFFFFFFF75A25F58
	internal Void .ctor(Int32 index) { }

}

// Namespace: 
internal sealed class Reference
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A26928
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26930
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A26980
	public Instruction BoxIfIndexMatches(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26A64
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class ImmutableValue
{
	// Fields
	private readonly Object _defaultValue; // 0x18

	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A26184
	internal Void .ctor(Int32 index, Object defaultValue) { }

	// RVA: 0xFFFFFFFF75A261B8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A26208
	public Instruction BoxIfIndexMatches(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26298
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class ImmutableBox
{
	// Fields
	private readonly Object _defaultValue; // 0x18

	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A25F60
	internal Void .ctor(Int32 index, Object defaultValue) { }

	// RVA: 0xFFFFFFFF75A25F94
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A2604C
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class ImmutableRefBox
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2608C
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26094
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A26144
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class ParameterBox
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A2680C
	public Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26814
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A268E8
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class Parameter
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A266D8
	internal Void .ctor(Int32 index) { }

	// RVA: 0xFFFFFFFF75A266E0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A266E8
	public Instruction BoxIfIndexMatches(Int32 index) { }

	// RVA: 0xFFFFFFFF75A267CC
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class MutableValue
{
	// Fields
	private readonly Type _type; // 0x18

	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A264A4
	internal Void .ctor(Int32 index, Type type) { }

	// RVA: 0xFFFFFFFF75A264D8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A26608
	public Instruction BoxIfIndexMatches(Int32 index) { }

	// RVA: 0xFFFFFFFF75A26698
	public override String get_InstructionName() { }

}

// Namespace: 
internal sealed class MutableBox
{
	// Fields
	private readonly Type _type; // 0x18

	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A262D8
	internal Void .ctor(Int32 index, Type type) { }

	// RVA: 0xFFFFFFFF75A2630C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A26464
	public override String get_InstructionName() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class RuntimeVariablesInstruction
{
	// Fields
	private readonly Int32 _count; // 0x10

	// Properties
	public override Int32 ProducedStack { get; }
	public override Int32 ConsumedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A49BA4
	public Void .ctor(Int32 count) { }

	// RVA: 0xFFFFFFFF75A49BD0
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A49BD8
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A49BE0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A49C20
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LocalVariable
{
	// Fields
	public readonly Int32 Index; // 0x10
	private Int32 _flags; // 0x14

	// Properties
	public Boolean IsBoxed { get; set; }
	public Boolean InClosure { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3E2DC
	public Boolean get_IsBoxed() { }

	// RVA: 0xFFFFFFFF75A3E2E8
	public Void set_IsBoxed(Boolean value) { }

	// RVA: 0xFFFFFFFF75A3E2FC
	public Boolean get_InClosure() { }

	// RVA: 0xFFFFFFFF75A3E308
	internal Void .ctor(Int32 index, Boolean closure) { }

	// RVA: 0xFFFFFFFF75A3E34C
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct LocalDefinition
{
	// Fields
	private readonly Int32 <Index>k__BackingField; // 0x10
	private readonly ParameterExpression <Parameter>k__BackingField; // 0x18

	// Properties
	public Int32 Index { get; }
	public ParameterExpression Parameter { get; }

	// Methods

	// RVA: 0xFFFFFFFF71144CA4
	internal Void .ctor(Int32 localIndex, ParameterExpression parameter) { }

	// RVA: 0xFFFFFFFF71144CB4
	public Int32 get_Index() { }

	// RVA: 0xFFFFFFFF71144CBC
	public ParameterExpression get_Parameter() { }

	// RVA: 0xFFFFFFFF71144CC4
	public override Boolean Equals(Object obj) { }

	// RVA: 0xFFFFFFFF71144CCC
	public override Int32 GetHashCode() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LocalVariables
{
	// Fields
	private readonly HybridReferenceDictionary<T0, T1> _variables; // 0x10
	private Dictionary<T0, T1> _closureVariables; // 0x18
	private Int32 _localCount; // 0x20
	private Int32 _maxLocalCount; // 0x24

	// Properties
	public Int32 LocalCount { get; }
	internal Dictionary<T0, T1> ClosureVariables { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3E424
	public LocalDefinition DefineLocal(ParameterExpression variable, Int32 start) { }

	// RVA: 0xFFFFFFFF75A3E6D0
	public Void UndefineLocal(LocalDefinition definition, Int32 end) { }

	// RVA: 0xFFFFFFFF75A3E794
	internal Void Box(ParameterExpression variable, InstructionList instructions) { }

	// RVA: 0xFFFFFFFF75A3E8FC
	public Int32 get_LocalCount() { }

	// RVA: 0xFFFFFFFF75A3E904
	public Boolean TryGetLocalOrClosure(ParameterExpression var, out LocalVariable local) { }

	// RVA: 0xFFFFFFFF75A3E9DC
	internal Dictionary<T0, T1> get_ClosureVariables() { }

	// RVA: 0xFFFFFFFF75A3E9E4
	internal LocalVariable AddClosureVariable(ParameterExpression variable) { }

	// RVA: 0xFFFFFFFF75A3EAE8
	public Void .ctor() { }

}

// Namespace: 
private sealed class VariableScope
{
	// Fields
	public readonly Int32 Start; // 0x10
	public Int32 Stop; // 0x14
	public readonly LocalVariable Variable; // 0x18
	public readonly VariableScope Parent; // 0x20
	public List<T0> ChildScopes; // 0x28

	// Methods

	// RVA: 0xFFFFFFFF75A3E670
	public Void .ctor(LocalVariable variable, Int32 start, VariableScope parent) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class ModuloInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3F0A4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A3F0AC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3F0B4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3F0F4
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A3F0FC
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class ModuloInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A3F580
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F408
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A3F6B0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F410
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A3F924
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F418
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A3FB8C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F420
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A3FCBC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F428
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A3FDEC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F430
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A3FA54
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F438
	public Void .ctor() { }

}

// Namespace: 
private sealed class ModuloDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A3F448
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3F440
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class MulInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3FF1C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A3FF24
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3FF2C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3FF6C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A3FF74
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class MulInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A403F4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40280
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A40520
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40288
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A40638
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40290
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A40898
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40298
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A409C4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A402A0
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A40AF0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A402A8
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A40764
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A402B0
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A402C0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A402B8
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class MulOvfInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A40C1C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A40C24
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A40C2C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A40C6C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A40C74
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class MulOvfInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A40F10
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40EE0
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulOvfInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A41150
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40EE8
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulOvfInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A41358
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40EF0
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulOvfUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A41530
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40EF8
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulOvfUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A41784
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40F00
	public Void .ctor() { }

}

// Namespace: 
private sealed class MulOvfUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A41944
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A40F08
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NegateInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_Single; // 0x18
	private static Instruction s_Double; // 0x20

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4228C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A42294
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4229C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A422DC
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A41CF8
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class NegateInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A423A4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A422E4
	public Void .ctor() { }

}

// Namespace: 
private sealed class NegateInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A4242C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A422EC
	public Void .ctor() { }

}

// Namespace: 
private sealed class NegateInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A424B0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A422F4
	public Void .ctor() { }

}

// Namespace: 
private sealed class NegateSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A42548
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A422FC
	public Void .ctor() { }

}

// Namespace: 
private sealed class NegateDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A4230C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A42304
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NegateCheckedInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A41B00
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A41B08
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A41B10
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A41B50
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A41B58
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class NegateCheckedInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A42064
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A41CE8
	public Void .ctor() { }

}

// Namespace: 
private sealed class NegateCheckedInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A41F2C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A41CE0
	public Void .ctor() { }

}

// Namespace: 
private sealed class NegateCheckedInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A4217C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A41CF0
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class NewInstruction
{
	// Fields
	protected readonly ConstructorInfo _constructor; // 0x10
	protected readonly Int32 _argumentCount; // 0x18

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A429B0
	public Void .ctor(ConstructorInfo constructor, Int32 argumentCount) { }

	// RVA: 0xFFFFFFFF75A429F8
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A42A00
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A42A08
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A42A14
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A42B68
	protected Object[] GetArgs(InterpretedFrame frame, Int32 first) { }

	// RVA: 0xFFFFFFFF75A42CC8
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class ByRefNewInstruction
{
	// Fields
	private readonly ByRefUpdater[] _byrefArgs; // 0x20

	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1AAC8
	internal Void .ctor(ConstructorInfo target, Int32 argumentCount, ByRefUpdater[] byrefArgs) { }

	// RVA: 0xFFFFFFFF75A1AAFC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1AB3C
	public sealed override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NotEqualInstruction
{
	// Fields
	private static Instruction s_reference; // 0x0
	private static Instruction s_Boolean; // 0x8
	private static Instruction s_SByte; // 0x10
	private static Instruction s_Int16; // 0x18
	private static Instruction s_Char; // 0x20
	private static Instruction s_Int32; // 0x28
	private static Instruction s_Int64; // 0x30
	private static Instruction s_Byte; // 0x38
	private static Instruction s_UInt16; // 0x40
	private static Instruction s_UInt32; // 0x48
	private static Instruction s_UInt64; // 0x50
	private static Instruction s_Single; // 0x58
	private static Instruction s_Double; // 0x60
	private static Instruction s_SByteLiftedToNull; // 0x68
	private static Instruction s_Int16LiftedToNull; // 0x70
	private static Instruction s_CharLiftedToNull; // 0x78
	private static Instruction s_Int32LiftedToNull; // 0x80
	private static Instruction s_Int64LiftedToNull; // 0x88
	private static Instruction s_ByteLiftedToNull; // 0x90
	private static Instruction s_UInt16LiftedToNull; // 0x98
	private static Instruction s_UInt32LiftedToNull; // 0xA0
	private static Instruction s_UInt64LiftedToNull; // 0xA8
	private static Instruction s_SingleLiftedToNull; // 0xB0
	private static Instruction s_DoubleLiftedToNull; // 0xB8

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A42DA8
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A42DB0
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A42DB8
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A42DF8
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A42E00
	public static Instruction Create(Type type, Boolean liftedToNull) { }

}

// Namespace: 
private sealed class NotEqualBoolean
{
	// Methods

	// RVA: 0xFFFFFFFF75A43694
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4362C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A44170
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43634
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A43C44
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4363C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualChar
{
	// Methods

	// RVA: 0xFFFFFFFF75A438FC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43644
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A43DE0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4364C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A43F7C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43654
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A43760
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4365C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A444B8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43664
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A44654
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4366C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A447F0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43674
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A4430C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4367C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A43A98
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43684
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualReference
{
	// Methods

	// RVA: 0xFFFFFFFF75A44118
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4368C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualSByteLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A4423C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A435D4
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt16LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A43D10
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A435DC
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualCharLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A439C8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A435E4
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt32LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A43EAC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A435EC
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt64LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A44048
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A435F4
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualByteLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A4382C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A435FC
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt16LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A44584
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43604
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt32LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A44720
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4360C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt64LiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A448BC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43614
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualSingleLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A443E0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4361C
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotEqualDoubleLiftedToNull
{
	// Methods

	// RVA: 0xFFFFFFFF75A43B6C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A43624
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NotInstruction
{
	// Fields
	public static Instruction s_Boolean; // 0x0
	public static Instruction s_Int64; // 0x8
	public static Instruction s_Int32; // 0x10
	public static Instruction s_Int16; // 0x18
	public static Instruction s_UInt64; // 0x20
	public static Instruction s_UInt32; // 0x28
	public static Instruction s_UInt16; // 0x30
	public static Instruction s_Byte; // 0x38
	public static Instruction s_SByte; // 0x40

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4498C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A44994
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4499C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A449A4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A449E4
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class NotBoolean
{
	// Methods

	// RVA: 0xFFFFFFFF75A44D80
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D38
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A44F98
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D40
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A44F14
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D48
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A44E8C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D50
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A451D4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D58
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A4513C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D60
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A450B8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D68
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A44E08
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D70
	public Void .ctor() { }

}

// Namespace: 
private sealed class NotSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A45030
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A44D78
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NullCheckInstruction
{
	// Fields
	public static readonly Instruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4526C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A45274
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4527C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A45284
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A452C4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45344
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NumericConvertInstruction
{
	// Fields
	internal readonly TypeCode _from; // 0x10
	internal readonly TypeCode _to; // 0x14
	private readonly Boolean _isLiftedToNull; // 0x18

	// Properties
	public override String InstructionName { get; }
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A45B00
	protected Void .ctor(TypeCode from, TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A45B40
	public sealed override Int32 Run(InterpretedFrame frame) { }

	// RVA: -1
	protected abstract Object Convert(Object obj) { }

	// RVA: 0xFFFFFFFF75A45C20
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A45C60
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A45C68
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A45C70
	public override String ToString() { }

}

// Namespace: 
internal sealed class Unchecked
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A46BF0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A46C30
	public Void .ctor(TypeCode from, TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A46C70
	protected override Object Convert(Object obj) { }

	// RVA: 0xFFFFFFFF75A46F34
	private Object ConvertInt32(Int32 obj) { }

	// RVA: 0xFFFFFFFF75A470D0
	private Object ConvertInt64(Int64 obj) { }

	// RVA: 0xFFFFFFFF75A4724C
	private Object ConvertUInt64(UInt64 obj) { }

	// RVA: 0xFFFFFFFF75A473CC
	private Object ConvertDouble(Double obj) { }

}

// Namespace: 
internal sealed class Checked
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A45D88
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A45DC8
	public Void .ctor(TypeCode from, TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A45E08
	protected override Object Convert(Object obj) { }

	// RVA: 0xFFFFFFFF75A460CC
	private Object ConvertInt32(Int32 obj) { }

	// RVA: 0xFFFFFFFF75A46298
	private Object ConvertInt64(Int64 obj) { }

	// RVA: 0xFFFFFFFF75A4645C
	private Object ConvertUInt64(UInt64 obj) { }

	// RVA: 0xFFFFFFFF75A46620
	private Object ConvertDouble(Double obj) { }

}

// Namespace: 
internal sealed class ToUnderlying
{
	// Properties
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A468A8
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A468E8
	public Void .ctor(TypeCode to, Boolean isLiftedToNull) { }

	// RVA: 0xFFFFFFFF75A46924
	protected override Object Convert(Object obj) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class OrInstruction
{
	// Fields
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Int32; // 0x10
	private static Instruction s_Int64; // 0x18
	private static Instruction s_Byte; // 0x20
	private static Instruction s_UInt16; // 0x28
	private static Instruction s_UInt32; // 0x30
	private static Instruction s_UInt64; // 0x38
	private static Instruction s_Boolean; // 0x40

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A47724
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4772C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A47734
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A47774
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A4777C
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class OrSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A47FD8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47AD0
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A47D44
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47AD8
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A47E1C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47AE0
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A47EF0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47AE8
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A47C70
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47AF0
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A480B0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47AF8
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A48184
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47B00
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A4826C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47B08
	public Void .ctor() { }

}

// Namespace: 
private sealed class OrBoolean
{
	// Methods

	// RVA: 0xFFFFFFFF75A47B18
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A47B10
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class RightShiftInstruction
{
	// Fields
	private static Instruction s_SByte; // 0x0
	private static Instruction s_Int16; // 0x8
	private static Instruction s_Int32; // 0x10
	private static Instruction s_Int64; // 0x18
	private static Instruction s_Byte; // 0x20
	private static Instruction s_UInt16; // 0x28
	private static Instruction s_UInt32; // 0x30
	private static Instruction s_UInt64; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A48FBC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A48FC4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A48FCC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4900C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A49014
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class RightShiftSByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A496B0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49320
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A49430
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49328
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A49500
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49330
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A495CC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49338
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftByte
{
	// Methods

	// RVA: 0xFFFFFFFF75A49360
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49340
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A49780
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49348
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A49850
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49350
	public Void .ctor() { }

}

// Namespace: 
private sealed class RightShiftUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A49934
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A49358
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class RuntimeVariables
{
	// Fields
	private readonly IStrongBox[] _boxes; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A49B08
	private Void .ctor(IStrongBox[] boxes) { }

	// RVA: 0xFFFFFFFF75A49B3C
	internal static IRuntimeVariables Create(IStrongBox[] boxes) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadObjectInstruction
{
	// Fields
	private readonly Object _value; // 0x10

	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3DFF8
	internal Void .ctor(Object value) { }

	// RVA: 0xFFFFFFFF75A3E02C
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3E034
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3E074
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3E0CC
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadCachedObjectInstruction
{
	// Fields
	private readonly UInt32 _index; // 0x10

	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A3D7C8
	internal Void .ctor(UInt32 index) { }

	// RVA: 0xFFFFFFFF75A3D7F4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A3D7FC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A3D83C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A3D8B8
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class PopInstruction
{
	// Fields
	internal static readonly PopInstruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A48568
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A48570
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A48578
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A485B8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A485E0
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class DupInstruction
{
	// Fields
	internal static readonly DupInstruction Instance; // 0x0

	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1E530
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1E538
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1E540
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1E580
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A1E610
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class SubInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28
	private static Instruction s_Single; // 0x30
	private static Instruction s_Double; // 0x38

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4A7B4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4A7BC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4A7C4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4A804
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A4A80C
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class SubInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A4AC8C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB18
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A4ADB8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB20
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A4AED0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB28
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A4B130
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB30
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A4B25C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB38
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A4B388
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB40
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubSingle
{
	// Methods

	// RVA: 0xFFFFFFFF75A4AFFC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB48
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubDouble
{
	// Methods

	// RVA: 0xFFFFFFFF75A4AB58
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4AB50
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class SubOvfInstruction
{
	// Fields
	private static Instruction s_Int16; // 0x0
	private static Instruction s_Int32; // 0x8
	private static Instruction s_Int64; // 0x10
	private static Instruction s_UInt16; // 0x18
	private static Instruction s_UInt32; // 0x20
	private static Instruction s_UInt64; // 0x28

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4B4B4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4B4BC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4B4C4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4B504
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A4B50C
	public static Instruction Create(Type type) { }

}

// Namespace: 
private sealed class SubOvfInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A4B7A8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4B778
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubOvfInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A4B9E8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4B780
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubOvfInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A4BBF0
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4B788
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubOvfUInt16
{
	// Methods

	// RVA: 0xFFFFFFFF75A4BDC8
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4B790
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubOvfUInt32
{
	// Methods

	// RVA: 0xFFFFFFFF75A4BFDC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4B798
	public Void .ctor() { }

}

// Namespace: 
private sealed class SubOvfUInt64
{
	// Methods

	// RVA: 0xFFFFFFFF75A4C19C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4B7A0
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CreateDelegateInstruction
{
	// Fields
	private readonly LightDelegateCreator _creator; // 0x10

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1C3A8
	internal Void .ctor(LightDelegateCreator delegateCreator) { }

	// RVA: 0xFFFFFFFF75A1C3DC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1C458
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1C460
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1C4A0
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TypeIsInstruction
{
	// Fields
	private readonly Type _type; // 0x10

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4CF08
	internal Void .ctor(Type type) { }

	// RVA: 0xFFFFFFFF75A4CF3C
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4CF44
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4CF4C
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4CF8C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4CFF0
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TypeAsInstruction
{
	// Fields
	private readonly Type _type; // 0x10

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4CC8C
	internal Void .ctor(Type type) { }

	// RVA: 0xFFFFFFFF75A4CCC0
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4CCC8
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4CCD0
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4CD10
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4CD84
	public override String ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TypeEqualsInstruction
{
	// Fields
	public static readonly TypeEqualsInstruction Instance; // 0x0

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A4CDEC
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A4CDF4
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A4CDFC
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A4CE3C
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A4CE44
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A4CEA8
	private static Void .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NullableMethodCallInstruction
{
	// Fields
	private static NullableMethodCallInstruction s_hasValue; // 0x0
	private static NullableMethodCallInstruction s_value; // 0x8
	private static NullableMethodCallInstruction s_equals; // 0x10
	private static NullableMethodCallInstruction s_getHashCode; // 0x18
	private static NullableMethodCallInstruction s_getValueOrDefault1; // 0x20
	private static NullableMethodCallInstruction s_toString; // 0x28

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A453A4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A453AC
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A453B4
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A453F4
	private Void .ctor() { }

	// RVA: 0xFFFFFFFF75A453FC
	public static Instruction Create(String method, Int32 argCount, MethodInfo mi) { }

	// RVA: 0xFFFFFFFF75A45780
	public static Instruction CreateGetValue() { }

}

// Namespace: 
private sealed class HasValue
{
	// Methods

	// RVA: 0xFFFFFFFF75A45A54
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45700
	public Void .ctor() { }

}

// Namespace: 
private sealed class GetValue
{
	// Methods

	// RVA: 0xFFFFFFFF75A45944
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45708
	public Void .ctor() { }

}

// Namespace: 
private sealed class GetValueOrDefault
{
	// Fields
	private readonly Type defaultValueType; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A45720
	public Void .ctor(MethodInfo mi) { }

	// RVA: 0xFFFFFFFF75A45990
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class GetValueOrDefault1
{
	// Properties
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A459F4
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A459FC
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45770
	public Void .ctor() { }

}

// Namespace: 
private sealed class EqualsClass
{
	// Properties
	public override Int32 ConsumedStack { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A45808
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A45810
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45710
	public Void .ctor() { }

}

// Namespace: 
private sealed class ToStringClass
{
	// Methods

	// RVA: 0xFFFFFFFF75A45A9C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45778
	public Void .ctor() { }

}

// Namespace: 
private sealed class GetHashCodeClass
{
	// Methods

	// RVA: 0xFFFFFFFF75A458E4
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: 0xFFFFFFFF75A45718
	public Void .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class CastInstruction
{
	// Fields
	private static CastInstruction s_Boolean; // 0x0
	private static CastInstruction s_Byte; // 0x8
	private static CastInstruction s_Char; // 0x10
	private static CastInstruction s_DateTime; // 0x18
	private static CastInstruction s_Decimal; // 0x20
	private static CastInstruction s_Double; // 0x28
	private static CastInstruction s_Int16; // 0x30
	private static CastInstruction s_Int32; // 0x38
	private static CastInstruction s_Int64; // 0x40
	private static CastInstruction s_SByte; // 0x48
	private static CastInstruction s_Single; // 0x50
	private static CastInstruction s_String; // 0x58
	private static CastInstruction s_UInt16; // 0x60
	private static CastInstruction s_UInt32; // 0x68
	private static CastInstruction s_UInt64; // 0x70

	// Properties
	public override Int32 ConsumedStack { get; }
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A1B398
	public override Int32 get_ConsumedStack() { }

	// RVA: 0xFFFFFFFF75A1B3A0
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A1B3A8
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A1B3E8
	public static Instruction Create(Type t) { }

	// RVA: 0xFFFFFFFF75A1BA68
	protected Void .ctor() { }

}

// Namespace: 
private sealed class CastInstructionT<T0>
{
	// Methods

	// RVA: -1
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: -1
	public Void .ctor() { }

}

// Namespace: 
private abstract class CastInstructionNoT
{
	// Fields
	private readonly Type _t; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A1BA70
	protected Void .ctor(Type t) { }

	// RVA: 0xFFFFFFFF75A1B9BC
	public static CastInstruction Create(Type t) { }

	// RVA: 0xFFFFFFFF75A1BB0C
	public override Int32 Run(InterpretedFrame frame) { }

	// RVA: -1
	protected abstract Void ConvertNull(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class Ref
{
	// Methods

	// RVA: 0xFFFFFFFF75A1BAD8
	public Void .ctor(Type t) { }

	// RVA: 0xFFFFFFFF75A1BC10
	protected override Void ConvertNull(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class Value
{
	// Methods

	// RVA: 0xFFFFFFFF75A1BAA4
	public Void .ctor(Type t) { }

	// RVA: 0xFFFFFFFF75A1BC2C
	protected override Void ConvertNull(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CastToEnumInstruction
{
	// Fields
	private readonly Type _t; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A1C100
	public Void .ctor(Type t) { }

	// RVA: 0xFFFFFFFF75A1C134
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CastReferenceToEnumInstruction
{
	// Fields
	private readonly Type _t; // 0x10

	// Methods

	// RVA: 0xFFFFFFFF75A1BC80
	public Void .ctor(Type t) { }

	// RVA: 0xFFFFFFFF75A1BCB4
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class QuoteInstruction
{
	// Fields
	private readonly Expression _operand; // 0x10
	private readonly Dictionary<T0, T1> _hoistedVariables; // 0x18

	// Properties
	public override Int32 ProducedStack { get; }
	public override String InstructionName { get; }

	// Methods

	// RVA: 0xFFFFFFFF75A48890
	public Void .ctor(Expression operand, Dictionary<T0, T1> hoistedVariables) { }

	// RVA: 0xFFFFFFFF75A488E0
	public override Int32 get_ProducedStack() { }

	// RVA: 0xFFFFFFFF75A488E8
	public override String get_InstructionName() { }

	// RVA: 0xFFFFFFFF75A48928
	public override Int32 Run(InterpretedFrame frame) { }

}

// Namespace: 
private sealed class ExpressionQuoter
{
	// Fields
	private readonly Dictionary<T0, T1> _variables; // 0x10
	private readonly InterpretedFrame _frame; // 0x18
	private readonly Stack<T0> _shadowedVars; // 0x20

	// Methods

	// RVA: 0xFFFFFFFF75A489D0
	internal Void .ctor(Dictionary<T0, T1> hoistedVariables, InterpretedFrame frame) { }

	// RVA: -1
	protected internal override Expression VisitLambda(Expression<T0> node) { }

	// RVA: 0xFFFFFFFF75A48A7C
	protected internal override Expression VisitBlock(BlockExpression node) { }

	// RVA: 0xFFFFFFFF75A48BF8
	protected override CatchBlock VisitCatchBlock(CatchBlock node) { }

	// RVA: 0xFFFFFFFF75A48D8C
	protected internal override Expression VisitParameter(ParameterExpression node) { }

	// RVA: 0xFFFFFFFF75A48E60
	private IStrongBox GetBox(ParameterExpression variable) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class DelegateHelpers
{
	// Methods

	// RVA: 0xFFFFFFFF75A1D224
	internal static Type MakeDelegate(Type[] types) { }

}

// Namespace: 
private sealed class <>c
{
	// Fields
	public static readonly <>c <>9; // 0x0
	public static Func<T0, T1> <>9__1_0; // 0x8

	// Methods

	// RVA: 0xFFFFFFFF75A1D7A8
	private static Void .cctor() { }

	// RVA: 0xFFFFFFFF75A1D808
	public Void .ctor() { }

	// RVA: 0xFFFFFFFF75A1D810
	internal Boolean <MakeDelegate>b__1_0(Type t) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class ScriptingRuntimeHelpers
{
	// Methods

	// RVA: 0xFFFFFFFF75A3F7CC
	public static Object Int32ToObject(Int32 i) { }

	// RVA: 0xFFFFFFFF75A49D50
	internal static Object GetPrimitiveDefaultValue(Type type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class ExceptionHelpers
{
	// Methods

	// RVA: 0xFFFFFFFF75A1A8D8
	public static Void UnwrapAndRethrow(TargetInvocationException exception) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class HybridReferenceDictionary<T0, T1>
{
	// Fields
	private KeyValuePair`2<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22, T23, T24, T25, T26, T27, T28, T29, T30, T31, T32, T33, T34, T35, T36, T37, T38, T39, T40, T41, T42, T43, T44> _keysAndValues; // 0x0
	private Dictionary<T0, T1> _dict; // 0x0

	// Properties
	public TValue Item { get; set; }

	// Methods

	// RVA: -1
	public Boolean TryGetValue(TKey key, out TValue value) { }

	// RVA: -1
	public Void Remove(TKey key) { }

	// RVA: -1
	public Boolean ContainsKey(TKey key) { }

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	private IEnumerator<T0> GetEnumeratorWorker() { }

	// RVA: -1
	public TValue get_Item(TKey key) { }

	// RVA: -1
	public Void set_Item(TKey key, TValue value) { }

	// RVA: -1
	public Void .ctor() { }

}

// Namespace: 
private sealed class <GetEnumeratorWorker>d__7
{
	// Fields
	private Int32 <>1__state; // 0x0
	private KeyValuePair<T0, T1> <>2__current; // 0x0
	public HybridReferenceDictionary<T0, T1> <>4__this; // 0x0
	private Int32 <i>5__1; // 0x0

	// Properties
	private KeyValuePair<T0, T1> System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 <>1__state) { }

	// RVA: -1
	private Void System.IDisposable.Dispose() { }

	// RVA: -1
	private Boolean MoveNext() { }

	// RVA: -1
	private KeyValuePair<T0, T1> System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Runtime.CompilerServices
public abstract class DebugInfoGenerator
{}

// Namespace: System.Runtime.CompilerServices
public interface IRuntimeVariables
{}

// Namespace: System.Runtime.CompilerServices
public sealed class ReadOnlyCollectionBuilder<T0>
{
	// Fields
	private T[] _items; // 0x0
	private Int32 _size; // 0x0
	private Int32 _version; // 0x0

	// Properties
	public Int32 Capacity { set; }
	public Int32 Count { get; }
	public T Item { get; set; }
	private Boolean System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
	private Boolean System.Collections.IList.IsReadOnly { get; }
	private Boolean System.Collections.IList.IsFixedSize { get; }
	private Object System.Collections.IList.Item { get; set; }
	private Boolean System.Collections.ICollection.IsSynchronized { get; }
	private Object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	public Void set_Capacity(Int32 value) { }

	// RVA: -1
	public Int32 get_Count() { }

	// RVA: -1
	public Int32 IndexOf(T item) { }

	// RVA: -1
	public Void Insert(Int32 index, T item) { }

	// RVA: -1
	public Void RemoveAt(Int32 index) { }

	// RVA: -1
	public T get_Item(Int32 index) { }

	// RVA: -1
	public Void set_Item(Int32 index, T value) { }

	// RVA: -1
	public Void Add(T item) { }

	// RVA: -1
	public Void Clear() { }

	// RVA: -1
	public Boolean Contains(T item) { }

	// RVA: -1
	public Void CopyTo(T[] array, Int32 arrayIndex) { }

	// RVA: -1
	private Boolean System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	// RVA: -1
	public Boolean Remove(T item) { }

	// RVA: -1
	public IEnumerator<T0> GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private Boolean System.Collections.IList.get_IsReadOnly() { }

	// RVA: -1
	private Int32 System.Collections.IList.Add(Object value) { }

	// RVA: -1
	private Boolean System.Collections.IList.Contains(Object value) { }

	// RVA: -1
	private Int32 System.Collections.IList.IndexOf(Object value) { }

	// RVA: -1
	private Void System.Collections.IList.Insert(Int32 index, Object value) { }

	// RVA: -1
	private Boolean System.Collections.IList.get_IsFixedSize() { }

	// RVA: -1
	private Void System.Collections.IList.Remove(Object value) { }

	// RVA: -1
	private Object System.Collections.IList.get_Item(Int32 index) { }

	// RVA: -1
	private Void System.Collections.IList.set_Item(Int32 index, Object value) { }

	// RVA: -1
	private Void System.Collections.ICollection.CopyTo(Array array, Int32 index) { }

	// RVA: -1
	private Boolean System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private Object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	public T[] ToArray() { }

	// RVA: -1
	public ReadOnlyCollection<T0> ToReadOnlyCollection() { }

	// RVA: -1
	private Void EnsureCapacity(Int32 min) { }

	// RVA: -1
	private static Boolean IsCompatibleObject(Object value) { }

	// RVA: -1
	private static Void ValidateNullValue(Object value, String argument) { }

}

// Namespace: 
private class Enumerator
{
	// Fields
	private readonly ReadOnlyCollectionBuilder<T0> _builder; // 0x0
	private readonly Int32 _version; // 0x0
	private Int32 _index; // 0x0
	private T _current; // 0x0

	// Properties
	public T Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal Void .ctor(ReadOnlyCollectionBuilder<T0> builder) { }

	// RVA: -1
	public T get_Current() { }

	// RVA: -1
	public Void Dispose() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public Boolean MoveNext() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class TrueReadOnlyCollection<T0>
{
	// Methods

	// RVA: -1
	public Void .ctor(T[] list) { }

}

// Namespace: System.Runtime.CompilerServices
public class StrongBox<T0>
{
	// Fields
	public T Value; // 0x0

	// Properties
	private Object System.Runtime.CompilerServices.IStrongBox.Value { get; set; }

	// Methods

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	public Void .ctor(T value) { }

	// RVA: -1
	private Object System.Runtime.CompilerServices.IStrongBox.get_Value() { }

	// RVA: -1
	private Void System.Runtime.CompilerServices.IStrongBox.set_Value(Object value) { }

}

// Namespace: System.Runtime.CompilerServices
public interface IStrongBox
{
	// Properties
	public abstract Object Value { get; set; }

	// Methods

	// RVA: -1
	public abstract Object get_Value() { }

	// RVA: -1
	public abstract Void set_Value(Object value) { }

}

// Namespace: System.Dynamic.Utils
internal sealed class CacheDict<T0, T1>
{
	// Fields
	private readonly Int32 _mask; // 0x0
	private readonly Entry[] _entries; // 0x0

	// Properties
	internal TKey Item { set; }

	// Methods

	// RVA: -1
	internal Void .ctor(Int32 size) { }

	// RVA: -1
	private static Int32 AlignSize(Int32 size) { }

	// RVA: -1
	internal Boolean TryGetValue(TKey key, out TValue value) { }

	// RVA: -1
	internal Void Add(TKey key, TValue value) { }

	// RVA: -1
	internal Void set_Item(TKey key, TValue value) { }

}

// Namespace: 
private sealed class Entry
{
	// Fields
	internal readonly Int32 _hash; // 0x0
	internal readonly TKey _key; // 0x0
	internal readonly TValue _value; // 0x0

	// Methods

	// RVA: -1
	internal Void .ctor(Int32 hash, TKey key, TValue value) { }

}

// Namespace: System.Dynamic.Utils
internal static class CollectionExtensions
{
	// Methods

	// RVA: -1
	public static T[] RemoveFirst(T[] array) { }

	// RVA: -1
	public static T[] RemoveLast(T[] array) { }

	// RVA: -1
	public static ReadOnlyCollection<T0> ToReadOnly(IEnumerable<T0> enumerable) { }

}

// Namespace: System.Dynamic.Utils
internal static class ContractUtils
{
	// Properties
	public static Exception Unreachable { get; }

	// Methods

	// RVA: 0xFFFFFFFF759F3E38
	public static Exception get_Unreachable() { }

	// RVA: 0xFFFFFFFF759F3E94
	public static Void Requires(Boolean precondition, String paramName) { }

	// RVA: 0xFFFFFFFF759F3F48
	public static Void RequiresNotNull(Object value, String paramName) { }

	// RVA: 0xFFFFFFFF759F3FC0
	public static Void RequiresNotNull(Object value, String paramName, Int32 index) { }

	// RVA: -1
	public static Void RequiresNotNullItems(IList<T0> array, String arrayName) { }

	// RVA: 0xFFFFFFFF759F404C
	private static String GetParamName(String paramName, Int32 index) { }

}

// Namespace: System.Dynamic.Utils
internal static class EmptyReadOnlyCollection<T0>
{
	// Fields
	public static readonly ReadOnlyCollection<T0> Instance; // 0x0

	// Methods

	// RVA: -1
	private static Void .cctor() { }

}

// Namespace: System.Dynamic.Utils
internal static class ExpressionUtils
{
	// Methods

	// RVA: -1
	public static ReadOnlyCollection<T0> ReturnReadOnly(ref IReadOnlyList<T0> collection) { }

	// RVA: -1
	public static T ReturnObject(Object collectionOrT) { }

	// RVA: 0xFFFFFFFF759F40D4
	public static Void ValidateArgumentTypes(MethodBase method, ExpressionType nodeKind, ref ReadOnlyCollection<T0> arguments, String methodParamName) { }

	// RVA: 0xFFFFFFFF759F4400
	public static Void ValidateArgumentCount(MethodBase method, ExpressionType nodeKind, Int32 count, ParameterInfo[] pis) { }

	// RVA: 0xFFFFFFFF759F44C8
	public static Expression ValidateOneArgument(MethodBase method, ExpressionType nodeKind, Expression arguments, ParameterInfo pi, String methodParamName, String argumentParamName, Int32 index) { }

	// RVA: 0xFFFFFFFF759F4CD0
	public static Void RequiresCanRead(Expression expression, String paramName) { }

	// RVA: 0xFFFFFFFF759F479C
	public static Void RequiresCanRead(Expression expression, String paramName, Int32 idx) { }

	// RVA: 0xFFFFFFFF759F4A84
	public static Boolean TryQuote(Type parameterType, ref Expression argument) { }

	// RVA: 0xFFFFFFFF759F4368
	internal static ParameterInfo[] GetParametersForValidation(MethodBase method, ExpressionType nodeKind) { }

	// RVA: -1
	internal static Boolean SameElements(ref IEnumerable<T0> replacement, IReadOnlyList<T0> current) { }

	// RVA: -1
	private static Boolean SameElementsInCollection(ICollection<T0> replacement, IReadOnlyList<T0> current) { }

}

// Namespace: System.Dynamic.Utils
internal static class ExpressionVisitorUtils
{
	// Methods

	// RVA: 0xFFFFFFFF759F4FCC
	public static Expression[] VisitBlockExpressions(ExpressionVisitor visitor, BlockExpression block) { }

	// RVA: 0xFFFFFFFF759F515C
	public static ParameterExpression[] VisitParameters(ExpressionVisitor visitor, IParameterProvider nodes, String callerName) { }

	// RVA: 0xFFFFFFFF759F540C
	public static Expression[] VisitArguments(ExpressionVisitor visitor, IArgumentProvider nodes) { }

}

// Namespace: System.Dynamic.Utils
internal static class TypeExtensions
{
	// Fields
	private static readonly CacheDict<T0, T1> s_paramInfoCache; // 0x0

	// Methods

	// RVA: 0xFFFFFFFF759F5684
	public static MethodInfo GetAnyStaticMethodValidated(Type type, String name, Type[] types) { }

	// RVA: 0xFFFFFFFF759F572C
	private static Boolean MatchesArgumentTypes(MethodInfo mi, Type[] argTypes) { }

	// RVA: 0xFFFFFFFF759F5844
	public static TypeCode GetTypeCode(Type type) { }

	// RVA: 0xFFFFFFFF759F4E88
	internal static ParameterInfo[] GetParametersCached(MethodBase method) { }

	// RVA: 0xFFFFFFFF759F5950
	private static Void .cctor() { }

}

// Namespace: System.Dynamic.Utils
internal static class TypeUtils
{
	// Fields
	private static Assembly s_mscorlib; // 0x0

	// Properties
	private static Assembly MsCorLib { get; }

	// Methods

	// RVA: 0xFFFFFFFF759F59D4
	public static Type GetNonNullableType(Type type) { }

	// RVA: 0xFFFFFFFF759F5ACC
	public static Type GetNullableType(Type type) { }

	// RVA: 0xFFFFFFFF759F5A34
	public static Boolean IsNullableType(Type type) { }

	// RVA: 0xFFFFFFFF759F5B90
	public static Boolean IsNullableOrReferenceType(Type type) { }

	// RVA: 0xFFFFFFFF759F5BD4
	public static Boolean IsBool(Type type) { }

	// RVA: 0xFFFFFFFF759F5C30
	public static Boolean IsNumeric(Type type) { }

	// RVA: 0xFFFFFFFF759F5CD0
	public static Boolean IsInteger(Type type) { }

	// RVA: 0xFFFFFFFF759F5D70
	public static Boolean IsArithmetic(Type type) { }

	// RVA: 0xFFFFFFFF759F5E10
	public static Boolean IsUnsignedInt(Type type) { }

	// RVA: 0xFFFFFFFF759F5EB4
	public static Boolean IsIntegerOrBool(Type type) { }

	// RVA: 0xFFFFFFFF759F5F58
	public static Boolean IsNumericOrBool(Type type) { }

	// RVA: 0xFFFFFFFF759F5F90
	public static Boolean IsValidInstanceType(MemberInfo member, Type instanceType) { }

	// RVA: 0xFFFFFFFF759F639C
	public static Boolean HasIdentityPrimitiveOrNullableConversionTo(Type source, Type dest) { }

	// RVA: 0xFFFFFFFF759F65F4
	public static Boolean HasReferenceConversionTo(Type source, Type dest) { }

	// RVA: 0xFFFFFFFF759F69D4
	private static Boolean IsCovariant(Type t) { }

	// RVA: 0xFFFFFFFF759F6A00
	private static Boolean IsContravariant(Type t) { }

	// RVA: 0xFFFFFFFF759F6A2C
	private static Boolean IsInvariant(Type t) { }

	// RVA: 0xFFFFFFFF759F6A5C
	private static Boolean IsDelegate(Type t) { }

	// RVA: 0xFFFFFFFF759F676C
	public static Boolean IsLegalExplicitVariantDelegateConversion(Type source, Type dest) { }

	// RVA: 0xFFFFFFFF759F6558
	public static Boolean IsConvertible(Type type) { }

	// RVA: 0xFFFFFFFF759F6AC4
	public static Boolean HasReferenceEquality(Type left, Type right) { }

	// RVA: 0xFFFFFFFF759F6B5C
	public static Boolean HasBuiltInEqualityOperator(Type left, Type right) { }

	// RVA: 0xFFFFFFFF759F6CA0
	public static Boolean IsImplicitlyConvertibleTo(Type source, Type destination) { }

	// RVA: 0xFFFFFFFF759F6FEC
	public static MethodInfo GetUserDefinedCoercionMethod(Type convertFrom, Type convertToType) { }

	// RVA: 0xFFFFFFFF759F7154
	private static MethodInfo FindConversionOperator(MethodInfo[] methods, Type typeFrom, Type typeTo) { }

	// RVA: 0xFFFFFFFF759F6D24
	private static Boolean IsImplicitNumericConversion(Type source, Type destination) { }

	// RVA: 0xFFFFFFFF759F6E5C
	private static Boolean IsImplicitReferenceConversion(Type source, Type destination) { }

	// RVA: 0xFFFFFFFF759F6E8C
	private static Boolean IsImplicitBoxingConversion(Type source, Type destination) { }

	// RVA: 0xFFFFFFFF759F6F98
	private static Boolean IsImplicitNullableConversion(Type source, Type destination) { }

	// RVA: 0xFFFFFFFF759F72E0
	public static Type FindGenericType(Type definition, Type type) { }

	// RVA: 0xFFFFFFFF759F7710
	public static MethodInfo GetBooleanOperator(Type type, String name) { }

	// RVA: 0xFFFFFFFF759F7844
	public static Type GetNonRefType(Type type) { }

	// RVA: 0xFFFFFFFF759F64E0
	public static Boolean AreEquivalent(Type t1, Type t2) { }

	// RVA: 0xFFFFFFFF759F4A04
	public static Boolean AreReferenceAssignable(Type dest, Type src) { }

	// RVA: 0xFFFFFFFF759F4D30
	public static Boolean IsSameOrSubclass(Type type, Type subType) { }

	// RVA: 0xFFFFFFFF759F7894
	public static Void ValidateType(Type type, String paramName) { }

	// RVA: 0xFFFFFFFF759F4944
	public static Void ValidateType(Type type, String paramName, Boolean allowByRef, Boolean allowPointer) { }

	// RVA: 0xFFFFFFFF759F78A0
	public static Boolean ValidateType(Type type, String paramName, Int32 index) { }

	// RVA: 0xFFFFFFFF759F7B18
	private static Assembly get_MsCorLib() { }

	// RVA: 0xFFFFFFFF759F5884
	public static Boolean CanCache(Type t) { }

	// RVA: 0xFFFFFFFF759F7BCC
	public static MethodInfo GetInvokeMethod(Type delegateType) { }

}

// Namespace: System.Collections.Generic
internal struct LargeArrayBuilder<T0>
{
	// Fields
	private readonly Int32 _maxCapacity; // 0x0
	private T[] _first; // 0x0
	private ArrayBuilder<T0> _buffers; // 0x0
	private T[] _current; // 0x0
	private Int32 _index; // 0x0
	private Int32 _count; // 0x0

	// Methods

	// RVA: -1
	public Void .ctor(Boolean initialize) { }

	// RVA: -1
	public Void .ctor(Int32 maxCapacity) { }

	// RVA: -1
	public Void AddRange(IEnumerable<T0> items) { }

	// RVA: -1
	public Void CopyTo(T[] array, Int32 arrayIndex, Int32 count) { }

	// RVA: -1
	public T[] GetBuffer(Int32 index) { }

	// RVA: -1
	public T[] ToArray() { }

	// RVA: -1
	public Boolean TryMove(out T[] array) { }

	// RVA: -1
	private Void AllocateBuffer() { }

}

// Namespace: System.Collections.Generic
internal struct ArrayBuilder<T0>
{
	// Fields
	private T[] _array; // 0x0
	private Int32 _count; // 0x0

	// Properties
	public Int32 Capacity { get; }
	public Int32 Count { get; }
	public T Item { get; }

	// Methods

	// RVA: -1
	public Void .ctor(Int32 capacity) { }

	// RVA: -1
	public Int32 get_Capacity() { }

	// RVA: -1
	public Int32 get_Count() { }

	// RVA: -1
	public T get_Item(Int32 index) { }

	// RVA: -1
	public Void Add(T item) { }

	// RVA: -1
	public T[] ToArray() { }

	// RVA: -1
	public Void UncheckedAdd(T item) { }

	// RVA: -1
	private Void EnsureCapacity(Int32 minimum) { }

}

// Namespace: System.Collections.Generic
internal static class EnumerableHelpers
{
	// Methods

	// RVA: -1
	internal static T[] ToArray(IEnumerable<T0> source) { }

}

// Namespace: System.Collections.Generic
public class HashSet<T0>
{
	// Fields
	private const Int32 Lower31BitMask = 2147483647;
	private const Int32 StackAllocThreshold = 100;
	private const Int32 ShrinkThreshold = 3;
	private const String CapacityName = "Capacity";
	private const String ElementsName = "Elements";
	private const String ComparerName = "Comparer";
	private const String VersionName = "Version";
	private Int32[] _buckets; // 0x0
	private Slot[] _slots; // 0x0
	private Int32 _count; // 0x0
	private Int32 _lastIndex; // 0x0
	private Int32 _freeList; // 0x0
	private IEqualityComparer<T0> _comparer; // 0x0
	private Int32 _version; // 0x0
	private SerializationInfo _siInfo; // 0x0

	// Properties
	public Int32 Count { get; }
	private Boolean System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
	public IEqualityComparer<T0> Comparer { get; }

	// Methods

	// RVA: -1
	public Void .ctor() { }

	// RVA: -1
	public Void .ctor(IEqualityComparer<T0> comparer) { }

	// RVA: -1
	public Void .ctor(IEnumerable<T0> collection) { }

	// RVA: -1
	public Void .ctor(IEnumerable<T0> collection, IEqualityComparer<T0> comparer) { }

	// RVA: -1
	protected Void .ctor(SerializationInfo info, StreamingContext context) { }

	// RVA: -1
	private Void CopyFrom(HashSet<T0> source) { }

	// RVA: -1
	private Void System.Collections.Generic.ICollection<T>.Add(T item) { }

	// RVA: -1
	public Void Clear() { }

	// RVA: -1
	public Boolean Contains(T item) { }

	// RVA: -1
	public Void CopyTo(T[] array, Int32 arrayIndex) { }

	// RVA: -1
	public Boolean Remove(T item) { }

	// RVA: -1
	public Int32 get_Count() { }

	// RVA: -1
	private Boolean System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	// RVA: -1
	public Enumerator GetEnumerator() { }

	// RVA: -1
	private IEnumerator<T0> System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public virtual Void GetObjectData(SerializationInfo info, StreamingContext context) { }

	// RVA: -1
	public virtual Void OnDeserialization(Object sender) { }

	// RVA: -1
	public Boolean Add(T item) { }

	// RVA: -1
	public Void UnionWith(IEnumerable<T0> other) { }

	// RVA: -1
	public Void ExceptWith(IEnumerable<T0> other) { }

	// RVA: -1
	public Void CopyTo(T[] array) { }

	// RVA: -1
	public Void CopyTo(T[] array, Int32 arrayIndex, Int32 count) { }

	// RVA: -1
	public IEqualityComparer<T0> get_Comparer() { }

	// RVA: -1
	public Void TrimExcess() { }

	// RVA: -1
	private Void Initialize(Int32 capacity) { }

	// RVA: -1
	private Void IncreaseCapacity() { }

	// RVA: -1
	private Void SetCapacity(Int32 newSize) { }

	// RVA: -1
	private Boolean AddIfNotPresent(T value) { }

	// RVA: -1
	private Void AddValue(Int32 index, Int32 hashCode, T value) { }

	// RVA: -1
	private static Boolean AreEqualityComparersEqual(HashSet<T0> set1, HashSet<T0> set2) { }

	// RVA: -1
	private Int32 InternalGetHashCode(T item) { }

}

// Namespace: 
internal struct Slot
{
	// Fields
	internal Int32 hashCode; // 0x0
	internal Int32 next; // 0x0
	internal T value; // 0x0
}

// Namespace: 
public struct Enumerator
{
	// Fields
	private HashSet<T0> _set; // 0x0
	private Int32 _index; // 0x0
	private Int32 _version; // 0x0
	private T _current; // 0x0

	// Properties
	public T Current { get; }
	private Object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal Void .ctor(HashSet<T0> set) { }

	// RVA: -1
	public Void Dispose() { }

	// RVA: -1
	public Boolean MoveNext() { }

	// RVA: -1
	public T get_Current() { }

	// RVA: -1
	private Object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private Void System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Collections.Generic
internal sealed class ICollectionDebugView<T0>
{}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{
	// Fields
	internal static readonly __StaticArrayInitTypeSize=120 0AA802CD6847EB893FE786B5EA5168B2FDCD7B93; // 0x0
	internal static readonly __StaticArrayInitTypeSize=256 0C4110BC17D746F018F47B49E0EB0D6590F69939; // 0x78
	internal static readonly __StaticArrayInitTypeSize=1024 20733E1283D873EBE47133A95C233E11B76F5F11; // 0x178
	internal static readonly __StaticArrayInitTypeSize=1024 21F4CBF8283FF1CAEB4A39316A97FC1D6DF1D35E; // 0x578
	internal static readonly __StaticArrayInitTypeSize=1024 23DFDCA6F045D4257BF5AC8CB1CF2EFADAFE9B94; // 0x978
	internal static readonly __StaticArrayInitTypeSize=1024 30A0358B25B1372DD598BB4B1AC56AD6B8F08A47; // 0xD78
	internal static readonly __StaticArrayInitTypeSize=1024 5B5DF5A459E902D96F7DB0FB235A25346CA85C5D; // 0x1178
	internal static readonly __StaticArrayInitTypeSize=1024 5BE411F1438EAEF33726D855E99011D5FECDDD4E; // 0x1578
	internal static readonly __StaticArrayInitTypeSize=256 8F22C9ECE1331718CBD268A9BBFD2F5E451441E3; // 0x1978
	internal static readonly __StaticArrayInitTypeSize=1024 A02DD1D8604EA8EC2D2BDA717A93A4EE85F13E53; // 0x1A78
	internal static readonly __StaticArrayInitTypeSize=1024 AE2F76ECEF8B08F0BC7EA95DCFE945E1727927C9; // 0x1E78
}

// Namespace: 
private struct __StaticArrayInitTypeSize=120
{}

// Namespace: 
private struct __StaticArrayInitTypeSize=256
{}

// Namespace: 
private struct __StaticArrayInitTypeSize=1024
{}


